/* fx-trim · כותרת מסתפרת */
(function () {
  'use strict';
  var mm = window.matchMedia;
  if (mm && mm('(prefers-reduced-motion: reduce)').matches) return;
  var FINE = !!mm && mm('(hover: hover) and (pointer: fine)').matches;
  var items = [], running = false, tickNo = 0;
  var mouse = { x: -9999, y: -9999, vx: 0, on: false };

  function hash(n) {
    var s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
    return s - Math.floor(s);
  }
  function noise(x) {                       // רעש חלק בין 0 ל-1: נותן לשיער גבהים לא אחידים
    var i = Math.floor(x), f = x - i, u = f * f * (3 - 2 * f);
    return hash(i) * (1 - u) + hash(i + 1) * u;
  }

  // עוטף כל מילה ב-span כדי לדעת איפה היא יושבת
  function wrap(el) {
    var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null), nodes = [], n, words = [];
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach(function (node) {
      var frag = document.createDocumentFragment();
      node.nodeValue.split(/(\s+)/).forEach(function (part) {
        if (!part) return;
        if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(' ')); return; }
        var s = document.createElement('span');
        s.textContent = part;
        frag.appendChild(s);
        words.push(s);
      });
      node.parentNode.replaceChild(frag, node);
    });
    return words;
  }

  // מצייר כל מילה בצד, מוצא את הקצה העליון של האותיות ושותל שם שערות
  function build(st) {
    var el = st.el, c = st.canvas, cs = getComputedStyle(el), de = document.documentElement;
    c.style.display = 'none';                // מודדים בלי הקנבס, כדי שהוא עצמו לא ירחיב את העמוד
    var r = el.getBoundingClientRect(), root = de.getBoundingClientRect();
    var below = Math.max(root.bottom, de.scrollHeight - (window.pageYOffset || 0)) - r.bottom;
    c.style.display = '';
    if (!r.width || !r.height) return;
    var size = parseFloat(cs.fontSize) || 40;
    st.max = st.length || size * 0.5;
    st.lw = Math.max(1.1, size / 64);
    st.clip = Math.max(34, size * 0.42);
    st.color = cs.getPropertyValue('--fx-trim-color').trim() || cs.color;
    // שוליים לשיער שנוטה הצידה ולקצוות שנופלים, בלי לחרוג מגבולות העמוד
    var padX = Math.max(0, Math.min(40, r.left - root.left)), padEnd = Math.max(0, Math.min(40, root.right - r.right));
    var padTop = Math.ceil(st.max) + 24, padBottom = Math.max(0, Math.min(170, below));
    st.W = r.width + padX + padEnd;
    st.H = r.height + padTop + padBottom;
    st.zone = r.height + padTop + 50;        // עד כאן המכונה עדיין נחשבת "על הכותרת"
    st.dpr = Math.min(window.devicePixelRatio || 1, 2);
    c.style.left = -padX + 'px';
    c.style.top = -padTop + 'px';
    c.style.width = st.W + 'px';
    c.style.height = st.H + 'px';
    c.width = Math.round(st.W * st.dpr);
    c.height = Math.round(st.H * st.dpr);

    var originX = r.left + el.clientLeft - padX, originY = r.top + el.clientTop - padTop;
    var font = cs.fontStyle + ' ' + cs.fontWeight + ' ' + size + 'px ' + cs.fontFamily;
    var off = document.createElement('canvas'), o = off.getContext('2d', { willReadFrequently: true });
    var step = Math.max(1.6, size / 60), strands = [], lines = [];

    st.words.forEach(function (w) {
      var wr = w.getBoundingClientRect();
      if (!wr.width || !wr.height) return;
      var ww = Math.ceil(wr.width) + 4, wh = Math.ceil(wr.height) + 4;
      off.width = ww;
      off.height = wh;
      o.font = font;
      o.textBaseline = 'alphabetic';
      o.textAlign = 'left';
      o.direction = cs.direction;
      o.fillStyle = '#000';
      var asc = o.measureText(w.textContent).fontBoundingBoxAscent || size * 0.8;
      o.fillText(w.textContent, 2, 2 + asc);
      var data = o.getImageData(0, 0, ww, wh).data, minY = 1e9, tops = [];
      for (var x = 2; x < ww - 2; x += step) {
        var xi = Math.round(x), top = -1;
        for (var y = 0; y < wh; y++) {
          if (data[(y * ww + xi) * 4 + 3] > 110) { top = y; break; }
        }
        if (top < 0) continue;
        var gx = wr.left - originX + x - 2, gy = wr.top - originY + top - 2 + 1.5;
        if (gy < minY) minY = gy;
        tops.push(gy);
        for (var k = 0; k < 2; k++) {
          var len = st.max * (0.28 + 0.72 * noise(gx * 0.021 + st.seed)) * (0.75 + Math.random() * 0.45);
          strands.push({
            x: gx + (Math.random() - 0.5) * step, y: gy, len: len, cur: len,
            lean: (noise(gx * 0.012 + st.seed + 40) - 0.5) * 1.1 + (Math.random() - 0.5) * 0.3,
            curl: (Math.random() - 0.5) * 0.8, ph: Math.random() * 6.283
          });
        }
      }
      if (minY < 1e9) {
        var left = wr.left - originX, line = null;
        lines.forEach(function (l) { if (Math.abs(l.top - minY) < size * 0.6) line = l; });
        if (!line) { line = { top: minY, y: minY, tops: [], x0: left, x1: left + wr.width }; lines.push(line); }
        line.top = Math.min(line.top, minY);
        line.tops = line.tops.concat(tops);
        line.x0 = Math.min(line.x0, left);
        line.x1 = Math.max(line.x1, left + wr.width);
      }
    });
    // גובה השורה למעבר האוטומטי: הגובה הרגיל של האותיות, כדי שאות גבוהה אחת (ל) לא תרים את המכונה מעל כולן
    lines.forEach(function (l) {
      l.tops.sort(function (a, b) { return a - b; });
      l.y = l.tops[Math.floor(l.tops.length * 0.4)];
      l.tops = null;
    });
    st.strands = strands;
    st.lines = lines.sort(function (a, b) { return a.top - b.top; });
    st.bits = [];
  }

  // המכונה עוברת בנקודה (mx, my): כל שערה שהיא חוצה מתקצרת, והקצה שנחתך נופל
  function cut(st, mx, my, vx, now) {
    var half = st.clip / 2, strands = st.strands;
    for (var i = 0; i < strands.length; i++) {
      var s = strands[i];
      if (s.cur < 2.2) continue;
      var a = -1.5708 + s.lean, tx = s.x + Math.cos(a) * s.cur, ty = s.y + Math.sin(a) * s.cur;
      if (mx < Math.min(s.x, tx) - half || mx > Math.max(s.x, tx) + half) continue;
      var next;
      if (my >= s.y) { if (my > s.y + st.clip * 0.9) continue; next = 2; }
      else if (my > ty) next = Math.max(2, (s.y - my) / Math.max(0.45, -Math.sin(a)));
      else continue;
      if (next > s.cur - 0.6) continue;
      var gone = Math.min(s.cur - next, 34);
      st.bits.push({
        x: s.x + Math.cos(a) * (next + gone / 2), y: s.y + Math.sin(a) * (next + gone / 2), a: a, len: gone,
        vx: vx * 0.12 + (Math.random() - 0.5) * 2.4, vy: -Math.random() * 2.2, va: (Math.random() - 0.5) * 0.3, life: 70 + Math.random() * 45
      });
      s.cur = next;
      st.lastCut = now;
    }
    if (st.bits.length > 700) st.bits.splice(0, st.bits.length - 700);
  }

  function rounded(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }
  function clipper(ctx, x, y, w) {
    ctx.fillStyle = '#1b1c21';
    rounded(ctx, x - w * 0.34, y + 4, w * 0.68, w * 1.2, w * 0.18);
    ctx.fill();
    ctx.fillStyle = '#d62839';
    ctx.fillRect(x - w * 0.34, y + w * 0.42, w * 0.68, w * 0.12);
    ctx.fillStyle = '#8f96a3';
    for (var k = -w / 2 + 1; k < w / 2 - 2; k += 5) ctx.fillRect(x + k, y - 7, 2.6, 6);
    ctx.fillStyle = '#c9ced6';
    ctx.fillRect(x - w / 2, y - 2.5, w, 7);
  }

  function draw(st, now) {
    var ctx = st.ctx, t = now * 0.0016, i, s;
    var cr = st.canvas.getBoundingClientRect();
    var mx = mouse.x - cr.left, my = mouse.y - cr.top;
    var near = mouse.on && mx > -st.clip && mx < st.W + st.clip && my > 0 && my < st.zone;
    var busy = false;

    if (near) { cut(st, mx, my, mouse.vx, now); busy = true; }

    // בלי עכבר (או עם data-auto) המכונה עוברת לבד פעם אחת כשהכותרת נכנסת למסך. data-auto="loop" חוזר שוב ושוב
    st.ax = null;
    if (st.auto && st.autoStart != null && st.lines.length) {
      var at = now - st.autoStart, li = Math.floor(at / 1100);
      if (at >= st.lines.length * 1100 + st.regrow + 3200) {
        st.autoStart = st.loop && st.inView && st.regrow ? now : null;
      } else if (at >= 0 && li < st.lines.length) {
        var l = st.lines[li], u = (at - li * 1100) / 1100;
        u = u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2;
        st.ax = st.rtl ? l.x1 + 20 - (l.x1 - l.x0 + 40) * u : l.x0 - 20 + (l.x1 - l.x0 + 40) * u;
        st.ay = l.y - st.max * 0.22;
        cut(st, st.ax, st.ay, st.rtl ? -9 : 9, now);
        busy = true;
      }
    }

    // השיער צומח בחזרה אחרי הפסקה
    if (st.regrow && now - st.lastCut > st.regrow) {
      for (i = 0; i < st.strands.length; i++) {
        s = st.strands[i];
        if (s.cur < s.len) { s.cur = Math.min(s.len, s.cur + 0.22 + (s.len - s.cur) * 0.014); busy = true; }
      }
    }
    if (st.bits.length) busy = true;
    if (!busy && tickNo % 2) return;         // כשהכול רגוע מספיק לצייר כל פריים שני

    ctx.setTransform(st.dpr, 0, 0, st.dpr, 0, 0);
    ctx.clearRect(0, 0, st.W, st.H);
    ctx.strokeStyle = st.color;
    ctx.lineWidth = st.lw;
    ctx.lineCap = 'round';
    ctx.beginPath();
    for (i = 0; i < st.strands.length; i++) {
      s = st.strands[i];
      if (s.cur < 1.5) continue;
      var a = -1.5708 + s.lean + Math.sin(t + s.ph) * 0.07, ca = Math.cos(a), sa = Math.sin(a), bend = s.curl * s.cur * 0.45;
      ctx.moveTo(s.x, s.y);
      ctx.quadraticCurveTo(s.x + ca * s.cur * 0.5 - sa * bend, s.y + sa * s.cur * 0.5 + ca * bend, s.x + ca * s.cur, s.y + sa * s.cur);
    }
    ctx.stroke();

    if (st.bits.length) {
      ctx.beginPath();
      for (i = st.bits.length - 1; i >= 0; i--) {
        var b = st.bits[i];
        b.vy += 0.32;
        b.vx *= 0.985;
        b.x += b.vx;
        b.y += b.vy;
        b.a += b.va;
        if (--b.life < 0 || b.y > st.H + 20) { st.bits.splice(i, 1); continue; }
        var hx = Math.cos(b.a) * b.len / 2, hy = Math.sin(b.a) * b.len / 2;
        ctx.moveTo(b.x - hx, b.y - hy);
        ctx.lineTo(b.x + hx, b.y + hy);
      }
      ctx.stroke();
    }
    if (near) clipper(ctx, mx, my, st.clip);
    else if (st.ax != null) clipper(ctx, st.ax, st.ay, st.clip);
  }

  function frame(now) {
    var any = false;
    tickNo++;
    items.forEach(function (st) {
      if (!st.visible || !st.strands.length) return;
      any = true;
      draw(st, now);
    });
    mouse.vx *= 0.8;
    if (any) requestAnimationFrame(frame); else running = false;
  }
  function wake() {
    if (!running && items.length) { running = true; requestAnimationFrame(frame); }
  }

  function setup(el) {
    if (el.__fxTrim) return;
    var canvas = document.createElement('canvas'), ctx = canvas.getContext('2d');
    if (!ctx) return;
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var st = el.__fxTrim = {
      el: el, canvas: canvas, ctx: ctx, words: wrap(el), strands: [], bits: [], lines: [], visible: true,
      W: 0, H: 0, zone: 0, dpr: 1, max: 0, lw: 1.2, clip: 40, color: '#000', seed: Math.random() * 100, lastCut: 0, ax: null, ay: 0,
      inView: false, autoStart: null, autoRan: false,
      rtl: getComputedStyle(el).direction === 'rtl',
      length: num('data-length', 0),                  // אורך השיער בפיקסלים. בלי זה, חצי מגודל האות
      regrow: num('data-regrow', 4) * 1000,           // אחרי כמה שניות השיער צומח בחזרה. 0 מבטל
      auto: el.hasAttribute('data-auto') ? el.getAttribute('data-auto') !== 'false' : !FINE,   // המכונה עוברת לבד
      loop: el.getAttribute('data-auto') === 'loop'                                            // ...שוב ושוב
    };
    canvas.className = 'fx-trim__canvas';
    canvas.setAttribute('aria-hidden', 'true');
    el.appendChild(canvas);
    items.push(st);

    var queued = false;
    function rebuild() {
      if (queued) return;
      queued = true;
      requestAnimationFrame(function () { queued = false; build(st); wake(); });
    }
    if ('ResizeObserver' in window) new ResizeObserver(rebuild).observe(el);
    window.addEventListener('resize', rebuild);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(rebuild);
    // המעבר האוטומטי מתחיל כשהכותרת נכנסת למסך (ולא כשהיא יוצאת ממנו), ולא באמצע מעבר קודם
    function start(delay) {
      var now = performance.now();
      if (!st.auto || !(st.regrow || !st.autoRan)) return;
      if (st.autoStart != null && now - st.autoStart < st.lines.length * 1100) return;
      st.autoStart = now + delay;
      st.autoRan = true;
      wake();
    }
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible) wake();
      }, { rootMargin: '200px 0px' }).observe(el);
      new IntersectionObserver(function (entries) {
        var on = entries[entries.length - 1].intersectionRatio >= 0.35;
        if (on && !st.inView) start(300);
        st.inView = on;
      }, { threshold: 0.35 }).observe(el);
    } else {
      st.inView = true;
      start(300);
    }
    el.fxTrim = {
      grow: function () {
        st.strands.forEach(function (s) { s.cur = s.len; });
        st.autoRan = false;
        st.autoStart = null;
        if (st.inView) start(1800);
        wake();
      },
      rebuild: rebuild
    };
    rebuild();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-trim'), setup);
  }

  function track(e) {
    mouse.vx = mouse.on ? e.clientX - mouse.x : 0;
    mouse.x = e.clientX;
    mouse.y = e.clientY;
    mouse.on = true;
  }
  window.addEventListener('pointermove', track, { passive: true });
  window.addEventListener('pointerdown', track, { passive: true });
  function away() { mouse.on = false; }
  window.addEventListener('pointerup', function (e) { if (e.pointerType !== 'mouse') away(); }, { passive: true });
  window.addEventListener('pointercancel', away, { passive: true });
  document.documentElement.addEventListener('mouseleave', away);

  (window.FX = window.FX || {}).trim = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-pole · עמוד הספר */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var linked = [], raf = 0;

  function frame() {
    raf = 0;
    var moving = false;
    linked.forEach(function (st) {
      st.cur += (st.target - st.cur) * 0.14;
      if (Math.abs(st.target - st.cur) > 0.3) moving = true; else st.cur = st.target;
      if (st.visible) st.el.style.setProperty('--fx-pole-shift', st.cur.toFixed(1) + 'px');
    });
    if (moving) raf = requestAnimationFrame(frame);
  }
  function onScroll() {
    var y = window.pageYOffset;
    linked.forEach(function (st) { st.target = y * st.k; });
    if (!raf) raf = requestAnimationFrame(frame);
  }

  function setup(el) {
    if (el.__fxPole) return;
    var st = el.__fxPole = { el: el, visible: true, cur: 0, target: 0, k: 0 };
    // data-scroll: הפסים זזים לפי הגלילה. המספר קובע כמה מהר
    if (el.hasAttribute('data-scroll') && !REDUCE) {
      st.k = parseFloat(el.getAttribute('data-scroll')) || 0.5;
      el.classList.add('is-scroll');
      linked.push(st);
      onScroll();
    }
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        el.classList.toggle('is-paused', !st.visible);     // לא מסתובב כשלא רואים אותו
      }).observe(el);
    }
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-pole'), setup);
  }
  window.addEventListener('scroll', function () { if (linked.length) onScroll(); }, { passive: true, capture: true });
  (window.FX = window.FX || {}).pole = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-neon · שלט ניאון */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var DAY = { 'א': 0, 'ב': 1, 'ג': 2, 'ד': 3, 'ה': 4, 'ו': 5, 'ש': 6, sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 };
  var NAMES = ['ראשון', 'שני', 'שלישי', 'רביעי', 'חמישי', 'שישי', 'שבת'];

  // "א-ה 09:00-20:00, ו 08:00-14:00" -> לכל יום בשבוע [דקת פתיחה, דקת סגירה] או null
  function parseHours(text) {
    var week = [null, null, null, null, null, null, null], ok = false;
    String(text || '').split(/[,;]/).forEach(function (part) {
      var m = part.trim().toLowerCase().match(/^(\S{1,3}?)(?:\s*-\s*(\S{1,3}?))?\s+(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})$/);
      if (!m || !(m[1] in DAY)) return;
      var from = DAY[m[1]], to = m[2] in DAY ? DAY[m[2]] : from;
      for (var d = from; ; d = (d + 1) % 7) {
        week[d] = [+m[3] * 60 + +m[4], +m[5] * 60 + +m[6]];
        ok = true;
        if (d === to) break;
      }
    });
    return ok ? week : null;
  }

  // היום והשעה באזור הזמן של המספרה (data-tz), או לפי השעון של הגולש
  function now(tz) {
    try {
      var parts = new Intl.DateTimeFormat('en-US', {
        timeZone: tz || undefined, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
      }).formatToParts(new Date()), o = {};
      parts.forEach(function (p) { o[p.type] = p.value; });
      return { day: DAY[o.weekday.toLowerCase()], min: +o.hour * 60 + +o.minute };
    } catch (err) {
      var d = new Date();
      return { day: d.getDay(), min: d.getHours() * 60 + d.getMinutes() };
    }
  }

  function clock(min) {
    return ('0' + Math.floor(min / 60)).slice(-2) + ':' + ('0' + min % 60).slice(-2);
  }

  function status(week, t) {
    var today = week[t.day];
    if (today && t.min >= today[0] && t.min < today[1]) return { open: true, note: 'נסגר ב-' + clock(today[1]) };
    if (today && t.min < today[0]) return { open: false, note: 'נפתח היום ב-' + clock(today[0]) };
    for (var i = 1; i <= 7; i++) {
      var d = (t.day + i) % 7;
      if (week[d]) return { open: false, note: (i === 1 ? 'נפתח מחר ב-' : 'נפתח ביום ' + NAMES[d] + ' ב-') + clock(week[d][0]) };
    }
    return { open: false, note: '' };
  }

  function setup(el) {
    if (el.__fxNeon) return;
    el.__fxNeon = true;
    var openText = el.getAttribute('data-open') || el.textContent.trim();
    var closedText = el.getAttribute('data-closed') || 'סגור';
    var week = parseHours(el.getAttribute('data-hours'));
    var note = el.parentNode ? el.parentNode.querySelector('.fx-neon__note') : null;
    var letters = [], shown = null, lit = false, timers = [];
    el.setAttribute('role', 'img');

    function write(text) {
      if (text === shown) return;
      shown = text;
      el.setAttribute('aria-label', text);
      el.textContent = '';
      letters = Array.from(text).map(function (ch) {
        var s = document.createElement('span');
        s.className = 'fx-neon__l';
        s.setAttribute('aria-hidden', 'true');
        s.textContent = ch;
        el.appendChild(s);
        return s;
      });
    }

    function refresh() {
      if (!week) { write(openText); return; }
      var s = status(week, now(el.getAttribute('data-tz')));
      el.setAttribute('data-state', s.open ? 'open' : 'closed');
      write(s.open ? openText : closedText);
      if (note) note.textContent = s.note;
    }

    // הדלקה: כמה הבהובים ואז אור יציב
    function ignite() {
      if (lit) return;
      lit = true;
      if (REDUCE) { el.classList.add('is-on'); return; }
      [0, 90, 150, 330, 380, 620, 670].forEach(function (ms, i) {
        timers.push(setTimeout(function () { el.classList.toggle('is-on', i % 2 === 0); }, ms));
      });
      timers.push(setTimeout(buzz, 3000));
    }
    // מדי פעם אות אחת מהבהבת, כמו צינור עייף
    function buzz() {
      if (!lit) return;
      var s = letters[Math.floor(Math.random() * letters.length)];
      if (s) {
        [0, 70, 130, 220].forEach(function (ms, i) {
          timers.push(setTimeout(function () { s.classList.toggle('is-out', i % 2 === 0); }, ms));
        });
      }
      timers.push(setTimeout(buzz, 3500 + Math.random() * 5000));
    }
    function sleep() {
      lit = false;
      timers.forEach(clearTimeout);
      timers = [];
      letters.forEach(function (s) { s.classList.remove('is-out'); });
    }

    refresh();
    if (week) setInterval(refresh, 30000);
    if (!('IntersectionObserver' in window)) { ignite(); return; }
    new IntersectionObserver(function (entries) {
      if (entries[entries.length - 1].isIntersecting) ignite(); else sleep();
    }, { threshold: 0.4 }).observe(el);
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-neon'), setup);
  }
  (window.FX = window.FX || {}).neon = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-price · מחירון */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var NS = 'http://www.w3.org/2000/svg';

  function scissors() {
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('class', 'fx-price__scissors');
    svg.setAttribute('viewBox', '0 0 64 40');
    svg.setAttribute('aria-hidden', 'true');
    svg.innerHTML =
      '<g class="fx-price__b"><path d="M22 18.4 60 19.5q2.2.7 0 1.5L22 21.8z"/>' +
      '<line x1="24" y1="19.6" x2="13.5" y2="13.4" stroke-width="4" stroke-linecap="round"/>' +
      '<circle cx="9" cy="9.8" r="6.2" stroke-width="3.6"/></g>' +
      '<g class="fx-price__a"><path d="M22 18.2 60 19.2q2.2.7 0 1.5L22 21.6z"/>' +
      '<line x1="24" y1="20.4" x2="13.5" y2="26.6" stroke-width="4" stroke-linecap="round"/>' +
      '<circle cx="9" cy="30.2" r="6.2" stroke-width="3.6"/></g>' +
      '<circle class="fx-price__screw" cx="26" cy="20" r="1.8"/>';
    return svg;
  }

  function amount(text) {
    var m = String(text).replace(/,/g, '').match(/\d+(\.\d+)?/);
    return m ? parseFloat(m[0]) : 0;
  }

  function setupRow(row, list, refresh) {
    var dots = row.querySelector('.fx-price__dots');
    if (!dots) return;
    dots.appendChild(scissors());
    var raf = 0, p = 0, selectable = list.hasAttribute('data-select');

    function set(v, a) {
      p = v;
      dots.style.setProperty('--p', v.toFixed(4));
      dots.style.setProperty('--a', a.toFixed(1));
    }
    // המספריים רצות לאורך הנקודות וגוזרות אותן
    function cut() {
      cancelAnimationFrame(raf);
      if (REDUCE) { set(1, 0); row.classList.add('is-cut'); return; }
      var w = dots.getBoundingClientRect().width, from = p, t0 = performance.now(), dur = 420 + w * 0.5;
      row.classList.add('is-cutting');
      (function tick(now) {
        var t = Math.min((now - t0) / dur, 1), v = from + (1 - from) * (1 - Math.pow(1 - t, 2));
        set(v, t < 1 ? 3 + Math.abs(Math.sin(v * w / 16)) * 22 : 0);
        if (t < 1) { raf = requestAnimationFrame(tick); return; }
        row.classList.remove('is-cutting');
        row.classList.add('is-cut');
      })(t0);
    }
    function regrow() {
      if (row.getAttribute('aria-checked') === 'true') return;
      cancelAnimationFrame(raf);
      row.classList.remove('is-cutting', 'is-cut');
      if (REDUCE) { set(0, 0); return; }
      var from = p, t0 = performance.now();
      (function tick(now) {
        var t = Math.min((now - t0) / 260, 1);
        set(from * (1 - t), 0);
        if (t < 1) raf = requestAnimationFrame(tick);
      })(t0);
    }

    row.addEventListener('pointerenter', function (e) { if (e.pointerType === 'mouse') cut(); });
    row.addEventListener('pointerleave', function (e) { if (e.pointerType === 'mouse') regrow(); });
    row.addEventListener('focus', cut);
    row.addEventListener('blur', regrow);

    if (!selectable) {
      row.addEventListener('pointerdown', function (e) { if (e.pointerType !== 'mouse') { cut(); setTimeout(regrow, 1400); } });
      return;
    }
    // data-select: לחיצה בוחרת את השורה ומעדכנת את הסכום
    row.setAttribute('role', 'checkbox');
    row.setAttribute('aria-checked', 'false');
    if (!row.hasAttribute('tabindex')) row.tabIndex = 0;
    function toggle() {
      var on = row.getAttribute('aria-checked') !== 'true';
      row.setAttribute('aria-checked', on ? 'true' : 'false');
      if (on) cut(); else regrow();
      refresh();
    }
    row.addEventListener('click', toggle);
    row.addEventListener('keydown', function (e) {
      if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); toggle(); }
    });
  }

  function setup(list) {
    if (list.__fxPrice) return;
    list.__fxPrice = true;
    if (getComputedStyle(list).direction === 'rtl') list.classList.add('fx-price--rtl');
    var rows = list.querySelectorAll('.fx-price__row');
    var totalEl = list.getAttribute('data-total') ? document.querySelector(list.getAttribute('data-total')) : null;
    var shown = 0, raf = 0, template = totalEl ? totalEl.textContent : '';

    // הסכום נספר למעלה או למטה עד הערך החדש
    function refresh() {
      var sum = 0;
      Array.prototype.forEach.call(rows, function (r) {
        if (r.getAttribute('aria-checked') !== 'true') return;
        var c = r.querySelector('.fx-price__cost');
        sum += c ? amount(c.textContent) : 0;
      });
      list.dispatchEvent(new CustomEvent('fx:price', { bubbles: true, detail: { total: sum } }));
      if (!totalEl) return;
      cancelAnimationFrame(raf);
      var from = shown, t0 = performance.now();
      function write(v) { totalEl.textContent = template.replace(/\d[\d,.]*/, String(Math.round(v))); }
      if (REDUCE) { shown = sum; write(sum); return; }
      (function tick(now) {
        var t = Math.min((now - t0) / 450, 1);
        shown = from + (sum - from) * (1 - Math.pow(1 - t, 3));
        write(shown);
        if (t < 1) raf = requestAnimationFrame(tick);
      })(t0);
    }
    Array.prototype.forEach.call(rows, function (row) { setupRow(row, list, refresh); });
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-price'), setup);
  }
  (window.FX = window.FX || {}).price = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-compare · לפני ואחרי */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  function make(tag, cls, text) {
    var n = document.createElement(tag);
    n.className = cls;
    if (text) n.textContent = text;
    return n;
  }

  function setup(root) {
    if (root.__fxCompare) return;
    root.__fxCompare = true;
    if (!root.querySelector('.fx-compare__before') || !root.querySelector('.fx-compare__after')) return;
    if (getComputedStyle(root).direction === 'rtl') root.classList.add('fx-compare--rtl');

    var handle = make('div', 'fx-compare__handle'), knob = make('span', 'fx-compare__knob');
    knob.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6 3.5 12 9 18M15 6l5.5 6-5.5 6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    handle.setAttribute('aria-hidden', 'true');
    handle.appendChild(knob);
    root.appendChild(handle);
    root.appendChild(make('span', 'fx-compare__label fx-compare__label--before', root.getAttribute('data-before') || 'לפני'));
    root.appendChild(make('span', 'fx-compare__label fx-compare__label--after', root.getAttribute('data-after') || 'אחרי'));

    // מחוון נסתר: מאפשר להזיז את הקו בחיצים במקלדת
    var range = make('input', 'fx-compare__range');
    range.type = 'range';
    range.min = 0;
    range.max = 100;
    range.dir = 'ltr';
    range.setAttribute('aria-label', root.getAttribute('data-label') || 'מיקום הקו בין לפני לאחרי');
    root.appendChild(range);

    var p = parseFloat(root.getAttribute('data-start')) || 50, touched = false, down = false, raf = 0;
    function set(v) {
      p = v < 0 ? 0 : v > 100 ? 100 : v;
      root.style.setProperty('--fx-compare-p', p.toFixed(2) + '%');
      range.value = Math.round(p);
    }
    function fromEvent(e) {
      var r = root.getBoundingClientRect();
      set((e.clientX - r.left) / r.width * 100);
    }
    function stop() { touched = true; cancelAnimationFrame(raf); }

    root.addEventListener('pointerdown', function (e) {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      stop();
      down = true;
      root.classList.add('is-dragging');
      try { root.setPointerCapture(e.pointerId); } catch (err) {}
      fromEvent(e);
    });
    root.addEventListener('pointermove', function (e) { if (down) fromEvent(e); });
    function up() { down = false; root.classList.remove('is-dragging'); }
    root.addEventListener('pointerup', up);
    root.addEventListener('pointercancel', up);
    range.addEventListener('input', function () { stop(); set(+range.value); });
    range.addEventListener('focus', function () { root.classList.add('is-focus'); });
    range.addEventListener('blur', function () { root.classList.remove('is-focus'); });
    set(p);

    // רמז קטן בכניסה למסך: הקו זז ימינה ושמאלה פעם אחת
    if (REDUCE || !('IntersectionObserver' in window)) return;
    var io = new IntersectionObserver(function (entries) {
      if (!entries[entries.length - 1].isIntersecting || touched) return;
      io.disconnect();
      var base = p, t0 = performance.now();
      (function tick(now) {
        var t = Math.min((now - t0) / 1700, 1);
        set(base + Math.sin(t * Math.PI * 2) * 14 * (1 - t * 0.4));
        if (t < 1 && !touched) raf = requestAnimationFrame(tick); else if (!touched) set(base);
      })(t0);
    }, { threshold: 0.6 });
    io.observe(root);
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-compare'), setup);
  }
  (window.FX = window.FX || {}).compare = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-snip · מספריים גוזרות */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var NS = 'http://www.w3.org/2000/svg';
  var items = [], queued = false;

  function scissors() {
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('class', 'fx-snip__scissors');
    svg.setAttribute('viewBox', '0 0 64 40');
    svg.setAttribute('aria-hidden', 'true');
    svg.innerHTML =
      '<g class="fx-snip__b"><path d="M22 18.4 60 19.5q2.2.7 0 1.5L22 21.8z"/>' +
      '<line x1="24" y1="19.6" x2="13.5" y2="13.4" stroke-width="4" stroke-linecap="round"/>' +
      '<circle cx="9" cy="9.8" r="6.2" stroke-width="3.6"/></g>' +
      '<g class="fx-snip__a"><path d="M22 18.2 60 19.2q2.2.7 0 1.5L22 21.6z"/>' +
      '<line x1="24" y1="20.4" x2="13.5" y2="26.6" stroke-width="4" stroke-linecap="round"/>' +
      '<circle cx="9" cy="30.2" r="6.2" stroke-width="3.6"/></g>' +
      '<circle class="fx-snip__screw" cx="26" cy="20" r="1.8"/>';
    return svg;
  }

  // p = כמה מהקו כבר נגזר (0 עד 1). הלהבים נפתחים ונסגרים לפי המרחק שעברו
  function place(st, p) {
    st.el.style.setProperty('--p', p.toFixed(4));
    st.el.style.setProperty('--a', (p >= 1 ? 0 : 3 + Math.abs(Math.sin(p * st.width / 34)) * 22).toFixed(1));
  }

  function update() {
    queued = false;
    var vh = window.innerHeight;
    items.forEach(function (st) {
      if (!st.visible || st.mode !== 'scroll') return;
      var r = st.el.getBoundingClientRect();
      st.width = r.width;
      var p = (vh * st.start - (r.top + r.height / 2)) / (vh * (st.start - st.end));
      place(st, p < 0 ? 0 : p > 1 ? 1 : p);
    });
  }
  function queue() {
    if (!queued) { queued = true; requestAnimationFrame(update); }
  }

  function play(st) {
    cancelAnimationFrame(st.raf);
    st.width = st.el.getBoundingClientRect().width;
    if (REDUCE) { place(st, 1); return; }
    var t0 = performance.now();
    (function tick(now) {
      var t = Math.min((now - t0) / st.duration, 1);
      place(st, t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
      if (t < 1) st.raf = requestAnimationFrame(tick);
    })(t0);
  }

  function setup(el) {
    if (el.__fxSnip) return;
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var st = el.__fxSnip = {
      el: el, visible: true, width: 600, raf: 0,
      mode: el.getAttribute('data-on') || 'scroll',   // scroll: לפי הגלילה. view: פעם אחת כשנכנס למסך
      start: num('data-start', 0.9),                  // באיזה גובה במסך הגזירה מתחילה (0 למעלה, 1 למטה)
      end: num('data-end', 0.4),                      // באיזה גובה היא נגמרת
      duration: num('data-duration', 1400)            // משך הגזירה במצב view, במילישניות
    };
    if (getComputedStyle(el).direction === 'rtl') el.classList.add('fx-snip--rtl');
    el.setAttribute('aria-hidden', 'true');
    el.appendChild(scissors());
    el.fxSnip = { play: function () { play(st); } };
    items.push(st);

    if (REDUCE) { place(st, st.mode === 'scroll' ? 0 : 1); return; }
    if ('IntersectionObserver' in window) {
      var seen = false;
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible && st.mode === 'view' && !seen) { seen = true; play(st); }
        queue();
      }, { threshold: st.mode === 'view' ? 0.6 : 0 }).observe(el);
    }
    queue();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-snip'), setup);
  }
  window.addEventListener('scroll', queue, { passive: true, capture: true });
  window.addEventListener('resize', queue);
  (window.FX = window.FX || {}).snip = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-chair · כיסא מסתובב */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  function setup(root) {
    if (root.__fxChair) return;
    var front = root.querySelector('.fx-chair__front'), back = root.querySelector('.fx-chair__back');
    if (!front || !back) return;
    root.__fxChair = true;
    var a = 0, v = 0, target = null, raf = 0, down = false, moved = 0, lastX = 0, pid = -1;
    var turns = parseFloat(root.getAttribute('data-turns')) || 1;   // כמה חצאי סיבוב בלחיצה: 1 הופך צד, 3 מסתובב יותר

    if (!root.hasAttribute('tabindex')) root.tabIndex = 0;
    root.setAttribute('role', 'button');
    if (!root.hasAttribute('aria-label')) root.setAttribute('aria-label', root.getAttribute('data-label') || 'סיבוב הכרטיס');

    function faces() {
      var isBack = Math.abs(Math.round(a / 180)) % 2 === 1;
      root.setAttribute('aria-pressed', isBack ? 'true' : 'false');
      root.classList.toggle('is-back', isBack);
      if ('inert' in front) { front.inert = isBack; back.inert = !isBack; }
    }
    function apply() { root.style.setProperty('--fx-chair-a', a.toFixed(2) + 'deg'); }

    function frame() {
      raf = 0;
      if (target !== null) {                       // קפיץ שמיישר אל הצד הקרוב
        v = (v + (target - a) * 0.07) * 0.84;
        a += v;
        if (Math.abs(target - a) < 0.15 && Math.abs(v) < 0.15) { a = target; v = 0; target = null; apply(); faces(); return; }
      } else if (!down) {                          // ממשיך להסתובב מהתנופה ומאט
        a += v;
        v *= 0.955;
        if (Math.abs(v) < 1.5) target = Math.round(a / 180) * 180;
      }
      apply();
      raf = requestAnimationFrame(frame);
    }
    function wake() { if (!raf) raf = requestAnimationFrame(frame); }

    function flip() {
      if (REDUCE) {
        a = (Math.round(a / 180) + 1) * 180;
        root.classList.add('is-flat');
        faces();
        return;
      }
      target = (Math.round(a / 180) + (turns % 2 ? turns : turns + 1)) * 180;
      wake();
    }

    root.addEventListener('pointerdown', function (e) {
      if ((e.pointerType === 'mouse' && e.button !== 0) || e.target.closest('a, button, input, select, textarea')) return;
      down = true;
      pid = e.pointerId;
      moved = 0;
      lastX = e.clientX;
    });
    root.addEventListener('pointermove', function (e) {
      if (!down || e.pointerId !== pid || REDUCE) return;
      var dx = e.clientX - lastX;
      lastX = e.clientX;
      moved += Math.abs(dx);
      if (moved < 6) return;
      if (!root.classList.contains('is-dragging')) {
        root.classList.add('is-dragging');
        try { root.setPointerCapture(pid); } catch (err) {}
      }
      target = null;
      a += dx * 0.6;
      v = v * 0.5 + dx * 0.6 * 0.5;
      wake();
    });
    function up(e) {
      if (!down || (e && e.pointerId !== pid)) return;
      down = false;
      root.classList.remove('is-dragging');
      if (moved < 6 && e && e.type === 'pointerup') flip(); else wake();
    }
    root.addEventListener('pointerup', up);
    root.addEventListener('pointercancel', up);
    root.addEventListener('keydown', function (e) {
      if (e.target !== root || (e.key !== 'Enter' && e.key !== ' ')) return;
      e.preventDefault();
      flip();
    });
    root.fxChair = { flip: flip };
    faces();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-chair'), setup);
  }
  (window.FX = window.FX || {}).chair = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-punch · כרטיסיית ניקובים */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  function setup(root) {
    if (root.__fxPunch) return;
    root.__fxPunch = true;
    function num(name, d) { var v = parseInt(root.getAttribute(name), 10); return isNaN(v) ? d : v; }
    var total = Math.max(2, num('data-total', 10));        // כמה משבצות בכרטיסייה
    var start = Math.min(num('data-done', 0), total);      // כמה כבר נוקבו
    var reward = root.getAttribute('data-reward') || 'חינם';
    var done = 0, slots = [], grid = document.createElement('ol');

    grid.className = 'fx-punch__grid';
    grid.setAttribute('aria-hidden', 'true');
    for (var i = 0; i < total; i++) {
      var li = document.createElement('li');
      li.className = 'fx-punch__slot' + (i === total - 1 ? ' fx-punch__slot--reward' : '');
      li.textContent = i === total - 1 ? reward : i + 1;
      grid.appendChild(li);
      slots.push(li);
    }
    root.appendChild(grid);
    var status = document.createElement('p');
    status.style.cssText = 'position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap';
    status.setAttribute('role', 'status');
    root.appendChild(status);

    function label() { status.textContent = done + ' מתוך ' + total + (done === total ? '. ' + reward : ''); }

    // עיגול נייר קטן שעף מהחור
    function chad(slot, burst) {
      if (REDUCE || !slot.animate) return;
      var c = document.createElement('span');
      c.className = 'fx-punch__chad';
      c.style.color = getComputedStyle(root).backgroundColor;
      slot.appendChild(c);
      var dx = (Math.random() - 0.5) * (burst ? 220 : 50), dy = burst ? -60 - Math.random() * 90 : 70 + Math.random() * 40;
      c.animate([
        { transform: 'translate(0,0) rotate(0deg) scale(' + (burst ? 0.5 : 1) + ')', opacity: 1 },
        { transform: 'translate(' + dx * 0.6 + 'px,' + (burst ? dy : dy * 0.3) + 'px) rotate(140deg) scale(' + (burst ? 0.5 : 0.9) + ')', opacity: 1, offset: 0.5 },
        { transform: 'translate(' + dx + 'px,' + (burst ? 90 : dy) + 'px) rotate(320deg) scale(' + (burst ? 0.4 : 0.7) + ')', opacity: 0 }
      ], { duration: burst ? 900 : 620, easing: 'cubic-bezier(.3,.6,.6,1)' }).onfinish = function () { c.remove(); };
    }

    function punch() {
      if (done >= total) return false;
      var slot = slots[done];
      done++;
      slot.classList.add('is-done');
      label();
      if (!REDUCE && root.animate) {
        root.animate([{ transform: 'translateY(0)' }, { transform: 'translateY(3px) scale(.995)' }, { transform: 'translateY(0)' }], { duration: 160 });
      }
      if (done === total) {
        root.classList.add('is-full');
        for (var k = 0; k < 12; k++) chad(slot, true);
        root.dispatchEvent(new CustomEvent('fx:punch-full', { bubbles: true }));
      } else {
        chad(slot, false);
      }
      return true;
    }
    function reset() {
      done = 0;
      root.classList.remove('is-full');
      slots.forEach(function (s) { s.classList.remove('is-done'); });
      label();
    }
    root.fxPunch = { punch: punch, reset: reset };
    label();

    // בכניסה למסך הניקובים הקיימים נעשים אחד אחרי השני
    function fill() {
      for (var k = 0; k < start; k++) setTimeout(punch, REDUCE ? 0 : 250 + k * 150);
    }
    if (REDUCE || !('IntersectionObserver' in window)) { fill(); return; }
    var io = new IntersectionObserver(function (entries) {
      if (!entries[entries.length - 1].isIntersecting) return;
      io.disconnect();
      fill();
    }, { threshold: 0.5 });
    io.observe(root);
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-punch'), setup);
  }
  (window.FX = window.FX || {}).punch = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-foam · קצף גילוח */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var RAZOR = '<svg viewBox="0 0 48 48"><rect x="20.5" y="13" width="7" height="32" rx="3.5" fill="#1b1c21"/>' +
    '<path d="M20.5 22h7M20.5 26h7M20.5 30h7" stroke="#8f96a3" stroke-width="1.4"/>' +
    '<rect x="4" y="4" width="40" height="11" rx="4" fill="#c9ced6" stroke="#1b1c21" stroke-width="1.6"/>' +
    '<path d="M8 9.5h32" stroke="#1b1c21" stroke-width="1.6" stroke-linecap="round"/></svg>';

  function setup(root) {
    if (root.__fxFoam) return;
    var canvas = document.createElement('canvas'), ctx = canvas.getContext('2d');
    if (!ctx) return;
    root.__fxFoam = true;
    function num(name, d) { var v = parseFloat(root.getAttribute(name)); return isNaN(v) ? d : v; }
    var size = num('data-size', 46);      // רוחב הפס שהסכין מנקה, בפיקסלים
    var goal = num('data-goal', 0.6);     // איזה חלק צריך לגלח עד שהקצף נעלם לבד (0 עד 1)
    var cell = 14, W = 0, H = 0, dpr = 1, cols = 0, rows = 0, grid = null, cleared = 0;
    var clean = false, playing = false, last = null;

    canvas.className = 'fx-foam__canvas';
    canvas.setAttribute('aria-hidden', 'true');
    var razor = document.createElement('span');
    razor.className = 'fx-foam__razor';
    razor.setAttribute('aria-hidden', 'true');
    razor.innerHTML = RAZOR;
    root.appendChild(canvas);
    root.appendChild(razor);

    // מצייר קצף: רקע בהיר ומעליו הרבה בועות רכות
    function paint() {
      W = root.clientWidth;
      H = root.clientHeight;
      if (!W || !H) return;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = '#f6f7f5';
      ctx.fillRect(0, 0, W, H);
      for (var i = 0, n = Math.round(W * H / 420); i < n; i++) {
        var x = Math.random() * W, y = Math.random() * H, r = 9 + Math.random() * 22;
        var g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.35, r * 0.1, x, y, r);
        g.addColorStop(0, 'rgba(255,255,255,.95)');
        g.addColorStop(0.65, 'rgba(240,243,246,.85)');
        g.addColorStop(1, 'rgba(190,201,214,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, 6.2832);
        ctx.fill();
      }
      cols = Math.ceil(W / cell);
      rows = Math.ceil(H / cell);
      grid = new Uint8Array(cols * rows);
      cleared = 0;
    }

    // מוחק פס של קצף בין שתי נקודות, וסופר כמה כבר נוקה
    function wipe(x0, y0, x1, y1) {
      if (!grid) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.globalCompositeOperation = 'destination-out';
      ctx.lineCap = ctx.lineJoin = 'round';
      ctx.lineWidth = size;
      ctx.shadowColor = '#000';
      ctx.shadowBlur = 5 * dpr;
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.lineTo(x1 + 0.01, y1);
      ctx.stroke();
      ctx.shadowBlur = 0;
      var dx = x1 - x0, dy = y1 - y0, steps = Math.max(1, Math.ceil(Math.sqrt(dx * dx + dy * dy) / (cell * 0.5))), rr = size / 2;
      for (var s = 0; s <= steps; s++) {
        var px = x0 + dx * s / steps, py = y0 + dy * s / steps;
        var c0 = Math.max(0, Math.floor((px - rr) / cell)), c1 = Math.min(cols - 1, Math.floor((px + rr) / cell));
        var r0 = Math.max(0, Math.floor((py - rr) / cell)), r1 = Math.min(rows - 1, Math.floor((py + rr) / cell));
        for (var r = r0; r <= r1; r++) {
          for (var c = c0; c <= c1; c++) {
            var ex = (c + 0.5) * cell - px, ey = (r + 0.5) * cell - py;
            if (ex * ex + ey * ey <= rr * rr && !grid[r * cols + c]) { grid[r * cols + c] = 1; cleared++; }
          }
        }
      }
      if (!clean && cleared / grid.length >= goal) finish();
    }

    function finish() {
      if (clean) return;
      clean = true;
      last = null;
      root.classList.remove('is-foamy', 'is-shaving');
      root.classList.add('is-clean');
      root.removeAttribute('role');
      root.removeAttribute('tabindex');
      root.removeAttribute('aria-label');
      root.dispatchEvent(new CustomEvent('fx:foam-clean', { bubbles: true }));
    }

    function reset() {
      clean = playing = false;
      root.classList.remove('is-clean');
      root.classList.add('is-foamy');
      root.setAttribute('role', 'button');
      root.tabIndex = 0;
      root.setAttribute('aria-label', root.getAttribute('data-label') || 'קצף גילוח. גלחו אותו כדי לגלות מה מתחתיו');
      paint();
    }

    function place(p) { razor.style.transform = 'translate(' + p.x.toFixed(1) + 'px,' + p.y.toFixed(1) + 'px)'; }
    function local(e) {
      var r = canvas.getBoundingClientRect();
      return { x: e.clientX - r.left, y: e.clientY - r.top };
    }

    // גילוח אוטומטי בזיגזג: למקלדת, ולמי שקורא ל-fxFoam.play()
    function play() {
      if (clean || playing) return;
      if (REDUCE) { finish(); return; }
      var lanes = Math.max(2, Math.ceil(H / (size * 0.8))), dur = 480 * lanes, t0 = performance.now(), prev = null;
      playing = true;
      root.classList.add('is-shaving');
      (function tick(now) {
        if (clean || !playing) return;
        var t = Math.min((now - t0) / dur, 1), f = t * lanes, lane = Math.min(lanes - 1, Math.floor(f)), u = f - lane;
        u = u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2;
        var p = { x: (lane % 2 ? 1 - u : u) * W, y: (lane + 0.5) / lanes * H };
        place(p);
        if (prev && Math.abs(prev.y - p.y) < 1) wipe(prev.x, prev.y, p.x, p.y);
        prev = p;
        if (t < 1) requestAnimationFrame(tick); else finish();
      })(t0);
    }

    root.addEventListener('pointerenter', function (e) {
      if (!clean && !REDUCE && e.pointerType === 'mouse') root.classList.add('is-shaving');
    });
    root.addEventListener('pointerleave', function () {
      last = null;
      if (!playing) root.classList.remove('is-shaving');
    });
    root.addEventListener('pointerdown', function (e) {
      if (clean) return;
      if (REDUCE) { finish(); return; }
      var p = local(e);
      last = p;
      place(p);
      root.classList.add('is-shaving');
      wipe(p.x, p.y, p.x, p.y);
    });
    root.addEventListener('pointermove', function (e) {
      if (clean || REDUCE) return;
      var p = local(e);
      place(p);
      // עם עכבר מגלחים בתנועה בלי ללחוץ. באצבע מגלחים כל עוד היא על המסך
      if (e.pointerType !== 'mouse' && !last) return;
      if (last) wipe(last.x, last.y, p.x, p.y);
      last = clean ? null : p;
    });
    function lift(e) {
      if (e.pointerType === 'mouse') return;
      last = null;
      if (!playing) root.classList.remove('is-shaving');
    }
    root.addEventListener('pointerup', lift);
    root.addEventListener('pointercancel', lift);
    root.addEventListener('keydown', function (e) {
      if (clean || e.target !== root || (e.key !== 'Enter' && e.key !== ' ')) return;
      e.preventDefault();
      play();
    });

    var lastW = 0;
    if ('ResizeObserver' in window) {
      new ResizeObserver(function () {
        if (root.clientWidth === lastW) return;
        lastW = root.clientWidth;
        if (!clean) paint();
      }).observe(root);
    }
    root.fxFoam = { play: play, reset: reset, clear: finish };
    reset();
    lastW = root.clientWidth;
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-foam'), setup);
  }
  (window.FX = window.FX || {}).foam = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-book · קביעת תור */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var DAY = { 'א': 0, 'ב': 1, 'ג': 2, 'ד': 3, 'ה': 4, 'ו': 5, 'ש': 6, sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 };
  var SHORT = ['א׳', 'ב׳', 'ג׳', 'ד׳', 'ה׳', 'ו׳', 'ש׳'];
  var FULL = ['ראשון', 'שני', 'שלישי', 'רביעי', 'חמישי', 'שישי', 'שבת'];
  // כל הטקסטים. אפשר להחליף חלק מהם ב-data-labels='{"send":"שלחו לי תור"}'
  var TEXT = {
    service: 'מה עושים?', day: 'באיזה יום?', time: 'באיזו שעה?',
    hint: 'בוחרים שירות, יום ושעה, והכרטיס מודפס כאן.',
    title: 'כרטיס תור', what: 'שירות', when: 'מתי', price: 'מחיר',
    today: 'היום', tomorrow: 'מחר', dayWord: 'יום', at: 'בשעה',
    send: 'שליחת הבקשה בוואטסאפ', pick: 'קודם בוחרים שירות, יום ושעה',
    message: 'היי, אשמח לקבוע תור: {service}, {day} בשעה {time}.'
  };

  function make(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  // "א-ה 09:00-20:00, ו 08:00-14:00" -> לכל יום בשבוע [דקת פתיחה, דקת סגירה] או null. אותו פורמט כמו בשלט הניאון
  function parseHours(text) {
    var week = [null, null, null, null, null, null, null], ok = false;
    String(text || '').split(/[,;]/).forEach(function (part) {
      var m = part.trim().toLowerCase().match(/^(\S{1,3}?)(?:\s*-\s*(\S{1,3}?))?\s+(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})$/);
      if (!m || !(m[1] in DAY)) return;
      var from = DAY[m[1]], to = m[2] in DAY ? DAY[m[2]] : from;
      for (var d = from; ; d = (d + 1) % 7) {
        week[d] = [+m[3] * 60 + +m[4], +m[5] * 60 + +m[6]];
        ok = true;
        if (d === to) break;
      }
    });
    return ok ? week : null;
  }
  function clock(min) {
    return ('0' + Math.floor(min / 60)).slice(-2) + ':' + ('0' + min % 60).slice(-2);
  }

  function setup(root) {
    if (root.__fxBook) return;
    root.__fxBook = true;
    var L = {}, key;
    for (key in TEXT) L[key] = TEXT[key];
    try {
      var custom = JSON.parse(root.getAttribute('data-labels') || '{}');
      for (key in custom) L[key] = custom[key];
    } catch (err) {}

    var phone = (root.getAttribute('data-phone') || '').replace(/\D/g, '');
    if (phone.length < 9) phone = '';                              // מספר חסר או לא מלא: בלי קישור
    var currency = root.getAttribute('data-currency') || '₪';
    var services = (root.getAttribute('data-services') || 'תספורת:70').split(',').map(function (s) {
      var p = s.split(':');
      return { name: p[0].trim(), price: parseFloat(p[1]) || 0 };
    }).filter(function (s) { return s.name; });
    // שעות הפתיחה לכל יום. יום שלא מופיע נחשב סגור
    var week = parseHours(root.getAttribute('data-hours')) || parseHours('א-ה 09:00-20:00, ו 09:00-14:00');
    var step = Math.max(5, parseInt(root.getAttribute('data-step'), 10) || 30);   // אורך תור בדקות
    var count = parseInt(root.getAttribute('data-days'), 10) || 5;                // כמה ימים קדימה להציג
    var state = { service: null, day: null, time: null };

    function days() {
      var out = [], d = new Date(), now = d.getHours() * 60 + d.getMinutes();
      for (var i = 0; out.length < count && i < 28; i++) {
        var x = new Date(d.getFullYear(), d.getMonth(), d.getDate() + i), h = week[x.getDay()];
        if (!h) continue;                                          // יום סגור
        // היום מתחילים מהתור הפנוי הבא, חצי שעה מעכשיו לפחות
        var first = i === 0 ? h[0] + Math.max(0, Math.ceil((now + 30 - h[0]) / step)) * step : h[0];
        if (first > h[1] - step) continue;                         // היום כבר נגמר
        var date = x.getDate() + '.' + (x.getMonth() + 1);
        out.push({
          first: first, last: h[1] - step, date: date,
          label: i === 0 ? L.today : i === 1 ? L.tomorrow : L.dayWord + ' ' + SHORT[x.getDay()],
          full: (i === 0 ? L.today : i === 1 ? L.tomorrow : L.dayWord + ' ' + FULL[x.getDay()]) + ' ' + date
        });
      }
      return out;
    }

    function group(title) {
      var set = make('fieldset', 'fx-book__step'), box = make('div', 'fx-book__chips');
      set.appendChild(make('legend', '', title));
      set.appendChild(box);
      root.appendChild(set);
      return box;
    }
    function chips(box, list, name, fill) {
      box.textContent = '';
      list.forEach(function (item, i) {
        var b = make('button', 'fx-book__chip');
        b.type = 'button';
        b.setAttribute('aria-pressed', 'false');
        b.style.setProperty('--i', i);
        fill(b, item);
        b.addEventListener('click', function () {
          state[name] = item;
          Array.prototype.forEach.call(box.children, function (c) { c.setAttribute('aria-pressed', c === b ? 'true' : 'false'); });
          if (name === 'day') { state.time = null; times(); }
          print();
        });
        box.appendChild(b);
      });
    }

    root.textContent = '';
    var boxService = group(L.service), boxDay = group(L.day), boxTime = group(L.time);
    var printer = make('div', 'fx-book__printer'), ticket = make('div', 'fx-book__ticket');
    var rows = {}, list = make('dl');
    printer.setAttribute('aria-live', 'polite');
    printer.appendChild(make('p', 'fx-book__hint', L.hint));
    ticket.appendChild(make('p', 'fx-book__title', L.title));
    [['what', L.what], ['when', L.when], ['price', L.price]].forEach(function (r) {
      var row = make('div');
      row.appendChild(make('dt', '', r[1]));
      rows[r[0]] = row.appendChild(make('dd', '', ' '));
      list.appendChild(row);
    });
    ticket.appendChild(list);
    printer.appendChild(ticket);
    root.appendChild(printer);

    // עם מספר טלפון הכפתור הוא קישור לוואטסאפ. בלי מספר הוא רק שולח אירוע fx:book
    var send = make(phone ? 'a' : 'button', 'fx-book__send', L.send);
    if (phone) { send.target = '_blank'; send.rel = 'noopener'; } else send.type = 'button';
    send.setAttribute('aria-disabled', 'true');
    root.appendChild(send);

    function times() {
      var slots = [];
      if (state.day) for (var t = state.day.first; t <= state.day.last; t += step) slots.push(t);
      chips(boxTime, slots, 'time', function (b, t) { b.textContent = clock(t); });
      boxTime.classList.remove('is-in');
      void boxTime.offsetWidth;
      boxTime.classList.add('is-in');
    }

    function details() {
      var when = state.day.full + ' ' + L.at + ' ' + clock(state.time);
      return {
        service: state.service.name, price: state.service.price, day: state.day.full, time: clock(state.time), when: when,
        message: L.message.replace('{service}', state.service.name).replace('{day}', state.day.full).replace('{time}', clock(state.time))
      };
    }

    // כשכל שלוש הבחירות מלאות הכרטיס מודפס
    function print() {
      var ready = !!(state.service && state.day && state.time != null);
      send.setAttribute('aria-disabled', ready ? 'false' : 'true');
      if (!ready) {
        root.classList.remove('is-printed');
        if (phone) send.removeAttribute('href');
        return;
      }
      var d = details();
      rows.what.textContent = d.service;
      rows.when.textContent = d.when;
      rows.price.textContent = currency + d.price;
      if (phone) send.href = 'https://wa.me/' + phone + '?text=' + encodeURIComponent(d.message);
      root.classList.remove('is-printed');
      void ticket.offsetWidth;
      root.classList.add('is-printed');
    }

    send.addEventListener('click', function (e) {
      if (send.getAttribute('aria-disabled') === 'true') {
        e.preventDefault();
        printer.querySelector('.fx-book__hint').textContent = L.pick;
        return;
      }
      root.dispatchEvent(new CustomEvent('fx:book', { bubbles: true, detail: details() }));
      if (REDUCE || !ticket.animate) return;
      // הכרטיס נתלש ויורד
      ticket.animate([
        { transform: 'translateY(0) rotate(0deg)', opacity: 1 },
        { transform: 'translateY(46px) rotate(3deg)', opacity: 0 }
      ], { duration: 520, easing: 'cubic-bezier(.5,0,.8,.4)' }).onfinish = function () {
        root.classList.remove('is-printed');
        void ticket.offsetWidth;
        root.classList.add('is-printed');
      };
    });

    chips(boxService, services, 'service', function (b, s) {
      b.appendChild(document.createTextNode(s.name));
      if (s.price) b.appendChild(make('small', '', currency + s.price));
    });
    var open_days = days();
    chips(boxDay, open_days, 'day', function (b, d) {
      b.appendChild(document.createTextNode(d.label));
      b.appendChild(make('small', '', d.date));
    });
    // היום הפנוי הראשון נבחר מראש, כדי שהשעות יופיעו מיד
    if (open_days.length) {
      state.day = open_days[0];
      boxDay.firstChild.setAttribute('aria-pressed', 'true');
    }
    times();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-book'), setup);
  }
  (window.FX = window.FX || {}).book = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();
