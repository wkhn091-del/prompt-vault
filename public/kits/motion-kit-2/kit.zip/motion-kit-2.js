/* fx-lines · שורות עולות */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var LAT = /[A-Za-z]/, HEB = /[א-תء-ي]/, DIG = /[0-9]/, TAIL = /[.,;:!?]+$/;
  var JOIN = String.fromCharCode(8288);          // תו שמונע שבירת שורה בין מילה לסימן הפיסוק שלה

  function word(text) {
    var outer = document.createElement('span'), inner = document.createElement('span');
    outer.className = 'fx-lines__w';
    inner.textContent = text;
    outer.appendChild(inner);
    return outer;
  }

  // עוטף כל מילה. רצף של מילים בכיוון ההפוך (אנגלית בתוך עברית) נעטף יחד, כדי שהסדר שלהן לא יתהפך
  function split(el) {
    var rtl = getComputedStyle(el).direction === 'rtl';
    var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null), nodes = [], n;
    while ((n = walker.nextNode())) if (n.nodeValue.trim()) nodes.push(n);
    var kind = function (w) { return LAT.test(w) ? (HEB.test(w) ? 'M' : 'L') : HEB.test(w) ? 'R' : DIG.test(w) ? 'D' : 'N'; };
    nodes.forEach(function (node) {
      var parts = node.nodeValue.split(/(\s+)/).filter(function (p) { return p !== ''; });
      var frag = document.createDocumentFragment(), i = 0;
      while (i < parts.length) {
        var p = parts[i];
        if (/^\s+$/.test(p)) { frag.appendChild(document.createTextNode(p)); i++; continue; }
        // מחפשים רצף בכיוון ההפוך: לפחות שתי מילים, ולפחות אחת מהן באותיות
        var j = i, count = 0, strong = 0, last = i;
        while (j < parts.length) {
          if (/^\s+$/.test(parts[j])) { j++; continue; }
          var k = kind(parts[j]);
          if (rtl ? (k === 'L' || k === 'D') : (k === 'R' || (k === 'D' && count > 0))) { count++; if (k !== 'D') strong++; last = j; j++; } else break;
        }
        if (!rtl) while (last > i && kind(parts[last]) === 'D') { last--; count--; }      // מספר בסוף רצף עברי נשאר בחוץ
        if (count >= 2 && strong >= 1) {
          var run = document.createElement('span');
          run.className = rtl ? 'fx-lines__ltr' : 'fx-lines__rtl';
          var tail = parts[last].match(TAIL);
          if (tail) {
            // סימן פיסוק בסוף הרצף מוצג בצד של השפה הראשית, כמו בטקסט רגיל
            parts[last] = parts[last].slice(0, -tail[0].length);
            run.appendChild(word(tail[0]));
            run.appendChild(document.createTextNode(JOIN));
          }
          for (var t = i; t <= last; t++) run.appendChild(/^\s+$/.test(parts[t]) ? document.createTextNode(parts[t]) : word(parts[t]));
          frag.appendChild(run);
          i = last + 1;
        } else {
          frag.appendChild(word(p));
          i++;
        }
      }
      node.parentNode.replaceChild(frag, node);
    });
    return Array.prototype.slice.call(el.querySelectorAll('.fx-lines__w'));
  }

  // קובע לכל מילה את מספר השורה שלה, וזה מה שיוצר את ההשהיה
  function number(st) {
    var line = -1, top = null, byWord = st.by === 'word';
    st.words.forEach(function (w, i) {
      var r = w.getBoundingClientRect();
      if (top === null || Math.abs(r.top - top) > r.height * 0.5) { line++; top = r.top; }
      w.firstChild.style.setProperty('--i', byWord ? i : line);
    });
  }

  function setup(el) {
    if (el.__fxLines || REDUCE) return;
    var st = el.__fxLines = { by: el.getAttribute('data-by') || 'line', words: split(el) };
    var delay = parseFloat(el.getAttribute('data-delay'));
    if (!isNaN(delay)) el.style.setProperty('--fx-lines-delay', delay + 'ms');
    number(st);
    var once = el.getAttribute('data-once') !== 'false';
    function show() { el.classList.remove('is-out'); el.classList.add('is-in'); }
    function hide() { el.classList.add('is-out'); el.classList.remove('is-in'); }
    el.fxLines = { play: function () { hide(); void el.offsetWidth; show(); }, reset: hide };
    if ('ResizeObserver' in window) {
      var width = 0;
      new ResizeObserver(function (en) { var w = en[0].contentRect.width; if (Math.abs(w - width) > 1) { width = w; number(st); } }).observe(el);
    }
    if (!('IntersectionObserver' in window)) { show(); return; }
    var io = new IntersectionObserver(function (entries) {
      var e = entries[entries.length - 1];
      if (e.isIntersecting) { show(); if (once) io.disconnect(); }
      else if (!once) hide();
    }, { threshold: 0.15, rootMargin: '0px 0px -8% 0px' });
    io.observe(el);
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-lines'), setup);
  }
  (window.FX = window.FX || {}).lines = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-scramble · פענוח */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  // כל תו מתחלף רק באותיות מאותו סוג, וכך הכיוון והרוחב של הטקסט כמעט לא זזים
  var HEB = 'אבגדהוזחטיכלמנסעפצקרשת', UP = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', LOW = 'abcdefghijklmnopqrstuvwxyz', DIG = '0123456789';
  function setOf(ch) { return /[א-ת]/.test(ch) ? HEB : /[A-Z]/.test(ch) ? UP : /[a-z]/.test(ch) ? LOW : /[0-9]/.test(ch) ? DIG : null; }
  function pick(set) { return set.charAt(Math.floor(Math.random() * set.length)); }

  function setup(el) {
    if (el.__fxScramble) return;
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var words = (el.getAttribute('data-words') || '').split('|').map(function (w) { return w.trim(); }).filter(Boolean);
    var text = document.createElement('span'), v = document.createElement('span');
    text.className = 'fx-scramble__text';
    text.textContent = el.textContent.replace(/\s+/g, ' ').trim();
    v.className = 'fx-scramble__v';
    v.setAttribute('aria-hidden', 'true');
    el.textContent = '';
    el.appendChild(text);
    el.appendChild(v);
    var st = el.__fxScramble = {
      speed: num('data-speed', 45),            // מילישניות לכל אות
      max: num('data-duration', 1400),         // תקרה למשך הכולל, כדי שפסקה ארוכה לא תימשך לנצח
      interval: num('data-interval', 2600),    // כמה זמן מילה נשארת לפני שמתחלפת
      index: Math.max(0, words.indexOf(text.textContent)), raf: 0, timer: 0, visible: false
    };

    function run(to) {
      cancelAnimationFrame(st.raf);
      if (to !== text.textContent && words.length) {
        // מילה ברוחב אחר: הרוחב מחליק לגודל החדש
        var w0 = el.getBoundingClientRect().width;
        text.textContent = to;
        el.style.width = 'auto';
        var w1 = el.getBoundingClientRect().width;
        if (Math.abs(w1 - w0) > 0.5 && !REDUCE) {
          el.style.width = w0 + 'px';
          void el.offsetWidth;
          el.style.width = w1 + 'px';
        } else {
          el.style.width = '';
        }
      } else {
        text.textContent = to;
      }
      if (REDUCE) return;
      var chars = Array.from(to), step = Math.min(st.speed, st.max / Math.max(1, chars.length));
      var ends = chars.map(function (c, i) { return i * step + Math.random() * step * 3; });
      var total = Math.max.apply(null, ends), start = performance.now(), swap = 0, shown = chars.map(function (c) { var s = setOf(c); return s ? pick(s) : c; });
      el.classList.add('is-busy');
      (function frame(now) {
        var t = now - start, fresh = now >= swap;
        if (fresh) swap = now + 45;
        for (var i = 0; i < chars.length; i++) {
          if (t >= ends[i]) shown[i] = chars[i];
          else if (fresh) { var s = setOf(chars[i]); if (s) shown[i] = pick(s); }
        }
        v.textContent = shown.join('');
        if (t < total) st.raf = requestAnimationFrame(frame);
        else { el.classList.remove('is-busy'); el.dispatchEvent(new CustomEvent('fx:scramble', { bubbles: true, detail: { text: to } })); }
      })(start);
    }
    function cycle() {
      clearTimeout(st.timer);
      if (words.length < 2 || !st.visible) return;
      st.timer = setTimeout(function () { st.index = (st.index + 1) % words.length; run(words[st.index]); cycle(); }, st.interval);
    }
    el.fxScramble = {
      play: function () { run(text.textContent); },
      to: function (next) { run(String(next)); }
    };
    if (el.getAttribute('data-on') === 'hover') el.addEventListener('pointerenter', function () { run(text.textContent); });
    el.addEventListener('transitionend', function (e) { if (e.propertyName === 'width') el.style.width = ''; });
    if (getComputedStyle(el).display === 'inline') el.style.display = 'inline-block';      // כדי שהשכבה המתחלפת תשב בדיוק מעל הטקסט

    var delay = num('data-delay', 0), played = false;
    if (!('IntersectionObserver' in window)) { st.visible = true; run(text.textContent); cycle(); return; }
    new IntersectionObserver(function (entries) {
      st.visible = entries[entries.length - 1].isIntersecting;
      if (st.visible && !played) { played = true; setTimeout(function () { run(text.textContent); }, delay); }
      cycle();
    }, { threshold: 0.4 }).observe(el);
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-scramble'), setup);
  }
  (window.FX = window.FX || {}).scramble = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-doodle · קשקוש בטוש */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var NS = 'http://www.w3.org/2000/svg';

  // אקראיות עם זרע קבוע: אותה מילה מקבלת תמיד אותו קשקוש
  function rng(seed) {
    var s = seed >>> 0;
    return function () { s = (s + 0x6D2B79F5) | 0; var t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function hash(text) { var h = 2166136261; for (var i = 0; i < text.length; i++) { h ^= text.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  // קו חלק דרך רשימת נקודות
  function smooth(p) {
    var d = 'M' + p[0][0].toFixed(1) + ' ' + p[0][1].toFixed(1);
    for (var i = 1; i < p.length - 1; i++) d += 'Q' + p[i][0].toFixed(1) + ' ' + p[i][1].toFixed(1) + ' ' + ((p[i][0] + p[i + 1][0]) / 2).toFixed(1) + ' ' + ((p[i][1] + p[i + 1][1]) / 2).toFixed(1);
    var last = p[p.length - 1];
    return d + 'L' + last[0].toFixed(1) + ' ' + last[1].toFixed(1);
  }

  // הצורות. w,h גודל המילה, px,py השוליים שמסביב, r מספר אקראי. מצוירות משמאל לימין, ובעברית הן מתהפכות
  var SHAPES = {
    underline: function (w, h, px, py, r) {
      var y = py + h * 0.94, j = function (a) { return (r() - 0.5) * 2 * a; };
      return [smooth([[px * 0.5, y + j(2)], [px + w * 0.3, y + h * 0.05 + j(h * 0.04)], [px + w * 0.7, y - h * 0.02 + j(h * 0.04)], [px * 1.5 + w, y + j(2)],
        [px + w * 0.75, y + h * 0.1 + j(2)], [px + w * 0.45, y + h * 0.13 + j(h * 0.03)], [px + w * 0.2, y + h * 0.1 + j(2)]])];
    },
    circle: function (w, h, px, py, r) {
      var cx = px + w / 2, cy = py + h / 2 + h * 0.03, rx = w / 2 + px * 0.72, ry = h / 2 + py * 0.35, pts = [], n = 46, turns = 1.13, a0 = -2.5 + r() * 0.5, ph = r() * 6.28;
      for (var i = 0; i <= n; i++) {
        var t = i / n, a = a0 + t * turns * 6.2832, k = 0.97 + t * 0.09 + 0.03 * Math.sin(a * 2 + ph);
        pts.push([cx + Math.cos(a) * rx * k, cy + Math.sin(a) * ry * k]);
      }
      return [smooth(pts)];
    },
    box: function (w, h, px, py, r) {
      var j = function (a) { return (r() - 0.5) * 2 * a; }, x0 = px * 0.35, x1 = px * 1.65 + w, y0 = py * 0.45, y1 = py * 1.5 + h;
      return [smooth([[x0 - 3, y0 + j(2)], [(x0 + x1) / 2, y0 + j(3)], [x1 + 2, y0 + j(2)], [x1 + j(2), y0], [x1 + j(3), (y0 + y1) / 2], [x1 + j(2), y1 + 2], [x1, y1 + j(2)],
        [(x0 + x1) / 2, y1 + j(3)], [x0 - 2, y1 + j(2)], [x0 + j(2), y1], [x0 + j(3), (y0 + y1) / 2], [x0 + j(2), y0 - 4]])];
    },
    strike: function (w, h, px, py, r) {
      var y = py + h * 0.56, j = function (a) { return (r() - 0.5) * 2 * a; };
      return [smooth([[px * 0.4, y + h * 0.04 + j(2)], [px + w * 0.5, y + j(h * 0.05)], [px * 1.6 + w, y - h * 0.05 + j(2)]])];
    },
    highlight: function (w, h, px, py, r) {
      var y = py + h * 0.57, j = function (a) { return (r() - 0.5) * 2 * a; };
      return [smooth([[px * 0.75, y + j(2)], [px + w * 0.5, y + j(h * 0.05)], [px * 1.25 + w, y + j(2)]])];
    }
  };

  function draw(st) {
    var el = st.el, r = el.getBoundingClientRect(), fs = parseFloat(getComputedStyle(el).fontSize) || 16;
    if (!r.width || !r.height) return;
    var w = r.width, h = r.height, px = fs * 0.3, py = fs * 0.16, W = w + px * 2, H = h + py * 2;
    var shape = SHAPES[st.shape] ? st.shape : 'underline', rand = rng(st.seed), rtl = getComputedStyle(el).direction === 'rtl';
    var svg = st.svg;
    svg.setAttribute('viewBox', '0 0 ' + W.toFixed(1) + ' ' + H.toFixed(1));
    svg.style.cssText = 'left:' + (-px).toFixed(1) + 'px;top:' + (-py).toFixed(1) + 'px;width:' + W.toFixed(1) + 'px;height:' + H.toFixed(1) + 'px';
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    var raw = getComputedStyle(el).getPropertyValue('--fx-doodle-width').trim(), num = parseFloat(raw);
    var width = shape === 'highlight' ? h * 0.66 : Math.max(1.5, isNaN(num) ? fs * 0.07 : /px$/.test(raw) ? num : num * fs);
    SHAPES[shape](w, h, px, py, rand).forEach(function (d) {
      var p = document.createElementNS(NS, 'path');
      p.setAttribute('d', d);
      if (rtl) p.setAttribute('transform', 'translate(' + W.toFixed(1) + ' 0) scale(-1 1)');      // בעברית מציירים מימין לשמאל
      p.setAttribute('stroke-width', width.toFixed(2));
      svg.appendChild(p);
      var len = Math.ceil(p.getTotalLength()) + 2;
      p.style.strokeDasharray = len;
      p.style.strokeDashoffset = len;
    });
  }

  function setup(el) {
    if (el.__fxDoodle) return;
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('class', 'fx-doodle__svg');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    el.appendChild(svg);
    var text = el.textContent, shape = el.getAttribute('data-shape') || 'underline';
    var st = el.__fxDoodle = { el: el, svg: svg, shape: shape, seed: hash(text + shape + (el.getAttribute('data-seed') || '')) };
    var delay = parseFloat(el.getAttribute('data-delay'));
    if (!isNaN(delay)) el.style.setProperty('--fx-doodle-delay', delay + 'ms');
    function redraw() { el.classList.add('is-still'); draw(st); void el.offsetWidth; if (!REDUCE) el.classList.remove('is-still'); }
    redraw();
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(redraw);
    if ('ResizeObserver' in window) new ResizeObserver(redraw).observe(el);
    var once = el.getAttribute('data-once') !== 'false';
    el.fxDoodle = { play: function () { el.classList.add('is-still'); el.classList.remove('is-in'); void el.offsetWidth; el.classList.remove('is-still'); el.classList.add('is-in'); }, redraw: redraw };
    if (REDUCE || !('IntersectionObserver' in window)) { el.classList.add('is-in'); return; }
    var io = new IntersectionObserver(function (entries) {
      var e = entries[entries.length - 1];
      if (e.isIntersecting) { el.classList.add('is-in'); if (once) io.disconnect(); }
      else if (!once) { el.classList.add('is-still'); el.classList.remove('is-in'); void el.offsetWidth; el.classList.remove('is-still'); }
    }, { threshold: 0.9, rootMargin: '0px 0px -6% 0px' });
    io.observe(el);
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-doodle'), setup);
  }
  (window.FX = window.FX || {}).doodle = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-marquee · פס רץ */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var items = [], raf = 0, last = 0, scrollY = window.pageYOffset, speedY = 0;

  function build(st) {
    var el = st.el, track = st.track;
    while (track.children.length > 1) track.removeChild(track.lastChild);
    st.size = st.group.getBoundingClientRect().width;
    if (!st.size) return;
    // משכפלים את הקבוצה עד שהפס מכסה את הרוחב ועוד קבוצה אחת, וכך הלולאה לא נגמרת
    var need = Math.ceil(el.getBoundingClientRect().width / st.size) + 1;
    for (var i = 0; i < need; i++) {
      var copy = st.group.cloneNode(true);
      copy.setAttribute('aria-hidden', 'true');
      Array.prototype.forEach.call(copy.querySelectorAll('a, button, input, [tabindex]'), function (n) { n.setAttribute('tabindex', '-1'); });
      track.appendChild(copy);
    }
  }

  function frame(now) {
    raf = 0;
    var dt = Math.min(0.05, (now - last) / 1000 || 0.016), busy = false;
    last = now;
    // מהירות הגלילה מאיצה את הפס, ואז דועכת
    var y = window.pageYOffset, vy = (y - scrollY) / dt;
    scrollY = y;
    speedY += (vy - speedY) * Math.min(1, dt * 8);
    items.forEach(function (st) {
      if (!st.visible || !st.size || st.paused) return;
      busy = true;
      var boost = st.scroll ? speedY * st.scroll * 0.35 : 0;
      if (st.flip && Math.abs(boost) > 30) st.sign = boost > 0 ? 1 : -1;        // גלילה למעלה הופכת את הכיוון
      var v = (st.speed + Math.abs(boost)) * st.sign * st.dir;
      st.x = ((st.x + v * dt) % st.size + st.size) % st.size;
      st.track.style.transform = 'translate3d(' + (-st.x).toFixed(2) + 'px,0,0)';
    });
    if (busy) raf = requestAnimationFrame(frame);
  }
  function wake() { if (!raf) { last = performance.now(); scrollY = window.pageYOffset; raf = requestAnimationFrame(frame); } }

  function setup(el) {
    if (el.__fxMarquee) return;
    if (REDUCE) { el.__fxMarquee = true; el.classList.add('is-still'); return; }
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var rtl = getComputedStyle(el).direction === 'rtl';
    var track = document.createElement('div'), group = document.createElement('div');
    track.className = 'fx-marquee__track';
    group.className = 'fx-marquee__group';
    group.style.direction = rtl ? 'rtl' : 'ltr';
    el.style.direction = 'ltr';                  // החישוב תמיד משמאל לימין. הפריטים עצמם שומרים על הכיוון שלהם
    while (el.firstChild) group.appendChild(el.firstChild);
    track.appendChild(group);
    el.appendChild(track);
    var st = el.__fxMarquee = {
      el: el, track: track, group: group, x: 0, size: 0, visible: false, paused: false, sign: 1,
      speed: num('data-speed', 70),                               // פיקסלים בשנייה
      scroll: num('data-scroll', 1),                              // כמה הגלילה מאיצה את הפס. 0 מבטל
      flip: el.getAttribute('data-flip') !== 'false',             // גלילה למעלה הופכת כיוון
      // בעברית הפס נע ימינה (טקסט חדש נכנס משמאל), באנגלית שמאלה. data-dir="reverse" הופך
      dir: (rtl ? -1 : 1) * (el.getAttribute('data-dir') === 'reverse' ? -1 : 1)
    };
    build(st);
    items.push(st);
    if (el.getAttribute('data-pause') === 'hover') {
      el.addEventListener('pointerenter', function (e) { if (e.pointerType === 'mouse') st.paused = true; });
      el.addEventListener('pointerleave', function () { st.paused = false; wake(); });
    }
    if ('ResizeObserver' in window) new ResizeObserver(function () { build(st); wake(); }).observe(el);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { build(st); });
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) { st.visible = entries[entries.length - 1].isIntersecting; if (st.visible) wake(); }, { rootMargin: '100px 0px' }).observe(el);
    } else { st.visible = true; wake(); }
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-marquee'), setup);
  }
  (window.FX = window.FX || {}).marquee = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-burst · קונפטי */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var COLORS = ['#e5432b', '#ffd21f', '#1d4ce0', '#19b37a', '#ff8ad8', '#ffffff'];
  var canvas = null, ctx = null, parts = [], raf = 0, last = 0, dpr = 1;

  function size() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(window.innerWidth * dpr);
    canvas.height = Math.round(window.innerHeight * dpr);
  }
  function ensure() {
    if (canvas) return;
    canvas = document.createElement('canvas');
    canvas.className = 'fx-burst-canvas';
    canvas.setAttribute('aria-hidden', 'true');
    document.body.appendChild(canvas);
    ctx = canvas.getContext('2d');
    size();
    window.addEventListener('resize', size);
  }

  // יורה קונפטי מנקודה על המסך. אפשר לקרוא לזה גם מהקוד: FX.burst.fire(x, y)
  function fire(x, y, o) {
    if (REDUCE) return;
    ensure();
    o = o || {};
    var n = Math.min(o.count || 70, 400), spread = (o.spread == null ? 80 : o.spread) * Math.PI / 180, angle = (o.angle == null ? -90 : o.angle) * Math.PI / 180;
    var power = o.power || 1, colors = o.colors && o.colors.length ? o.colors : COLORS;
    for (var i = 0; i < n; i++) {
      var a = angle + (Math.random() - 0.5) * spread, v = (420 + Math.random() * 760) * power;
      parts.push({
        x: x, y: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v,
        w: 6 + Math.random() * 7, h: 4 + Math.random() * 6, rot: Math.random() * 6.28, vr: (Math.random() - 0.5) * 14,
        tilt: Math.random() * 6.28, vt: 5 + Math.random() * 9, sway: 20 + Math.random() * 40,
        color: colors[Math.floor(Math.random() * colors.length)], shape: i % 5 === 0 ? 1 : i % 7 === 0 ? 2 : 0,
        life: 0, ttl: 1.5 + Math.random() * 1.3
      });
    }
    if (parts.length > 900) parts.splice(0, parts.length - 900);
    if (!raf) { last = performance.now(); raf = requestAnimationFrame(frame); }
  }

  function frame(now) {
    var dt = Math.min(0.034, (now - last) / 1000 || 0.016), W = window.innerWidth, H = window.innerHeight;
    last = now;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    for (var i = parts.length - 1; i >= 0; i--) {
      var p = parts[i];
      p.life += dt;
      // התנגדות אוויר חזקה בהתחלה, ואחר כך נפילה איטית ומתנדנדת כמו נייר
      p.vx *= 1 - Math.min(1, 2.4 * dt);
      p.vy = p.vy * (1 - Math.min(1, 2.4 * dt)) + 1500 * dt;
      if (p.vy > 300) p.vy = 300;
      p.tilt += p.vt * dt;
      p.rot += p.vr * dt;
      p.x += (p.vx + Math.sin(p.tilt) * p.sway) * dt;
      p.y += p.vy * dt;
      if (p.life > p.ttl || p.y > H + 40) { parts.splice(i, 1); continue; }
      ctx.globalAlpha = Math.min(1, (p.ttl - p.life) / 0.35);
      ctx.fillStyle = p.color;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      ctx.scale(1, Math.cos(p.tilt));
      if (p.shape === 1) { ctx.beginPath(); ctx.arc(0, 0, p.h * 0.75, 0, 6.2832); ctx.fill(); }
      else if (p.shape === 2) ctx.fillRect(-p.w, -1.5, p.w * 2, 3);
      else ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      ctx.restore();
    }
    ctx.globalAlpha = 1;
    raf = parts.length ? requestAnimationFrame(frame) : 0;
  }

  function options(el) {
    function num(name) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? null : v; }
    var colors = (el.getAttribute('data-colors') || '').split(',').map(function (c) { return c.trim(); }).filter(Boolean);
    return { count: num('data-count'), spread: num('data-spread'), angle: num('data-angle'), power: num('data-power'), colors: colors };
  }
  function from(el, e) {
    var r = el.getBoundingClientRect(), mouse = e && (e.clientX || e.clientY);
    fire(mouse ? e.clientX : r.left + r.width / 2, mouse ? e.clientY : r.top + r.height / 2, options(el));
  }

  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('.fx-burst') : null;
    if (!el || el.disabled || el.getAttribute('data-on') === 'view') return;
    from(el, e);
  });

  // data-on="view": יורה פעם אחת כשהאלמנט נכנס למסך (למשל הודעת "ההזמנה התקבלה")
  function init(scope) {
    if (!('IntersectionObserver' in window)) return;
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-burst[data-on="view"]'), function (el) {
      if (el.__fxBurst) return;
      el.__fxBurst = true;
      var io = new IntersectionObserver(function (entries) {
        if (!entries[entries.length - 1].isIntersecting) return;
        from(el);
        io.disconnect();
      }, { threshold: 0.8 });
      io.observe(el);
    });
  }
  init.fire = fire;
  (window.FX = window.FX || {}).burst = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-theme · מעבר צבע בעיגול */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var uid = 0, busy = false;

  function targetOf(btn) {
    var sel = btn.getAttribute('data-target');
    return (sel && document.querySelector(sel)) || document.documentElement;
  }
  function sync(target) {
    var dark = target.getAttribute('data-theme') === 'dark';
    Array.prototype.forEach.call(document.querySelectorAll('.fx-theme'), function (b) { if (targetOf(b) === target) b.setAttribute('aria-pressed', String(dark)); });
  }
  function apply(btn, dark) {
    var target = targetOf(btn), key = btn.getAttribute('data-save');
    target.setAttribute('data-theme', dark ? 'dark' : 'light');
    sync(target);
    if (key) { try { localStorage.setItem(key, dark ? 'dark' : 'light'); } catch (err) {} }
    btn.dispatchEvent(new CustomEvent('fx:theme', { bubbles: true, detail: { theme: dark ? 'dark' : 'light' } }));
  }

  function toggle(btn) {
    if (busy) return;
    var dark = targetOf(btn).getAttribute('data-theme') !== 'dark';
    if (REDUCE || !document.startViewTransition) { apply(btn, dark); return; }
    var r = btn.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
    var radius = Math.hypot(Math.max(x, window.innerWidth - x), Math.max(y, window.innerHeight - y));
    var time = parseFloat(btn.getAttribute('data-duration')) || 700, root = document.documentElement;
    busy = true;
    root.classList.add('fx-theme-run');
    var done = function () { root.classList.remove('fx-theme-run'); busy = false; };
    var vt;
    try { vt = document.startViewTransition(function () { apply(btn, dark); }); } catch (err) { apply(btn, dark); done(); return; }
    vt.ready.then(function () {
      root.animate({ clipPath: ['circle(0px at ' + x + 'px ' + y + 'px)', 'circle(' + Math.ceil(radius) + 'px at ' + x + 'px ' + y + 'px)'] },
        { duration: time, easing: 'cubic-bezier(.4, 0, .2, 1)', pseudoElement: '::view-transition-new(root)' });
    }, function () {});
    vt.finished.then(done, done);
  }

  function setup(btn) {
    if (btn.__fxTheme) return;
    btn.__fxTheme = true;
    var id = 'fx-theme-m' + (++uid), rays = '';
    for (var i = 0; i < 8; i++) rays += '<line x1="12" y1="1.2" x2="12" y2="3.6" transform="rotate(' + i * 45 + ' 12 12)"/>';
    btn.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><mask id="' + id + '"><rect x="-12" y="-12" width="48" height="48" fill="#fff" stroke="none"/><circle class="fx-theme__cut" cx="16.5" cy="7.5" r="5.2" fill="#000" stroke="none"/></mask>' +
      '<circle class="fx-theme__core" cx="12" cy="12" r="5" stroke="none" mask="url(#' + id + ')"/><g class="fx-theme__rays" fill="none" stroke-width="2" stroke-linecap="round">' + rays + '</g></svg>';
    var target = targetOf(btn), key = btn.getAttribute('data-save'), saved = null;
    if (key) { try { saved = localStorage.getItem(key); } catch (err) {} }
    if (saved === 'dark' || saved === 'light') target.setAttribute('data-theme', saved);
    else if (!target.hasAttribute('data-theme')) target.setAttribute('data-theme', btn.hasAttribute('data-auto') && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    sync(target);
    btn.addEventListener('click', function () { toggle(btn); });
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-theme'), setup);
  }
  (window.FX = window.FX || {}).theme = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-torch · פנס */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var items = [], raf = 0, last = 0;

  function frame(now) {
    raf = 0;
    var dt = Math.min(0.05, (now - last) / 1000 || 0.016), busy = false;
    last = now;
    items.forEach(function (st) {
      if (!st.visible) return;
      busy = true;
      // בלי עכבר (או אחרי שהוא נח) הפנס מטייל לבד, כדי שגם במסך מגע יראו שיש מה לגלות
      if (st.idle && now - st.moved > 1800) {
        var t = now / 1000;
        st.tx = st.w * (0.5 + 0.34 * Math.cos(t * 0.55 + st.phase));
        st.ty = st.h * (0.5 + 0.3 * Math.sin(t * 0.83 + st.phase));
      }
      var k = 1 - Math.exp(-dt * st.ease);
      st.x += (st.tx - st.x) * k;
      st.y += (st.ty - st.y) * k;
      st.el.style.setProperty('--fx-torch-x', st.x.toFixed(1) + 'px');
      st.el.style.setProperty('--fx-torch-y', st.y.toFixed(1) + 'px');
    });
    if (busy) raf = requestAnimationFrame(frame);
  }
  function wake() { if (!raf) { last = performance.now(); raf = requestAnimationFrame(frame); } }

  function setup(el) {
    if (el.__fxTorch) return;
    if (REDUCE) { el.__fxTorch = true; el.classList.add('is-off'); return; }
    var ease = parseFloat(el.getAttribute('data-ease'));
    var st = el.__fxTorch = { el: el, w: 1, h: 1, x: 0, y: 0, tx: 0, ty: 0, moved: -1e9, visible: false, phase: Math.random() * 6.28,
      idle: el.getAttribute('data-idle') !== 'false',           // הפנס מטייל לבד כשלא נוגעים
      ease: isNaN(ease) ? 9 : ease };                           // כמה מהר האלומה רודפת אחרי הסמן
    function measure() { var r = el.getBoundingClientRect(); st.w = r.width; st.h = r.height; }
    measure();
    st.x = st.tx = st.w / 2; st.y = st.ty = st.h / 2;
    function move(e) {
      var r = el.getBoundingClientRect();
      st.tx = e.clientX - r.left; st.ty = e.clientY - r.top;
      st.moved = performance.now();
      wake();
    }
    el.addEventListener('pointermove', move, { passive: true });
    el.addEventListener('pointerdown', move, { passive: true });
    el.addEventListener('pointerleave', function (e) { if (e.pointerType === 'mouse') st.moved = performance.now() - 1200; });
    if ('ResizeObserver' in window) new ResizeObserver(measure).observe(el);
    items.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) { st.visible = entries[entries.length - 1].isIntersecting; if (st.visible) wake(); }).observe(el);
    } else { st.visible = true; wake(); }
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-torch'), setup);
  }
  (window.FX = window.FX || {}).torch = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-peek · רשימה מציצה */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var COARSE = window.matchMedia && matchMedia('(hover: none), (pointer: coarse)').matches;

  function setup(list) {
    if (list.__fxPeek) return;
    var rows = Array.prototype.slice.call(list.querySelectorAll('[data-img]'));
    list.__fxPeek = true;
    if (!rows.length) return;
    if (COARSE) {
      rows.forEach(function (row) {
        var img = document.createElement('img');
        img.className = 'fx-peek__thumb';
        img.src = row.getAttribute('data-img');
        img.alt = '';
        img.loading = 'lazy';
        row.appendChild(img);
      });
      return;
    }
    var box = document.createElement('div');
    box.className = 'fx-peek__box';
    box.setAttribute('aria-hidden', 'true');
    var imgs = rows.map(function (row) {
      var img = document.createElement('img');
      img.src = row.getAttribute('data-img');
      img.alt = '';
      box.appendChild(img);
      return img;
    });
    list.appendChild(box);
    var tilt = parseFloat(list.getAttribute('data-tilt'));
    var st = { x: 0, y: 0, tx: 0, ty: 0, vx: 0, s: 0.6, on: false, raf: 0, last: 0, first: true,
      tilt: isNaN(tilt) ? 12 : tilt };                   // כמה התמונה נוטה בזמן תנועה, במעלות
    var rtl = getComputedStyle(list).direction === 'rtl';

    function frame(now) {
      st.raf = 0;
      var dt = Math.min(0.05, (now - st.last) / 1000 || 0.016), k = REDUCE ? 1 : 1 - Math.exp(-dt * 10);
      st.last = now;
      var px = st.x;
      st.x += (st.tx - st.x) * k; st.y += (st.ty - st.y) * k;
      st.vx += ((st.x - px) / dt - st.vx) * Math.min(1, dt * 8);
      st.s += ((st.on ? 1 : 0.6) - st.s) * (REDUCE ? 1 : 1 - Math.exp(-dt * 12));
      var rot = REDUCE ? 0 : Math.max(-st.tilt, Math.min(st.tilt, st.vx * 0.012));
      box.style.transform = 'translate(' + st.x.toFixed(1) + 'px,' + st.y.toFixed(1) + 'px) translate(-50%,-50%) rotate(' + rot.toFixed(2) + 'deg) scale(' + st.s.toFixed(3) + ')';
      if (Math.abs(st.tx - st.x) > 0.3 || Math.abs(st.ty - st.y) > 0.3 || Math.abs(st.vx) > 2 || Math.abs((st.on ? 1 : 0.6) - st.s) > 0.004) st.raf = requestAnimationFrame(frame);
    }
    function wake() { if (!st.raf) { st.last = performance.now(); st.raf = requestAnimationFrame(frame); } }
    function aim(x, y) {
      var r = list.getBoundingClientRect(), w = box.offsetWidth, h = box.offsetHeight;
      // התמונה נשארת בתוך רוחב הרשימה, כדי שלא תיצור גלילה לצד
      st.tx = Math.max(w / 2, Math.min(r.width - w / 2, x - r.left));
      st.ty = Math.max(0, Math.min(r.height, y - r.top));
      if (st.first) { st.x = st.tx; st.y = st.ty; st.first = false; }
      wake();
    }
    function activate(row) {
      rows.forEach(function (r, i) { var on = r === row; r.classList.toggle('is-active', on); imgs[i].classList.toggle('is-on', on); });
      st.on = !!row;
      list.classList.toggle('is-on', st.on);
      wake();
    }
    list.addEventListener('pointermove', function (e) {
      if (e.pointerType !== 'mouse') return;
      var row = e.target.closest('[data-img]');
      aim(e.clientX + (rtl ? -1 : 1) * box.offsetWidth * 0.2, e.clientY);
      if (row !== (rows.filter(function (r) { return r.classList.contains('is-active'); })[0] || null)) activate(row && list.contains(row) ? row : null);
    }, { passive: true });
    list.addEventListener('pointerleave', function () { activate(null); st.first = true; });
    // מקלדת: התמונה מופיעה ליד השורה שבפוקוס
    list.addEventListener('focusin', function (e) {
      var row = e.target.closest('[data-img]');
      if (!row) return;
      var r = row.getBoundingClientRect();
      aim(rtl ? r.left + box.offsetWidth * 0.6 : r.right - box.offsetWidth * 0.6, r.top + r.height / 2);
      activate(row);
    });
    list.addEventListener('focusout', function () { activate(null); st.first = true; });
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-peek'), setup);
  }
  (window.FX = window.FX || {}).peek = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-rail · גלילה אופקית */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var items = [], raf = 0;

  function update(st) {
    var r = st.root.getBoundingClientRect(), total = r.height - st.pin.offsetHeight;
    var p = total > 0 ? Math.max(0, Math.min(1, -r.top / total)) : 0, x = p * st.dist;
    st.track.style.transform = 'translate3d(' + (st.rtl ? x : -x).toFixed(1) + 'px,0,0)';
    st.root.style.setProperty('--fx-rail-p', p.toFixed(4));
    if (st.manual) st.pin.style.transform = 'translateY(' + Math.max(0, Math.min(total, -r.top)).toFixed(1) + 'px)';
  }
  function frame() {
    raf = 0;
    items.forEach(function (st) { if (st.visible) update(st); });
  }
  function wake() { if (!raf) raf = requestAnimationFrame(frame); }

  function setup(root) {
    if (root.__fxRail) return;
    var track = root.querySelector('.fx-rail__track');
    if (!track) return;
    var pin = document.createElement('div'), bar = document.createElement('div');
    pin.className = 'fx-rail__pin';
    bar.className = 'fx-rail__bar';
    bar.setAttribute('aria-hidden', 'true');
    root.insertBefore(pin, track);
    pin.appendChild(track);
    pin.appendChild(bar);
    var rtl = getComputedStyle(root).direction === 'rtl';
    if (rtl) root.classList.add('fx-rail--rtl');
    root.__fxRail = true;
    if (REDUCE || root.getAttribute('data-mode') === 'native') { root.classList.add('is-native'); return; }

    var speed = parseFloat(root.getAttribute('data-speed'));
    var st = { root: root, pin: pin, track: track, rtl: rtl, dist: 0, visible: false, manual: false,
      speed: isNaN(speed) || speed <= 0 ? 1 : speed };       // 1 = פיקסל הצידה על כל פיקסל של גלילה. 2 מהיר פי שניים
    // אב שגולל או חותך מבטל הצמדה רגילה. אז מצמידים ידנית
    for (var p = root.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      var o = getComputedStyle(p);
      if (/(auto|scroll|hidden)/.test(o.overflowY + o.overflowX)) { st.manual = true; pin.classList.add('is-manual'); break; }
    }
    function measure() {
      st.dist = Math.max(0, track.offsetWidth - pin.clientWidth);
      root.style.height = Math.round(pin.offsetHeight + st.dist / st.speed) + 'px';
      update(st);
    }
    measure();
    window.addEventListener('resize', measure);
    if ('ResizeObserver' in window) new ResizeObserver(measure).observe(track);
    // פוקוס ממקלדת על פריט שמחוץ למסך: גוללים עד שהוא נראה
    track.addEventListener('focusin', function (e) {
      var item = e.target.closest('.fx-rail__track > *');
      if (!item || !st.dist) return;
      var t = track.getBoundingClientRect(), i = item.getBoundingClientRect();
      var offset = st.rtl ? t.right - i.right : i.left - t.left;
      var want = Math.max(0, Math.min(st.dist, offset - (pin.clientWidth - i.width) / 2));
      window.scrollTo({ top: root.getBoundingClientRect().top + window.pageYOffset + want / st.speed, behavior: 'auto' });
    });
    items.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) { st.visible = entries[entries.length - 1].isIntersecting; wake(); }).observe(root);
    } else st.visible = true;
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-rail'), setup);
  }
  window.addEventListener('scroll', wake, { passive: true });
  (window.FX = window.FX || {}).rail = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-stack · קלפים נערמים */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var items = [], raf = 0;

  function update(st) {
    var cards = st.cards, n = cards.length, covered = [], i;
    for (i = 0; i < n; i++) {
      var r = cards[i].getBoundingClientRect();
      // כמה הקלף הזה כבר כיסה את הקודם: 0 כשהוא רק מגיע, 1 כשהוא יושב עליו
      if (i === 0) { covered.push(0); continue; }
      var start = st.tops[i - 1] + st.heights[i - 1] + st.gap, end = st.tops[i];
      covered.push(Math.max(0, Math.min(1, (start - r.top) / Math.max(1, start - end))));
    }
    for (i = 0; i < n; i++) {
      var depth = 0;
      for (var j = i + 1; j < n; j++) depth += covered[j];
      cards[i].style.setProperty('--fx-stack-s', (1 - depth * st.scale).toFixed(4));
      cards[i].style.setProperty('--fx-stack-b', (1 - Math.min(0.6, depth * st.dim)).toFixed(3));
    }
  }
  function frame() {
    raf = 0;
    items.forEach(function (st) { if (st.visible) update(st); });
  }
  function wake() { if (!raf) raf = requestAnimationFrame(frame); }

  function setup(root) {
    if (root.__fxStack) return;
    var cards = Array.prototype.slice.call(root.children);
    function num(name, d) { var v = parseFloat(root.getAttribute(name)); return isNaN(v) ? d : v; }
    var st = root.__fxStack = { cards: cards, tops: [], heights: [], gap: 0, visible: false,
      scale: num('data-scale', 0.045),          // כמה קלף מתכווץ על כל קלף שנערם עליו
      dim: num('data-dim', 0.1) };              // כמה הוא מתכהה
    cards.forEach(function (c, i) { c.style.setProperty('--fx-stack-i', i); });
    for (var p = root.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      var o = getComputedStyle(p);
      if (/(auto|scroll|hidden)/.test(o.overflowY + o.overflowX)) { root.classList.add('is-flat'); return; }
    }
    if (REDUCE) return;                          // הקלפים עדיין נערמים, רק בלי ההתכווצות
    function measure() {
      st.gap = parseFloat(getComputedStyle(root).rowGap) || 0;
      st.tops = cards.map(function (c) { return parseFloat(getComputedStyle(c).top) || 0; });
      st.heights = cards.map(function (c) { return c.offsetHeight; });
      wake();
    }
    measure();
    if ('ResizeObserver' in window) new ResizeObserver(measure).observe(root);
    items.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) { st.visible = entries[entries.length - 1].isIntersecting; wake(); }, { rootMargin: '20% 0px' }).observe(root);
    } else st.visible = true;
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-stack'), setup);
  }
  window.addEventListener('scroll', wake, { passive: true });
  window.addEventListener('resize', wake);
  (window.FX = window.FX || {}).stack = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-glow · כרטיסים עם הילה */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var COARSE = window.matchMedia && matchMedia('(hover: none), (pointer: coarse)').matches;

  function setup(root) {
    if (root.__fxGlow || REDUCE) return;
    var cards = Array.prototype.slice.call(root.querySelectorAll('.fx-glow__card'));
    var st = root.__fxGlow = { x: 0, y: 0, raf: 0, visible: false, hover: false };
    // כל כרטיס מקבל את מיקום האור ביחס לעצמו, וכך גם המסגרות של השכנים נדלקות כשהעכבר מתקרב
    function paint() {
      st.raf = 0;
      for (var i = 0; i < cards.length; i++) {
        var r = cards[i].getBoundingClientRect();
        cards[i].style.setProperty('--fx-glow-x', (st.x - r.left).toFixed(1) + 'px');
        cards[i].style.setProperty('--fx-glow-y', (st.y - r.top).toFixed(1) + 'px');
      }
    }
    function at(x, y) { st.x = x; st.y = y; if (!st.raf) st.raf = requestAnimationFrame(paint); }
    root.addEventListener('pointermove', function (e) {
      if (e.pointerType !== 'mouse') return;
      st.hover = true;
      root.style.setProperty('--fx-glow-o', '1');
      at(e.clientX, e.clientY);
    }, { passive: true });
    root.addEventListener('pointerleave', function () { st.hover = false; if (!roam) root.style.setProperty('--fx-glow-o', '0'); });
    window.addEventListener('scroll', function () { if (st.hover) at(st.x, st.y); }, { passive: true });

    // במסך מגע (או עם data-idle="true") האור מטייל לבד על הכרטיסים
    var roam = root.hasAttribute('data-idle') ? root.getAttribute('data-idle') !== 'false' : COARSE;
    if (!roam) return;
    root.style.setProperty('--fx-glow-o', '1');
    var loop = 0;
    function tick(now) {
      loop = 0;
      if (!st.visible) return;
      if (!st.hover) {
        var r = root.getBoundingClientRect(), t = now / 1000;
        at(r.left + r.width * (0.5 + 0.42 * Math.cos(t * 0.5)), r.top + r.height * (0.5 + 0.38 * Math.sin(t * 0.8)));
      }
      loop = requestAnimationFrame(tick);
    }
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) { st.visible = entries[entries.length - 1].isIntersecting; if (st.visible && !loop) loop = requestAnimationFrame(tick); }).observe(root);
    } else { st.visible = true; loop = requestAnimationFrame(tick); }
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-glow'), setup);
  }
  (window.FX = window.FX || {}).glow = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-orbit · טבעת תלת־ממדית */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var items = [], raf = 0, last = 0;

  function place(st) {
    var n = st.cards.length, r = st.radius;
    st.ring.style.transform = 'translateZ(' + (-r).toFixed(1) + 'px) rotateX(' + st.tilt + ') rotateY(' + st.angle.toFixed(3) + 'deg)';
    for (var i = 0; i < n; i++) {
      // הכרטיסים מקיפים את המרכז ותמיד פונים אלינו. face: 1 מלפנים, 1- מאחור
      var world = st.base[i] + st.angle, face = Math.cos(world * Math.PI / 180);
      st.cards[i].style.transform = 'translate(-50%,-50%) rotateY(' + st.base[i].toFixed(3) + 'deg) translateZ(' + r.toFixed(1) + 'px) rotateY(' + (-world).toFixed(3) + 'deg)';
      // רק הכרטיסים שמאחור מתעמעמים. אלה שמלפנים אטומים, כדי שלא יראו דרכם
      var k = Math.max(0, Math.min(1, (face + 1) / 1.2));
      st.cards[i].style.opacity = (st.fade + (1 - st.fade) * k * k * (3 - 2 * k)).toFixed(3);
      st.cards[i].style.pointerEvents = face > 0 ? '' : 'none';
    }
  }
  function nearest(st) { return Math.round(st.angle / st.step) * st.step; }

  function frame(now) {
    raf = 0;
    var dt = Math.min(0.05, (now - last) / 1000 || 0.016), busy = false;
    last = now;
    items.forEach(function (st) {
      if (!st.visible) return;
      if (st.drag) { busy = true; place(st); return; }
      if (Math.abs(st.v) > 4) {
        // תנופה אחרי שחרור
        st.angle += st.v * dt;
        st.v *= Math.pow(0.04, dt);
        st.target = null;
        busy = true;
      } else if (st.target != null) {
        // מתיישר על הכרטיס הקרוב
        st.v = 0;
        var d = st.target - st.angle;
        st.angle += d * (REDUCE ? 1 : 1 - Math.exp(-dt * 7));
        if (Math.abs(d) < 0.02) { st.angle = st.target; st.target = null; }
        busy = true;
      } else if (st.auto && !st.hold && now > st.rest) {
        st.angle += st.auto * st.dir * dt;
        busy = true;
      } else if (st.snapPending) {
        st.snapPending = false;
        st.target = nearest(st);
        busy = true;
      } else if (st.auto) busy = true;
      place(st);
    });
    if (busy) raf = requestAnimationFrame(frame);
  }
  function wake() { if (!raf) { last = performance.now(); raf = requestAnimationFrame(frame); } }

  function setup(root) {
    if (root.__fxOrbit) return;
    var cards = Array.prototype.slice.call(root.children);
    if (cards.length < 3) return;
    function num(name, d) { var v = parseFloat(root.getAttribute(name)); return isNaN(v) ? d : v; }
    var rtl = getComputedStyle(root).direction === 'rtl', ring = document.createElement('div');
    ring.className = 'fx-orbit__ring';
    cards.forEach(function (c) { ring.appendChild(c); });
    root.appendChild(ring);
    root.classList.add('is-on');
    if (!root.hasAttribute('role')) root.setAttribute('role', 'group');
    root.setAttribute('aria-roledescription', 'קרוסלה');
    var n = cards.length, step = 360 / n, side = rtl ? -1 : 1;
    var st = root.__fxOrbit = {
      root: root, ring: ring, cards: cards, step: step, base: cards.map(function (c, i) { return i * step * side; }),
      angle: 0, v: 0, target: null, radius: 300, tilt: '0deg', fade: 0.45, drag: null, visible: false, hold: false, rest: 0, snapPending: false,
      dir: -side,                                             // לאן הטבעת מסתובבת לבד
      auto: REDUCE ? 0 : num('data-auto', 9)                  // מעלות לשנייה. 0 מבטל את הסיבוב העצמי
    };
    function measure() {
      var w = cards[0].offsetWidth, gap = parseFloat(getComputedStyle(root).getPropertyValue('--fx-orbit-gap')) || 0, h = 0;
      if (/rem$/.test(getComputedStyle(root).getPropertyValue('--fx-orbit-gap').trim())) gap *= parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
      cards.forEach(function (c) { h = Math.max(h, c.offsetHeight); });
      // הרדיוס: מספיק כדי שהכרטיסים לא יעלו זה על זה, ורחב יותר כשיש מקום
      st.radius = Math.max((w + gap) / (2 * Math.tan(Math.PI / n)), Math.min(root.clientWidth * 0.38, w * 2.1));
      st.tilt = getComputedStyle(root).getPropertyValue('--fx-orbit-tilt').trim() || '0deg';
      var fade = parseFloat(getComputedStyle(root).getPropertyValue('--fx-orbit-fade'));
      st.fade = isNaN(fade) ? 0.45 : Math.max(0, Math.min(1, fade));
      // הכרטיסים שמאחור נראים גבוה יותר בגלל ההטיה. הגובה מחושב כך שכולם נכנסים
      var drop = st.radius * Math.sin(Math.abs(parseFloat(st.tilt) || 0) * Math.PI / 180), above = drop * 0.8 + h * 0.32 + 26;
      root.style.height = Math.round(above + drop + h / 2 + 30) + 'px';
      ring.style.top = Math.round(above) + 'px';
      place(st);
    }
    measure();
    if ('ResizeObserver' in window) new ResizeObserver(measure).observe(root);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(measure);

    function front(i) {
      // מסובב בדרך הקצרה עד שהכרטיס מלפנים
      var want = -st.base[i], d = ((want - st.angle) % 360 + 540) % 360 - 180;
      st.target = st.angle + d; st.v = 0;
      st.rest = performance.now() + 2500;
      wake();
    }
    // גרירה
    var moved = 0;
    root.addEventListener('pointerdown', function (e) {
      if (e.button != null && e.button > 0) return;
      st.drag = { x: e.clientX, t: performance.now() };
      st.v = 0; st.target = null; moved = 0;
      root.classList.add('is-grabbing');
      wake();
    });
    window.addEventListener('pointermove', function (e) {
      if (!st.drag) return;
      var dx = e.clientX - st.drag.x, now = performance.now(), dt = Math.max(8, now - st.drag.t), k = 150 / Math.max(240, root.clientWidth) * 1.6;
      st.angle += dx * k;
      st.v = st.v * 0.4 + (dx * k / dt * 1000) * 0.6;
      st.drag.x = e.clientX; st.drag.t = now;
      moved += Math.abs(dx);
    }, { passive: true });
    function release() {
      if (!st.drag) return;
      st.drag = null;
      root.classList.remove('is-grabbing');
      st.v = Math.max(-520, Math.min(520, st.v));
      st.snapPending = true;
      st.rest = performance.now() + 2500;
      wake();
    }
    window.addEventListener('pointerup', release);
    window.addEventListener('pointercancel', release);
    // לחיצה על כרטיס מהצד מביאה אותו לחזית. גרירה לא נחשבת לחיצה
    root.addEventListener('click', function (e) {
      if (moved > 6) { e.preventDefault(); e.stopPropagation(); return; }
      var card = e.target.closest('.fx-orbit__ring > *'), i = cards.indexOf(card);
      if (i < 0) return;
      var a = (st.base[i] + st.angle) * Math.PI / 180;
      if (Math.cos(a) < 0.985) { e.preventDefault(); front(i); }
    }, true);
    root.addEventListener('focusin', function (e) {
      st.hold = true;
      var i = cards.indexOf(e.target.closest('.fx-orbit__ring > *'));
      if (i >= 0) front(i);
    });
    root.addEventListener('focusout', function () { st.hold = false; wake(); });
    root.addEventListener('pointerenter', function (e) { if (e.pointerType === 'mouse') st.hold = true; });
    root.addEventListener('pointerleave', function () { st.hold = false; wake(); });
    root.addEventListener('keydown', function (e) {
      if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
      e.preventDefault();
      st.target = nearest(st) + (e.key === 'ArrowLeft' ? st.step : -st.step);
      st.v = 0;
      wake();
    });
    root.fxOrbit = { to: front, next: function () { st.target = nearest(st) - st.step * side; wake(); }, prev: function () { st.target = nearest(st) + st.step * side; wake(); } };
    items.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) { st.visible = entries[entries.length - 1].isIntersecting; if (st.visible) wake(); }).observe(root);
    } else { st.visible = true; wake(); }
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-orbit'), setup);
  }
  (window.FX = window.FX || {}).orbit = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-silk · רקע משי */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var VERT = 'attribute vec2 p; void main() { gl_Position = vec4(p, 0.0, 1.0); }';
  // רעש שמעוות את עצמו פעמיים נותן קפלים רכים, כמו בד שזז ברוח
  var FRAG = [
    'precision highp float;',
    'uniform vec2 uRes; uniform float uTime; uniform vec2 uMouse; uniform float uScale;',
    'uniform vec3 uC0; uniform vec3 uC1; uniform vec3 uC2; uniform vec3 uC3;',
    'float hash(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }',
    'float noise(vec2 p) { vec2 i = floor(p), f = fract(p); vec2 u = f * f * (3.0 - 2.0 * f);',
    '  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y); }',
    'float fbm(vec2 p) { float v = 0.0, a = 0.5; for (int i = 0; i < 4; i++) { v += a * noise(p); p = p * 2.03 + vec2(11.3, 7.7); a *= 0.5; } return v; }',
    'void main() {',
    '  vec2 p = (gl_FragCoord.xy - 0.5 * uRes) / uRes.y * uScale;',
    '  vec2 m = (uMouse - 0.5) * vec2(uRes.x / uRes.y, 1.0);',
    '  float t = uTime;',
    '  vec2 q = vec2(fbm(p + vec2(0.0, t)), fbm(p + vec2(5.2, -t * 1.3)));',
    '  vec2 r = vec2(fbm(p + 3.0 * q + vec2(1.7, 9.2) + 0.5 * t + m * 0.7), fbm(p + 3.0 * q + vec2(8.3, 2.8) - 0.4 * t - m * 0.7));',
    '  float f = fbm(p + 3.2 * r);',
    '  float fold = 0.5 + 0.5 * sin(6.2831 * (f * 1.5 + r.x * 0.9));',
    '  vec3 col = mix(uC0, uC1, smoothstep(0.15, 0.85, f + 0.3 * (q.x - 0.5)));',
    '  col = mix(col, uC2, smoothstep(0.45, 0.95, r.y) * 0.7);',
    '  col = mix(col, uC3, smoothstep(0.5, 0.95, r.x * q.y * 2.4) * 0.75);',
    '  col *= 0.84 + 0.26 * fold;',
    '  col += (hash(gl_FragCoord.xy + fract(t) * 91.7) - 0.5) * 0.03;',
    '  gl_FragColor = vec4(col, 1.0);',
    '}'
  ].join('\n');
  var items = [], raf = 0;

  function rgb(hex) {
    var h = String(hex).trim().replace('#', '');
    if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
    var n = parseInt(h, 16);
    return isNaN(n) || h.length !== 6 ? null : [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255];
  }
  function program(gl) {
    function sh(type, src) { var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return gl.getShaderParameter(s, gl.COMPILE_STATUS) ? s : null; }
    var v = sh(gl.VERTEX_SHADER, VERT), f = sh(gl.FRAGMENT_SHADER, FRAG), pr = gl.createProgram();
    if (!v || !f) return null;
    gl.attachShader(pr, v); gl.attachShader(pr, f); gl.linkProgram(pr);
    return gl.getProgramParameter(pr, gl.LINK_STATUS) ? pr : null;
  }

  function draw(st, now) {
    var gl = st.gl, c = st.canvas;
    st.mx += (st.tx - st.mx) * 0.06; st.my += (st.ty - st.my) * 0.06;
    gl.viewport(0, 0, c.width, c.height);
    gl.uniform2f(st.u.uRes, c.width, c.height);
    gl.uniform1f(st.u.uTime, st.seed + now / 1000 * 0.07 * st.speed);
    gl.uniform2f(st.u.uMouse, st.mx, st.my);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
  function frame(now) {
    raf = 0;
    var busy = false;
    items.forEach(function (st) { if (st.visible && !st.lost) { draw(st, now); busy = true; } });
    if (busy && !REDUCE) raf = requestAnimationFrame(frame);
  }
  function wake() { if (!raf) raf = requestAnimationFrame(frame); }

  function setup(el) {
    if (el.__fxSilk) return;
    el.__fxSilk = true;
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var colors = (el.getAttribute('data-colors') || '#1d4ce0,#14141a,#ffd21f,#e5432b').split(',').map(rgb).filter(Boolean);
    while (colors.length < 4) colors.push(colors[colors.length - 1] || [0.1, 0.1, 0.2]);
    var css = function (c) { return 'rgb(' + c.map(function (v) { return Math.round(v * 255); }).join(',') + ')'; };
    // אם אין WebGL נשאר מעבר צבעים רגיל באותם צבעים
    var fallback = 'linear-gradient(135deg,' + css(colors[0]) + ',' + css(colors[1]) + ' 55%,' + css(colors[2]) + ')';
    var canvas = document.createElement('canvas'), gl = null;
    canvas.className = 'fx-silk__canvas';
    canvas.setAttribute('aria-hidden', 'true');
    canvas.style.background = fallback;
    el.insertBefore(canvas, el.firstChild);
    try { gl = canvas.getContext('webgl', { antialias: false, alpha: false, powerPreference: 'low-power' }); } catch (err) { gl = null; }
    var pr = gl && program(gl);
    if (!pr) return;
    gl.useProgram(pr);
    var buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    var loc = gl.getAttribLocation(pr, 'p');
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    var u = {};
    ['uRes', 'uTime', 'uMouse', 'uScale', 'uC0', 'uC1', 'uC2', 'uC3'].forEach(function (k) { u[k] = gl.getUniformLocation(pr, k); });
    colors.slice(0, 4).forEach(function (c, i) { gl.uniform3f(u['uC' + i], c[0], c[1], c[2]); });
    gl.uniform1f(u.uScale, num('data-scale', 1.5));                  // גודל הקפלים. מספר גדול יותר נותן קפלים קטנים
    var st = { el: el, canvas: canvas, gl: gl, u: u, visible: false, lost: false, mx: 0.5, my: 0.5, tx: 0.5, ty: 0.5,
      seed: num('data-seed', Math.random() * 40),
      speed: num('data-speed', 1),                                   // מהירות הזרימה
      quality: Math.max(0.2, Math.min(1, num('data-quality', 0.5))) }; // רזולוציית הציור ביחס לגודל האלמנט. הרקע רך, אז חצי מספיק
    function size() {
      var r = el.getBoundingClientRect(), w = Math.max(2, Math.round(r.width * st.quality)), h = Math.max(2, Math.round(r.height * st.quality));
      if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
      wake();
    }
    size();
    if ('ResizeObserver' in window) new ResizeObserver(size).observe(el);
    el.addEventListener('pointermove', function (e) {
      var r = el.getBoundingClientRect();
      st.tx = (e.clientX - r.left) / r.width; st.ty = 1 - (e.clientY - r.top) / r.height;
    }, { passive: true });
    canvas.addEventListener('webglcontextlost', function (e) { e.preventDefault(); st.lost = true; });
    canvas.addEventListener('webglcontextrestored', function () { st.lost = false; el.__fxSilk = false; canvas.parentNode.removeChild(canvas); items.splice(items.indexOf(st), 1); setup(el); });
    items.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) { st.visible = entries[entries.length - 1].isIntersecting; if (st.visible) wake(); }).observe(el);
    } else { st.visible = true; wake(); }
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-silk'), setup);
  }
  (window.FX = window.FX || {}).silk = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();
