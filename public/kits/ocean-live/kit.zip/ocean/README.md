# ים חי · ocean.js

ים שמצויר בזמן אמת בכרטיס המסך (WebGL): גלים, השתקפות של השמים, קצף, ארבעה מצבי אור, וצלילה מתחת למים עם קרני אור, בועות וחושך בעומק. קובץ אחד, בלי ספריות ובלי תמונות.

## מה יש בתיקייה

- `ocean.js` הרכיב. זה הקובץ היחיד שצריך באתר.
- `demo.html` עמוד ההדגמה המלא: צלילה בגלילה והוראות.
- `example.html` דוגמה לכותרת ראשית של אתר עם ים ברקע.

## צלילה בגלילה

```html
<section class="fx-ocean" data-mood="sunset">
  <div class="fx-ocean__stop" data-level="3"><h2>מעל המים</h2></div>
  <div class="fx-ocean__stop" data-level="0"><h2>על קו המים</h2></div>
  <div class="fx-ocean__stop" data-level="-6" data-pitch="25"><h2>מתחת למים</h2></div>
  <div class="fx-ocean__stop" data-level="-60"><h2>בעומק</h2></div>
  <div class="fx-ocean__stop" data-level="6" data-mood="storm"><h2>סערה</h2></div>
</section>
<script src="ocean.js"></script>
```

כל `fx-ocean__stop` הוא תחנה בגובה מסך. `data-level` הוא גובה המצלמה במטרים: חיובי מעל המים, שלילי מתחת. בין התחנות המצלמה זזה לבד לפי הגלילה, והתוכן של כל תחנה מוצג מעל הים.

## רק רקע של ים

```html
<section class="fx-ocean" data-mood="day" data-level="2.5" style="--fx-ocean-height: 90vh">
  <div class="hero">…</div>
</section>
```

## אפשרויות

| מאפיין | איפה | מה הוא עושה |
| --- | --- | --- |
| `data-mood` | section או תחנה | `day`, `sunset`, `night`, `storm`. בתחנה: מחליף את מצב האור כשמגיעים אליה. ברירת מחדל: `sunset` |
| `data-level` | תחנה, או section בלי תחנות | גובה המצלמה במטרים. ברירת מחדל: 3.2 |
| `data-pitch` | תחנה | הטיית המבט במעלות, חיובי למעלה |
| `data-turn` | תחנה | סיבוב המבט לצדדים, במעלות |
| `data-fov` | תחנה | זווית הראייה במעלות. בלי ערך: לפי צורת המסך |
| `data-waves` | section | גובה הגלים, כפול. 0.5 שקט, 2 גבוה |
| `data-speed` | section | מהירות הגלים. ברירת מחדל: 1 |
| `data-drift` | section | שיוט המצלמה קדימה, מטרים לשנייה. 0 עוצר. ברירת מחדל: 0.6 |
| `data-quality` | section | `high`, `mid`, `low`. בלי ערך: לפי המכשיר, ויורד לבד אם הוא מתקשה |
| `data-lightning` | section | `off` מבטל את הברקים בסערה |
| `--fx-ocean-height` | CSS | גובה הים כשאין תחנות. ברירת מחדל: 100vh |
| `--fx-ocean-level` | CSS, לקריאה | הגובה הנוכחי במטרים |

## שליטה מקוד

```js
const sea = document.querySelector('.fx-ocean').fxOcean;
sea.setMood('night');      // day, sunset, night, storm
sea.go(2);                 // גלילה לתחנה השלישית
sea.go({ level: -12 });    // מעבר לעומק 12 מטר בלי גלילה
sea.go(null);              // חזרה לשליטת הגלילה
sea.setQuality('mid');     // high, mid, low
```

תוכן שנוסף לדף אחרי הטעינה: `FX.ocean(container)`.

## אירועים

`fx:ocean-ready`, `fx:ocean-level` (`detail.level`, `detail.under`), `fx:ocean-stop` (`detail.index`), `fx:ocean-mood` (`detail.mood`), `fx:ocean-quality`, `fx:ocean-fallback` (`detail.reason`).

## חשוב לדעת

- הים מצויר ברזולוציה מוקטנת, נעצר כשהוא לא על המסך, ויורד באיכות לבד במכשיר חלש.
- בלי WebGL מוצג רקע מצויר של שמים וים, והתוכן נשאר קריא.
- בהפחתת תנועה: הים עומד, המעבר בין תחנות הוא חיתוך מהיר, ואין ברקים, גשם ובועות.
- בסערה יש לכל היותר שני הבזקים קצרים כל חמש שניות. `data-lightning="off"` מבטל אותם.
- נבדק ב־Chrome עם רינדור תוכנה. לפני מסירה ללקוח כדאי לבדוק בטלפון אמיתי.
