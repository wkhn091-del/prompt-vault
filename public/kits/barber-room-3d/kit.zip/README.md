# חדר מספרה בתלת־ממד

חדר מספרה שלם שנבנה בקוד: שלושה כיסאות ספר, מראות עם נורות, רצפת שחמט, שלט ניאון עם שם המספרה, עמוד ספר מסתובב, לוח מחירים, שעון שמראה את השעה וחלון. החדר נדבק לראש המסך, חלקי העמוד נגללים מעליו, והמצלמה נוסעת בין נקודות מבט.

## מה יש כאן

- `barber-room.js` הוא הרכיב כולו בקובץ אחד (כ-630 ק"ב, כולל three.js).
- `example.html` הוא עמוד מינימלי עם ארבע תחנות. מתחילים ממנו.
- `demo.html` הוא עמוד הנחיתה המלא לדוגמה, עם כפתורי יום וערב וערכות הצבע.

## שימוש

```html
<section class="fx-room" data-name="שם המספרה" data-prices="תספורת:70, זקן:40">
  <div class="fx-room__stop" data-view="wide"> … </div>
  <div class="fx-room__stop" data-view="chair" data-shift="0.17"> … </div>
  <div class="fx-room__stop" data-view="board" data-shift="0.2"> … </div>
  <div class="fx-room__stop" data-view="sign"> … </div>
</section>
<script src="barber-room.js" defer></script>
```

כל `fx-room__stop` הוא מסך אחד של גלילה, ובתוכו כותבים HTML רגיל. בלי תחנות בכלל החדר מוצג כתמונה אחת בגובה המסך (`--fx-room-height` משנה את הגובה, `data-view` את נקודת המבט).

## נקודות מבט

`wide` כל החדר · `chair` הכיסא מקרוב · `mirror` מול המראה · `counter` הכלים שעל הדלפק · `board` לוח המחירים · `sign` שלט הניאון · `pole` עמוד הספר · `window` החלון וספסל ההמתנה.

מבט משלכם כותבים כך: `data-view="0.9,1.5,3 | 0,1.25,-3.2 | 50"` (מיקום המצלמה, לאן מסתכלים, זווית). החדר ברוחב 8 מטר ובעומק 6.4, והמרכז שלו ב-0,0.

## כיוונון

| מאפיין | מה הוא עושה |
| --- | --- |
| `data-name` | שם המספרה על שלט הניאון |
| `data-prices` | שורות לוח המחירים: `תספורת:70, זקן:40` |
| `data-prices-title`, `data-currency` | כותרת הלוח וסימן המטבע |
| `data-theme` | `classic`, `noir` או `bright` |
| `data-mood` | `evening`, `day` או `auto` (לפי השעה אצל הגולש) |
| `data-font`, `data-font-weight` | הגופן של השלט ושל הלוח |
| `data-shift` על תחנה | כמה התמונה זזה הצידה כדי לפנות מקום לטקסט |
| `data-quality` | `high`, `mid`, `low`. בלי זה הרכיב בוחר לבד |

## תוויות על חפצים

```html
<button class="fx-room__spot" data-at="chair" data-go="chair">הכיסא</button>
```

`data-at`: `chair`, `mirror`, `counter`, `board`, `sign`, `pole`, `window`, `clock`. תווית שנכתבת בתוך תחנה מוצגת רק כשהתחנה הזאת על המסך.

## שליטה מהקוד

```js
const room = document.querySelector('.fx-room').fxRoom;
room.go('chair');        // מעבר לתחנה או למבט
room.setMood('day');     // יום או ערב. toggleMood() מחליף
room.setTheme('noir');   // ערכת צבע אחרת
room.spin(1);            // מסובב כיסא
room.refresh();          // אחרי שינוי של data-name או data-prices
```

אירועים על האלמנט: `fx:room-ready`, `fx:room-view`, `fx:room-mood`, `fx:room-quality`, `fx:room-fallback`.

## כדאי לדעת

- אלמנט שנוסף לעמוד אחרי הטעינה מופעל בקריאה ל-`FX.room()`.
- הרכיב בוחר רמת איכות לפי המכשיר ויורד רמה אם הקצב נמוך. ברמה הנמוכה אין השתקפות אמיתית במראה, אין צללים ואין זוהר.
- בלי WebGL מוצג רקע מצויר, והטקסט של התחנות נשאר.
- עם "הפחתת תנועה" המצלמה מתחלפת בין התחנות בחיתוך רך במקום לנסוע.
- הרכיב משתלב עם ערכת התנועה למספרות: אותו `FX`, ושמות המחלקות לא מתנגשים.
- three.js מופץ ברישיון MIT.
