/* fx-weight · משקל משתנה */
(function () {
  'use strict';
  var mm = window.matchMedia;
  var REDUCE = mm && mm('(prefers-reduced-motion: reduce)').matches;
  var FINE = mm && mm('(hover: hover) and (pointer: fine)').matches;
  var list = [], running = false, px = null, py = null, lastY = window.pageYOffset || 0;

  // מחלק לאותיות, ומשאיר ניקוד וסימנים צמודים לאות שלהם
  function graphemes(s) {
    if (window.Intl && Intl.Segmenter) {
      return Array.from(new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(s), function (x) { return x.segment; });
    }
    return s.match(/[\s\S][̀-֑ͯ-ׇ‍]*/g) || [];
  }
  function split(el) {
    var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null), nodes = [], n, letters = [];
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach(function (node) {
      var frag = document.createDocumentFragment();
      node.nodeValue.split(/(\s+)/).forEach(function (part) {
        if (!part) return;
        if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(part)); return; }
        var w = document.createElement('span');                // מילה שלמה לא נשברת באמצע
        w.className = 'fx-weight__w';
        w.setAttribute('aria-hidden', 'true');
        graphemes(part).forEach(function (g) {
          var l = document.createElement('span');
          l.className = 'fx-weight__l';
          l.textContent = g;
          w.appendChild(l);
          letters.push({ el: l, cur: 0, shown: -1 });
        });
        frag.appendChild(w);
      });
      node.parentNode.replaceChild(frag, node);
    });
    return letters;
  }

  function frame(now) {
    var active = false;
    list.forEach(function (st) {
      if (!st.visible) return;
      var r = st.el.getBoundingClientRect(), size = parseFloat(getComputedStyle(st.el).fontSize) || 16, R = st.radius * size;
      var near = px !== null && px > r.left - R && px < r.right + R && py > r.top - R && py < r.bottom + R;
      var wave = !near && st.idle, i, L, t = now / 1000;
      var targets = [];
      for (i = 0; i < st.letters.length; i++) {              // קודם קוראים את כל המקומות, ורק אחר כך כותבים
        L = st.letters[i];
        var f = 0;
        if (near) {
          var lr = L.el.getBoundingClientRect(), dx = px - (lr.left + lr.width / 2), dy = (py - (lr.top + lr.height / 2)) * 1.3;
          f = Math.max(0, 1 - Math.sqrt(dx * dx + dy * dy) / R);
          f = f * f * (3 - 2 * f);
        } else if (wave) {                                     // גל שעובר על האותיות, וזז גם עם הגלילה
          f = Math.pow((Math.sin(t * 2.2 + st.phase - i * 0.5) + 1) / 2, 4);
        }
        targets.push(st.thin ? st.rest + (st.min - st.rest) * f : st.rest + (st.max - st.rest) * f);
      }
      for (i = 0; i < st.letters.length; i++) {
        L = st.letters[i];
        L.cur += (targets[i] - L.cur) * 0.2;
        if (Math.abs(targets[i] - L.cur) > 0.6) active = true;
        if (Math.abs(L.cur - L.shown) > 0.6) {
          L.shown = L.cur;
          L.el.style.fontVariationSettings = "'wght' " + L.cur.toFixed(0);
          L.el.style.setProperty('--fx-w', Math.max(0, Math.min(1, Math.abs(L.cur - st.rest) / (Math.abs((st.thin ? st.min : st.max) - st.rest) || 1))).toFixed(3));
        }
      }
      if (wave) active = true;
    });
    if (active) requestAnimationFrame(frame); else running = false;
  }
  function wake() {
    if (!running && list.length) { running = true; requestAnimationFrame(frame); }
  }

  function setup(el) {
    if (el.__fxWeight || REDUCE) return;
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var weight = parseFloat(getComputedStyle(el).fontWeight) || 400;
    var idle = el.getAttribute('data-idle') || 'auto';
    var st = el.__fxWeight = {
      el: el,
      min: num('data-min', 100),                 // המשקל הדק ביותר בגופן
      max: num('data-max', 900),                 // המשקל הכבד ביותר בגופן
      rest: num('data-rest', weight),            // המשקל במנוחה. בלי זה, ה-font-weight של האלמנט
      radius: num('data-radius', 2.2),           // טווח ההשפעה של העכבר, ביחס לגודל הפונט
      thin: el.getAttribute('data-mode') === 'thin',
      idle: idle === 'wave' || (idle === 'auto' && !FINE),   // גל אוטומטי, כברירת מחדל רק במסכי מגע
      phase: 0, visible: true, letters: []
    };
    el.setAttribute('aria-label', (el.textContent || '').replace(/\s+/g, ' ').trim());
    st.letters = split(el);
    st.letters.forEach(function (L) { L.cur = st.rest; });
    list.push(st);

    // במסך מגע: האצבע על הטקסט עובדת כמו עכבר
    el.addEventListener('pointermove', function (e) { if (e.pointerType !== 'mouse') { px = e.clientX; py = e.clientY; wake(); } });
    function up(e) { if (e.pointerType !== 'mouse') { px = py = null; wake(); } }
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible) wake();
      }).observe(el);
    }
    wake();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-weight'), setup);
  }
  if (!REDUCE) {
    window.addEventListener('pointermove', function (e) {
      if (e.pointerType !== 'mouse') return;
      px = e.clientX;
      py = e.clientY;
      wake();
    }, { passive: true });
    document.documentElement.addEventListener('mouseleave', function () { px = py = null; wake(); });
    window.addEventListener('scroll', function () {
      var y = window.pageYOffset || 0, dy = y - lastY;
      lastY = y;
      list.forEach(function (st) { st.phase += dy * 0.02; });
      wake();
    }, { passive: true });
  }
  (window.FX = window.FX || {}).weight = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-drum · גליל מילים */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var list = [], running = false, lastY = window.pageYOffset || 0;

  function measure(st) {
    var cs = getComputedStyle(st.el), size = parseFloat(cs.fontSize) || 16;
    var lh = parseFloat(cs.lineHeight);
    st.H = isNaN(lh) ? size * 1.2 : lh;
    st.el.style.height = st.H + 'px';
    st.faces.forEach(function (f) { f.style.lineHeight = st.H + 'px'; f.w = f.offsetWidth; });
    // רדיוס הגליל: כך שכל מילה תופסת בדיוק שורה אחת על ההיקף
    st.r = st.H / 2 / Math.tan(st.step / 2 * Math.PI / 180) * 1.04;
    fit(st);
  }
  function front(st) { return ((Math.round(st.target / st.step) % st.faces.length) + st.faces.length) % st.faces.length; }
  function fit(st) {
    var f = st.faces[front(st)];
    if (st.fit && f) st.el.style.width = f.w + 'px';
  }

  function render(st) {
    var n = st.faces.length, fi = front(st);
    st.drum.style.transform = 'translateZ(' + (-st.r).toFixed(1) + 'px)';   // המילה שבחזית יושבת בעומק 0, בגודל רגיל
    st.faces.forEach(function (f, i) {
      var a = i * st.step - st.angle, rad = a * Math.PI / 180, c = Math.cos(rad);
      f.style.transform = 'rotateX(' + (-a).toFixed(2) + 'deg) translateZ(' + st.r.toFixed(1) + 'px)';
      f.style.opacity = c > 0 ? Math.pow(c, 4).toFixed(3) : '0';     // מילים שמסתובבות הצידה דוהות
      f.classList.toggle('is-front', i === fi);
    });
  }

  function frame(now) {
    var again = false;
    list.forEach(function (st) {
      if (!st.visible) return;
      if (!st.hold && !st.scrolling && now - st.last > st.every) {   // מעבר אוטומטי למילה הבאה
        st.last = now;
        st.target += st.step;
        fit(st);
      }
      st.v = (st.v + (st.target - st.angle) * 0.11) * 0.72;          // קפיץ: הגליל עוצר עם קפיצה קטנה
      st.angle += st.v;
      render(st);
      again = true;
    });
    if (again) requestAnimationFrame(frame); else running = false;
  }
  function wake() {
    if (!running && list.length) { running = true; requestAnimationFrame(frame); }
  }

  function setup(el) {
    if (el.__fxDrum) return;
    var words = Array.prototype.filter.call(el.children, function (n) { return n.tagName === 'SPAN'; });
    if (words.length < 2) return;
    el.__fxDrum = true;
    if (REDUCE) return;                                                // בלי תנועה: כל המילים בשורה, עם קו נטוי ביניהן
    var sr = document.createElement('span'), drum = document.createElement('span');
    sr.className = 'fx-drum__sr';
    sr.textContent = words.map(function (w) { return w.textContent.trim(); }).join(', ');
    drum.className = 'fx-drum__drum';
    drum.setAttribute('aria-hidden', 'true');
    var n = words.length, copies = Math.ceil(8 / n), faces = [];     // לפחות 8 פאות, כדי שהגליל ייראה עגול
    for (var c = 0; c < copies; c++) {
      words.forEach(function (w) {
        var f = c === 0 ? w : w.cloneNode(true);
        f.classList.add('fx-drum__face');
        faces.push(f);
      });
    }
    faces.forEach(function (f) { drum.appendChild(f); });
    el.appendChild(sr);
    el.appendChild(drum);
    el.classList.add('is-ready');

    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var st = el.__fxDrum = {
      el: el, drum: drum, faces: faces, step: 360 / faces.length, angle: 0, target: 0, v: 0, r: 0, H: 0,
      every: num('data-interval', 2200),        // כמה זמן כל מילה נשארת, במילישניות
      fit: el.getAttribute('data-fit') !== 'false',
      last: performance.now(), hold: false, scrolling: false, visible: true, timer: 0
    };
    measure(st);
    render(st);
    list.push(st);

    el.addEventListener('click', function () { st.target += st.step; st.last = performance.now(); fit(st); wake(); });
    el.addEventListener('pointerenter', function (e) { if (e.pointerType === 'mouse') st.hold = true; });
    el.addEventListener('pointerleave', function () { st.hold = false; st.last = performance.now(); });
    st.scroll = function (dy) {                                        // הגלילה מסובבת את הגליל, ובסוף נעצרים על מילה
      if (el.getAttribute('data-scroll') === 'false') return;
      st.scrolling = true;
      st.target += dy * 0.35;
      clearTimeout(st.timer);
      st.timer = setTimeout(function () {
        st.scrolling = false;
        st.target = Math.round(st.target / st.step) * st.step;
        st.last = performance.now();
        fit(st);
      }, 140);
    };
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible) { st.last = performance.now(); wake(); }
      }).observe(el);
    }
    if ('ResizeObserver' in window) new ResizeObserver(function () { measure(st); }).observe(el.parentElement || el);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { measure(st); });
    wake();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-drum'), setup);
  }
  if (!REDUCE) {
    window.addEventListener('scroll', function () {
      var y = window.pageYOffset || 0, dy = Math.max(-80, Math.min(80, y - lastY));
      lastY = y;
      list.forEach(function (st) { if (st.visible && st.scroll) st.scroll(dy); });
    }, { passive: true });
  }
  (window.FX = window.FX || {}).drum = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-ribbon · סרט טקסט */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var NS = 'http://www.w3.org/2000/svg';
  var list = [], running = false, last = 0, lastY = window.pageYOffset || 0, px = null, py = null, uid = 0;

  function make(tag, cls) { var n = document.createElementNS(NS, tag); if (cls) n.setAttribute('class', cls); return n; }

  // גובה הסרט בכל נקודה: גל סינוס, ועוד בליטה רכה לכיוון העכבר
  function y(st, x) {
    var k = 2 * Math.PI / st.len;
    var v = st.H / 2 + st.amp * st.boost * Math.sin(x * k + st.phase) + st.amp * 0.35 * Math.sin(x * k * 0.47 - st.phase * 0.6);
    if (st.pull) v += st.pull * Math.exp(-Math.pow((x - st.px) / (st.len * 0.35), 2));
    return v;
  }
  function path(st) {
    var step = st.len / 8, x0 = -st.len * 0.5, x1 = st.W + st.len * 0.5, d = '', e = 0.5;
    for (var x = x0; x <= x1 + 0.1; x += step) {
      var yy = y(st, x);
      if (x === x0) { d = 'M' + x.toFixed(1) + ' ' + yy.toFixed(1); continue; }
      var xa = x - step, ya = y(st, xa);
      var ta = (y(st, xa + e) - y(st, xa - e)) / (2 * e), tb = (y(st, x + e) - y(st, x - e)) / (2 * e);   // שיפוע בשני הקצוות, בשביל עקומה חלקה
      d += 'C' + (xa + step / 3).toFixed(1) + ' ' + (ya + ta * step / 3).toFixed(1) + ' ' + (x - step / 3).toFixed(1) + ' ' + (yy - tb * step / 3).toFixed(1) + ' ' + x.toFixed(1) + ' ' + yy.toFixed(1);
    }
    return d;
  }

  function layout(st) {
    var cs = getComputedStyle(st.el), size = parseFloat(cs.fontSize) || 16;
    st.W = st.el.clientWidth;
    st.band = size * st.bandK;
    st.H = Math.round(st.amp * 2.6 + st.band + 8);
    st.svg.setAttribute('viewBox', '0 0 ' + st.W + ' ' + st.H);
    st.svg.style.height = st.H + 'px';
    st.bandPath.style.strokeWidth = st.band + 'px';
    st.shadowPath.style.strokeWidth = st.band + 'px';
    st.shadowPath.setAttribute('transform', 'translate(0 ' + (size * 0.18).toFixed(1) + ')');
    // מודדים פעם אחת את אורך הביטוי, וחוזרים עליו מספיק פעמים כדי למלא את הסרט
    st.tp.textContent = st.phrase;
    var one = st.text.getComputedTextLength() || size * st.phrase.length * 0.5;
    st.one = one;
    var count = Math.ceil((st.W * 1.8 + st.len * 2) / one) + 2;
    st.tp.textContent = new Array(count + 1).join(st.phrase);
    draw(st);
  }
  function draw(st) {
    var d = path(st);
    st.line.setAttribute('d', d);
    st.bandPath.setAttribute('d', d);
    st.shadowPath.setAttribute('d', d);
    st.tp.setAttribute('startOffset', ((st.pos % st.one + st.one) % st.one - st.one * 2).toFixed(1));
  }

  function frame(now) {
    var dt = last ? Math.min((now - last) / 1000, 0.05) : 0.016, again = false;
    last = now;
    list.forEach(function (st) {
      if (!st.visible || !st.W) return;
      again = true;
      st.pos += (st.speed * st.dir + st.kick) * dt;
      st.kick *= Math.exp(-dt * 2.5);
      st.phase += dt * st.waveSpeed;
      st.boost += (1 - st.boost) * (1 - Math.exp(-dt * 2));
      // העכבר מושך את הסרט אליו כשהוא קרוב
      var r = st.svg.getBoundingClientRect(), target = 0;
      if (px !== null && py > r.top - st.H && py < r.bottom + st.H && px > r.left && px < r.right) {
        st.px = px - r.left;
        var base = st.pull;
        st.pull = 0;
        target = Math.max(-st.H * 0.9, Math.min(st.H * 0.9, (py - r.top) - y(st, st.px)));
        st.pull = base;
      }
      st.pv = (st.pv + (target - st.pull) * 0.08) * 0.8;
      st.pull += st.pv;
      draw(st);
    });
    if (again) requestAnimationFrame(frame);
    else { running = false; last = 0; }
  }
  function wake() {
    if (!running && list.length) { running = true; last = 0; requestAnimationFrame(frame); }
  }

  function setup(el) {
    if (el.__fxRibbon) return;
    var text = (el.textContent || '').replace(/\s+/g, ' ').trim();
    if (!text) return;
    var id = 'fx-ribbon-' + (++uid), sr = document.createElement('span'), svg = make('svg', 'fx-ribbon__svg');
    sr.className = 'fx-ribbon__sr';
    sr.textContent = text;
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('direction', 'ltr');                // הטקסט עצמו נשאר מימין לשמאל. כך הדפדפן מניח אותו נכון על הקו
    var defs = make('defs'), line = make('path'), shadow = make('path', 'fx-ribbon__shadow'), band = make('path', 'fx-ribbon__band');
    var t = make('text', 'fx-ribbon__text'), tp = make('textPath');
    line.id = id;
    tp.setAttribute('href', '#' + id);
    tp.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', '#' + id);
    defs.appendChild(line);
    t.appendChild(tp);
    svg.appendChild(defs);
    svg.appendChild(shadow);
    svg.appendChild(band);
    svg.appendChild(t);
    el.textContent = '';
    el.appendChild(sr);
    el.appendChild(svg);
    el.classList.add('is-ready');

    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var sep = el.getAttribute('data-separator');
    var st = el.__fxRibbon = {
      el: el, svg: svg, line: line, bandPath: band, shadowPath: shadow, text: t, tp: tp,
      phrase: text + (sep === null ? '  ' : ' ' + sep + ' '),
      speed: num('data-speed', 70),               // מהירות הטקסט על הסרט, בפיקסלים לשנייה
      amp: num('data-wave', 34),                  // גובה הגל, בפיקסלים
      len: num('data-length', 520),               // אורך גל אחד, בפיקסלים
      waveSpeed: num('data-flow', 1.1),           // כמה מהר הגל עצמו זז
      bandK: num('data-band', 1.75),              // עובי הסרט ביחס לגודל הפונט
      dir: (getComputedStyle(el).direction === 'rtl' ? 1 : -1) * (el.getAttribute('data-reverse') === 'true' ? -1 : 1),
      pos: 0, kick: 0, phase: Math.random() * 6, boost: 1, pull: 0, pv: 0, px: 0, W: 0, H: 0, one: 100, visible: true
    };
    layout(st);
    if (REDUCE) return;                                  // בלי תנועה: גל קפוא
    list.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible) wake();
      }, { rootMargin: '60px 0px' }).observe(el);
    }
    wake();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-ribbon'), setup);
  }
  var rt = 0;
  window.addEventListener('resize', function () {
    clearTimeout(rt);
    rt = setTimeout(function () {
      Array.prototype.forEach.call(document.querySelectorAll('.fx-ribbon.is-ready'), function (el) { if (el.__fxRibbon) layout(el.__fxRibbon); });
    }, 120);
  });
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () {
    Array.prototype.forEach.call(document.querySelectorAll('.fx-ribbon.is-ready'), function (el) { if (el.__fxRibbon) layout(el.__fxRibbon); });
  });
  if (!REDUCE) {
    window.addEventListener('pointermove', function (e) { px = e.clientX; py = e.clientY; }, { passive: true });
    document.documentElement.addEventListener('mouseleave', function () { px = py = null; });
    window.addEventListener('pointerup', function (e) { if (e.pointerType !== 'mouse') px = py = null; }, { passive: true });
    // גלילה מאיצה את הטקסט ומגביהה את הגל לרגע
    window.addEventListener('scroll', function () {
      var yy = window.pageYOffset || 0, dy = Math.max(-100, Math.min(100, yy - lastY));
      lastY = yy;
      list.forEach(function (st) {
        if (!st.visible) return;
        st.kick += Math.abs(dy) * 6 * st.dir;
        st.boost = Math.min(2.2, st.boost + Math.abs(dy) * 0.012);
      });
    }, { passive: true });
  }
  (window.FX = window.FX || {}).ribbon = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-ring · טבעת תמונות */
(function () {
  'use strict';
  if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) {   // בלי תנועה: שורה רגילה עם גלילה הצידה
    (window.FX = window.FX || {}).ring = function () {};
    return;
  }
  var list = [], running = false, last = 0, lastY = window.pageYOffset || 0;

  function layout(st) {
    var cs = getComputedStyle(st.el), gap = parseFloat(cs.getPropertyValue('--fx-ring-gap')) || 20;
    var w = st.items[0].offsetWidth, h = 0;
    st.items.forEach(function (it) { h = Math.max(h, it.offsetHeight); });
    st.w = w;
    st.R = Math.max(w * 0.9, (w + gap) / (2 * Math.tan(Math.PI / st.items.length)));   // רדיוס שבו הכרטיסים נוגעים זה בזה
    st.el.style.height = Math.round(h * 1.12 + 24) + 'px';
    st.el.style.perspective = Math.round(st.R * 2.4 + 500) + 'px';
    st.items.forEach(function (it, i) {
      it.style.marginLeft = (-w / 2) + 'px';
      it.style.marginTop = (-it.offsetHeight / 2) + 'px';
      it.style.transform = 'rotateY(' + (i * st.step) + 'deg) translateZ(' + st.R.toFixed(1) + 'px)';
    });
  }

  function render(st) {
    // הטבעת כולה זזה אחורה ברדיוס, כדי שהכרטיס שבחזית יישאר בגודל המקורי שלו
    st.spin.style.transform = 'translateZ(' + (-st.R).toFixed(1) + 'px) rotateY(' + (-st.angle).toFixed(3) + 'deg)';
    var front = st.front();
    st.items.forEach(function (it, i) {
      var rel = (i * st.step - st.angle) * Math.PI / 180, c = Math.cos(rel);
      it.__shade.style.opacity = Math.min(0.75, (1 - c) * 0.6).toFixed(3);
      it.style.pointerEvents = c > 0.2 ? '' : 'none';
      it.classList.toggle('is-front', i === front);
    });
  }

  function frame(now) {
    var dt = last ? Math.min((now - last) / 1000, 0.05) : 0.016, again = false;
    last = now;
    list.forEach(function (st) {
      if (!st.visible) return;
      again = true;
      if (st.drag) return render(st);
      if (st.target !== null) {                            // נסיעה לכרטיס מסוים, עם קפיץ
        st.v = (st.v + (st.target - st.angle) * 0.07) * 0.78;
        st.angle += st.v;
        if (Math.abs(st.target - st.angle) < 0.02 && Math.abs(st.v) < 0.02) { st.angle = st.target; st.target = null; st.v = 0; st.idleAt = now; }
      } else {
        st.angle += st.v * dt * 60;
        st.v *= Math.pow(0.05, dt);                          // תנופה שדועכת
        if (Math.abs(st.v) < 0.04 && st.snap && !st.spun) { st.target = st.near(); }
        if (Math.abs(st.v) < 0.04 && !st.over && now - st.idleAt > 2500) st.angle += st.auto * dt;   // סיבוב עצמי איטי כשאף אחד לא נוגע
        if (Math.abs(st.v) >= 0.04) st.spun = false; else st.spun = true;
      }
      render(st);
    });
    if (again) requestAnimationFrame(frame);
    else { running = false; last = 0; }
  }
  function wake() {
    if (!running && list.length) { running = true; last = 0; requestAnimationFrame(frame); }
  }

  function setup(el) {
    if (el.__fxRing) return;
    var items = Array.prototype.slice.call(el.children);
    if (items.length < 3) return;
    var spin = document.createElement('div');
    spin.className = 'fx-ring__spin';
    items.forEach(function (it) {
      it.classList.add('fx-ring__item');
      var shade = document.createElement('span');
      shade.className = 'fx-ring__shade';
      it.appendChild(shade);
      it.__shade = shade;
      spin.appendChild(it);
    });
    el.appendChild(spin);
    el.classList.add('is-ready');
    if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '0');
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var st = el.__fxRing = {
      el: el, spin: spin, items: items, step: 360 / items.length, angle: 0, v: 0, target: null, R: 300, w: 200,
      auto: num('data-auto', 7),                // מהירות הסיבוב העצמי, במעלות לשנייה. 0 מבטל
      snap: el.getAttribute('data-snap') !== 'false',
      drag: null, over: false, visible: true, idleAt: 0, spun: true
    };
    st.front = function () { return ((Math.round(st.angle / st.step) % items.length) + items.length) % items.length; };
    st.near = function () { return Math.round(st.angle / st.step) * st.step; };
    st.go = function (i) {                                     // הדרך הקצרה אל כרטיס i
      var cur = st.angle, base = i * st.step, k = Math.round((cur - base) / 360);
      st.target = base + k * 360;
      wake();
    };
    layout(st);
    render(st);
    list.push(st);

    // גרירה: פני הטבעת נעים עם היד, ובשחרור ממשיכים בתנופה ועוצרים על כרטיס
    el.addEventListener('pointerdown', function (e) {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      st.drag = { id: e.pointerId, x: e.clientX, sx: e.clientX, t: performance.now(), v: 0, moved: 0, cap: false };
      st.target = null;
      st.v = 0;
      wake();
    });
    el.addEventListener('pointermove', function (e) {
      var d = st.drag;
      if (!d || e.pointerId !== d.id) return;
      var now = performance.now(), dx = e.clientX - d.x, dt = Math.max(now - d.t, 1);
      d.x = e.clientX;
      d.t = now;
      d.moved = Math.max(d.moved, Math.abs(e.clientX - d.sx));
      if (d.moved > 4 && !d.cap) { d.cap = true; el.classList.add('is-dragging'); try { el.setPointerCapture(e.pointerId); } catch (err) {} }
      var da = -dx / st.R * 180 / Math.PI;
      st.angle += da;
      d.v = d.v * 0.5 + da / dt * 16.7 * 0.5;
    });
    function end(e) {
      var d = st.drag;
      if (!d || (e && e.pointerId !== d.id)) return;
      st.drag = null;
      el.classList.remove('is-dragging');
      st.v = performance.now() - d.t < 90 ? Math.max(-12, Math.min(12, d.v)) : 0;
      st.spun = false;
      st.idleAt = performance.now();
      st.moved = d.moved;
      wake();
    }
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
    el.addEventListener('click', function (e) {               // לחיצה על כרטיס בצד מביאה אותו לחזית
      if (st.moved > 5) { e.preventDefault(); e.stopPropagation(); st.moved = 0; return; }
      var item = e.target.closest('.fx-ring__item'), i = items.indexOf(item);
      if (i >= 0 && i !== st.front()) { e.preventDefault(); st.go(i); }
    }, true);
    el.addEventListener('dragstart', function (e) { e.preventDefault(); });
    el.addEventListener('keydown', function (e) {
      var k = { ArrowLeft: 1, ArrowRight: -1 }[e.key];
      if (!k) return;
      e.preventDefault();
      if (getComputedStyle(el).direction !== 'rtl') k = -k;
      st.go((st.front() + k + items.length) % items.length);
    });
    el.addEventListener('focusin', function (e) {
      var i = items.indexOf(e.target.closest('.fx-ring__item'));
      if (i >= 0) st.go(i);
    });
    el.addEventListener('pointerenter', function (e) { if (e.pointerType === 'mouse') st.over = true; });
    el.addEventListener('pointerleave', function () { st.over = false; st.idleAt = performance.now(); });

    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible) wake();
      }).observe(el);
    }
    if ('ResizeObserver' in window) new ResizeObserver(function () { layout(st); render(st); }).observe(el);
    wake();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-ring'), setup);
  }
  // גלילה נותנת לטבעת דחיפה קטנה
  window.addEventListener('scroll', function () {
    var y = window.pageYOffset || 0, dy = Math.max(-60, Math.min(60, y - lastY));
    lastY = y;
    list.forEach(function (st) {
      if (!st.visible || st.drag) return;
      st.target = null;
      st.v += dy * 0.02;
      st.spun = false;
      st.idleAt = performance.now();
    });
    wake();
  }, { passive: true });
  (window.FX = window.FX || {}).ring = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-grid · קנבס אינסופי */
(function () {
  'use strict';
  var mm = window.matchMedia;
  if (mm && mm('(prefers-reduced-motion: reduce)').matches) {          // בלי תנועה: רשת רגילה
    (window.FX = window.FX || {}).grid = function () {};
    return;
  }
  var FINE = mm && mm('(hover: hover) and (pointer: fine)').matches;
  var list = [], running = false, last = 0, lastY = window.pageYOffset || 0;

  function mod(a, b) { return ((a % b) + b) % b; }

  // בונה רשת שגדולה מהמסך בשורה ועמודה לכל כיוון. אם אין מספיק אריחים, משכפלים אותם
  function layout(st) {
    var el = st.el, W = el.clientWidth, H = el.clientHeight, gap = parseFloat(getComputedStyle(el).getPropertyValue('--fx-grid-gap')) || 24;
    var w = st.src[0].offsetWidth, h = 0;
    st.src.forEach(function (n) { h = Math.max(h, n.offsetHeight); });
    if (!w || !h || !W || !H) return;
    st.cw = w + gap;
    st.ch = h + gap;
    var cols = Math.max(2, Math.ceil(W / st.cw) + 2), rows = Math.max(2, Math.ceil(H / st.ch) + 2);
    if (cols % 2) cols++;                                   // מספר זוגי של עמודות, כדי שההיסט בעמודות האי־זוגיות ייסגר יפה
    var need = cols * rows;
    while (st.tiles.length < need) {
      var src = st.src[st.tiles.length % st.src.length], n = st.tiles.length < st.src.length ? src : src.cloneNode(true);
      if (n !== src) {
        n.setAttribute('aria-hidden', 'true');
        n.setAttribute('tabindex', '-1');
        Array.prototype.forEach.call(n.querySelectorAll('a, button'), function (a) { a.setAttribute('tabindex', '-1'); });
        el.appendChild(n);
      }
      st.tiles.push(n);
    }
    while (st.tiles.length > Math.max(need, st.src.length)) el.removeChild(st.tiles.pop());
    st.cols = cols;
    st.rows = rows;
    st.PW = cols * st.cw;
    st.PH = rows * st.ch;
    st.W = W;
    st.H = H;
    render(st);
  }

  function render(st) {
    var cw = st.cw, ch = st.ch;
    st.tiles.forEach(function (n, k) {
      var c = k % st.cols, r = Math.floor(k / st.cols);
      var x = mod(c * cw + st.ox, st.PW) - cw;
      var y = mod(r * ch + (c % 2 ? ch / 2 : 0) + st.oy, st.PH) - ch;
      n.style.transform = 'translate3d(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px,0)';
    });
  }

  function frame(now) {
    var dt = last ? Math.min((now - last) / 1000, 0.05) : 0.016, again = false;
    last = now;
    list.forEach(function (st) {
      if (!st.visible || !st.PW) return;
      again = true;
      if (!st.drag) {
        var f = Math.pow(0.06, dt);                          // תנופה שדועכת, ואז סחיפה איטית
        st.vx = st.vx * f + st.driftX * (1 - f);
        st.vy = st.vy * f + st.driftY * (1 - f);
        st.ox += st.vx * dt;
        st.oy += st.vy * dt;
      }
      render(st);
    });
    if (again) requestAnimationFrame(frame);
    else { running = false; last = 0; }
  }
  function wake() {
    if (!running && list.length) { running = true; last = 0; requestAnimationFrame(frame); }
  }

  function setup(el) {
    if (el.__fxGrid) return;
    var src = Array.prototype.slice.call(el.children);
    if (src.length < 2) return;
    el.classList.add('is-ready');
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var drift = num('data-drift', 16);                      // סחיפה איטית כשאף אחד לא נוגע, בפיקסלים לשנייה. 0 עוצר
    var st = el.__fxGrid = {
      el: el, src: src, tiles: [], cols: 0, rows: 0, cw: 0, ch: 0, PW: 0, PH: 0, W: 0, H: 0,
      ox: 0, oy: 0, vx: 0, vy: 0, driftX: drift * 0.6, driftY: drift,
      scrollK: num('data-scroll', 0.5),                      // כמה הגלילה בעמוד מזיזה את הרשת
      drag: null, moved: 0, visible: true
    };
    layout(st);
    list.push(st);

    el.addEventListener('pointerdown', function (e) {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      st.drag = { id: e.pointerId, x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY, t: performance.now(), vx: 0, vy: 0, cap: false };
      st.moved = 0;
      wake();
    });
    el.addEventListener('pointermove', function (e) {
      var d = st.drag;
      if (!d || e.pointerId !== d.id) return;
      var now = performance.now(), dx = e.clientX - d.x, dy = e.clientY - d.y, dt = Math.max(now - d.t, 1) / 1000;
      if (e.pointerType !== 'mouse') dy = 0;                 // במגע הגלילה למעלה ולמטה שייכת לעמוד
      d.x = e.clientX;
      d.y = e.clientY;
      d.t = now;
      st.moved = Math.max(st.moved, Math.abs(e.clientX - d.sx) + Math.abs(e.clientY - d.sy));
      if (st.moved > 5 && !d.cap) { d.cap = true; el.classList.add('is-dragging'); try { el.setPointerCapture(e.pointerId); } catch (err) {} }
      st.ox += dx;
      st.oy += dy;
      d.vx = d.vx * 0.5 + dx / dt * 0.5;
      d.vy = d.vy * 0.5 + dy / dt * 0.5;
    });
    function end(e) {
      var d = st.drag;
      if (!d || (e && e.pointerId !== d.id)) return;
      st.drag = null;
      el.classList.remove('is-dragging');
      var fresh = performance.now() - d.t < 90;
      st.vx = fresh ? Math.max(-3000, Math.min(3000, d.vx)) : 0;
      st.vy = fresh ? Math.max(-3000, Math.min(3000, d.vy)) : 0;
      wake();
    }
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
    el.addEventListener('click', function (e) { if (st.moved > 5) { e.preventDefault(); e.stopPropagation(); st.moved = 0; } }, true);
    el.addEventListener('dragstart', function (e) { e.preventDefault(); });
    // משטח מגע במחשב: גלילה הצידה מזיזה את הרשת, גלילה למעלה ולמטה נשארת של העמוד
    el.addEventListener('wheel', function (e) {
      if (Math.abs(e.deltaX) <= Math.abs(e.deltaY)) return;
      e.preventDefault();
      st.ox -= e.deltaX;
      wake();
    }, { passive: false });
    el.addEventListener('focusin', function (e) {          // מקלדת: האריח שקיבל פוקוס מגיע לאמצע
      var t = e.target.closest('.fx-grid > *');
      if (!t) return;
      var r = t.getBoundingClientRect(), g = el.getBoundingClientRect();
      st.ox += (g.left + g.width / 2) - (r.left + r.width / 2);
      st.oy += (g.top + g.height / 2) - (r.top + r.height / 2);
      el.scrollTop = el.scrollLeft = 0;
      render(st);
    });
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible) wake();
      }).observe(el);
    }
    if ('ResizeObserver' in window) new ResizeObserver(function () { layout(st); }).observe(el);
    else window.addEventListener('resize', function () { layout(st); });
    Array.prototype.forEach.call(el.querySelectorAll('img'), function (img) { if (!img.complete) img.addEventListener('load', function () { layout(st); }, { once: true }); });
    wake();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-grid'), setup);
  }
  window.addEventListener('scroll', function () {
    var y = window.pageYOffset || 0, dy = y - lastY;
    lastY = y;
    list.forEach(function (st) { if (st.visible) st.oy -= dy * st.scrollK; });
    wake();
  }, { passive: true });
  (window.FX = window.FX || {}).grid = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-trail · שובל תמונות */
(function () {
  'use strict';
  var mm = window.matchMedia;
  if (mm && mm('(prefers-reduced-motion: reduce)').matches) {          // בלי תנועה: בלי שובל
    (window.FX = window.FX || {}).trail = function () {};
    return;
  }
  var FINE = mm && mm('(hover: hover) and (pointer: fine)').matches;
  var list = [], running = false;

  function spawn(st, x, y, vx, vy) {
    if (!st.srcs.length || !st.pool[0].animate) return;
    var pic = st.pool[st.k % st.pool.length], src = st.srcs[st.k % st.srcs.length];
    st.k++;
    pic.getAnimations().forEach(function (a) { a.cancel(); });
    if (pic.getAttribute('src') !== src) pic.src = src;
    pic.style.zIndex = st.k;
    var w = pic.offsetWidth || 180, h = pic.offsetHeight || w * 1.25;
    var ang = Math.max(-14, Math.min(14, vx * 0.6)) + (Math.random() - 0.5) * 8;
    var s = 0.85 + Math.random() * 0.25, bx = x - w / 2, by = y - h / 2;
    var ox = Math.max(-60, Math.min(60, vx * 3)), oy = Math.max(-60, Math.min(60, vy * 3));
    function at(dx, dy, sc, r) { return 'translate(' + (bx + dx).toFixed(1) + 'px,' + (by + dy).toFixed(1) + 'px) rotate(' + r.toFixed(1) + 'deg) scale(' + sc.toFixed(3) + ')'; }
    // נכנסת בקפיצה בכיוון התנועה, נשארת רגע, ונעלמת כלפי מטה
    pic.animate([
      { transform: at(-ox * 0.3, -oy * 0.3, s * 0.35, ang - 10), opacity: 0 },
      { transform: at(ox * 0.25, oy * 0.25, s * 1.04, ang), opacity: 1, offset: 0.16 },
      { transform: at(ox * 0.3, oy * 0.3, s, ang), opacity: 1, offset: 0.62 },
      { transform: at(ox * 0.35, oy * 0.35 + 40, s * 0.82, ang + 6), opacity: 0 }
    ], { duration: st.life, easing: 'cubic-bezier(.2, .8, .2, 1)', fill: 'forwards' });
  }

  function move(st, x, y, auto) {
    if (st.lx === null) { st.lx = x; st.ly = y; return; }
    var dx = x - st.lx, dy = y - st.ly;
    st.dist += Math.sqrt(dx * dx + dy * dy);
    st.vx = st.vx * 0.6 + dx * 0.4;
    st.vy = st.vy * 0.6 + dy * 0.4;
    st.lx = x;
    st.ly = y;
    if (st.dist >= st.gap * (auto ? 0.7 : 1)) { st.dist = 0; spawn(st, x, y, st.vx, st.vy); }
  }

  // בלי עכבר: סמן דמיוני שמצייר לולאות באזור, כדי שאפשר לראות את השובל גם בטלפון
  function frame(now) {
    var again = false;
    list.forEach(function (st) {
      if (!st.visible || !st.auto) return;
      again = true;                                           // ממתין עד שאף אחד לא נוגע שתי שניות
      if (now - st.touched < 2200) return;
      var t = now / 1000 * 1.5, r = st.el.getBoundingClientRect();
      move(st, r.width * (0.5 + 0.38 * Math.sin(t)), r.height * (0.5 + 0.32 * Math.sin(t * 2 + 0.6)), true);
    });
    if (again) requestAnimationFrame(frame); else running = false;
  }
  function wake() {
    if (!running && list.length) { running = true; requestAnimationFrame(frame); }
  }

  function setup(el) {
    if (el.__fxTrail) return;
    var srcEls = Array.prototype.slice.call(el.querySelectorAll('.fx-trail__img'));
    if (!srcEls.length) return;
    var layer = document.createElement('div'), pool = [];
    layer.className = 'fx-trail__layer';
    layer.setAttribute('aria-hidden', 'true');
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var size = Math.max(6, num('data-pool', 14));
    for (var i = 0; i < size; i++) {
      var p = document.createElement('img');
      p.className = 'fx-trail__pic';
      p.alt = '';
      p.decoding = 'async';
      p.src = srcEls[i % srcEls.length].currentSrc || srcEls[i % srcEls.length].src;
      layer.appendChild(p);
      pool.push(p);
    }
    el.appendChild(layer);
    el.classList.add('is-ready');
    var auto = el.getAttribute('data-auto');
    var st = el.__fxTrail = {
      el: el, pool: pool, srcs: srcEls.map(function (s) { return s.currentSrc || s.src; }), k: 0,
      gap: num('data-gap', 90),                 // כל כמה פיקסלים של תנועה נולדת תמונה
      life: num('data-life', 1300),             // כמה זמן כל תמונה חיה, במילישניות
      auto: auto === 'true' || (auto !== 'false' && !FINE),
      lx: null, ly: null, dist: 0, vx: 0, vy: 0, touched: 0, visible: true
    };
    function local(e) { var r = el.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
    el.addEventListener('pointermove', function (e) { var p = local(e); st.touched = performance.now(); move(st, p[0], p[1]); });
    el.addEventListener('pointerleave', function () { st.lx = st.ly = null; });
    el.addEventListener('pointerdown', function (e) {        // הקשה: שלוש תמונות בבת אחת
      var p = local(e);
      st.touched = performance.now();
      for (var j = 0; j < 3; j++) spawn(st, p[0] + (Math.random() - 0.5) * 70, p[1] + (Math.random() - 0.5) * 50, (Math.random() - 0.5) * 20, (Math.random() - 0.5) * 10);
      st.lx = p[0];
      st.ly = p[1];
    });
    el.addEventListener('pointerup', function (e) { if (e.pointerType !== 'mouse') st.lx = st.ly = null; });
    list.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible) wake();
      }).observe(el);
    }
    wake();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-trail'), setup);
  }
  (window.FX = window.FX || {}).trail = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-wheel · גלגל פרסים */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var NS = 'http://www.w3.org/2000/svg', TAU = Math.PI * 2;
  var MU = 1.1, K = 0.32, C = MU / K;                      // חיכוך: קבוע ועוד חלק שגדל עם המהירות
  var audio = null;

  function make(tag, cls, attrs) {
    var n = document.createElementNS(NS, tag);
    if (cls) n.setAttribute('class', cls);
    for (var a in attrs) n.setAttribute(a, attrs[a]);
    return n;
  }
  function mod(a, b) { return ((a % b) + b) % b; }
  function lum(hex) {
    var c = document.createElement('canvas').getContext('2d');
    c.fillStyle = hex;
    var m = /^#(..)(..)(..)/.exec(c.fillStyle);
    if (!m) return 1;
    return [1, 2, 3].reduce(function (s, i, k) { return s + parseInt(m[i], 16) / 255 * [0.299, 0.587, 0.114][k]; }, 0);
  }
  // כמה הגלגל יסתובב עד שיעצור, אם יוצא במהירות w
  function travel(w) { return w / K - C / K * Math.log(1 + w / C); }
  function speedFor(dist) {                                 // המהירות שצריך כדי לעצור בדיוק אחרי מרחק מסוים
    var lo = 0, hi = 200;
    for (var i = 0; i < 60; i++) { var mid = (lo + hi) / 2; if (travel(mid) < dist) lo = mid; else hi = mid; }
    return (lo + hi) / 2;
  }

  function tick(volume) {                                   // נקישה קצרה כשפין עובר את המחוג
    if (!audio) return;
    var t = audio.currentTime, o = audio.createOscillator(), g = audio.createGain();
    o.type = 'square';
    o.frequency.value = 1400 + Math.random() * 300;
    g.gain.setValueAtTime(0.05 * volume, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.03);
    o.connect(g).connect(audio.destination);
    o.start(t);
    o.stop(t + 0.035);
  }

  function confetti(x, y, colors) {
    var c = document.createElement('canvas'), ctx = c.getContext('2d'), dpr = Math.min(window.devicePixelRatio || 1, 2), parts = [];
    c.className = 'fx-wheel__fx';
    c.setAttribute('aria-hidden', 'true');
    c.width = innerWidth * dpr;
    c.height = innerHeight * dpr;
    document.body.appendChild(c);
    for (var i = 0; i < 150; i++) {
      var a = -Math.PI / 2 + (Math.random() - 0.5) * 2.6, s = 6 + Math.random() * 12;
      parts.push({ x: x, y: y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, r: Math.random() * 6, vr: (Math.random() - 0.5) * 0.3, w: 6 + Math.random() * 6, h: 4 + Math.random() * 4, c: colors[i % colors.length], life: 160 + Math.random() * 60 });
    }
    (function step() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, innerWidth, innerHeight);
      parts = parts.filter(function (p) { return p.life > 0 && p.y < innerHeight + 40; });
      parts.forEach(function (p) {
        p.vy += 0.28; p.vx *= 0.985; p.vy *= 0.985; p.x += p.vx; p.y += p.vy; p.r += p.vr; p.life--;
        ctx.save();
        ctx.globalAlpha = Math.min(1, p.life / 25);
        ctx.translate(p.x, p.y);
        ctx.rotate(p.r);
        ctx.scale(1, Math.cos(p.r * 1.7 + p.life * 0.15));
        ctx.fillStyle = p.c;
        ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        ctx.restore();
      });
      if (parts.length) requestAnimationFrame(step); else c.remove();
    })();
  }

  function setup(el) {
    if (el.__fxWheel) return;
    var items = Array.prototype.slice.call(el.querySelectorAll('li'));
    if (items.length < 2) return;
    var list = items[0].parentElement, cs = getComputedStyle(el), rtl = cs.direction === 'rtl';
    var colors = (cs.getPropertyValue('--fx-wheel-colors') || '').split(',').map(function (s) { return s.trim(); }).filter(Boolean);
    if (!colors.length) colors = ['#ffd21f', '#1d4ce0', '#e5432b', '#0a7b4e', '#f4f3ec', '#14141a'];
    var n = items.length, a = TAU / n, R = 100;
    list.classList.add('fx-wheel__list');

    var stage = document.createElement('div'), svg = make('svg', 'fx-wheel__svg', { viewBox: '-112 -112 224 224', 'aria-hidden': 'true' });
    stage.className = 'fx-wheel__stage';
    svg.appendChild(make('circle', 'fx-wheel__rim', { r: 109 }));
    var rotor = make('g', 'fx-wheel__rotor'), segs = [];
    items.forEach(function (li, i) {                         // פלח לכל פריט ברשימה. פלח 0 מתחיל למעלה
      var t0 = i * a - a / 2 - Math.PI / 2, t1 = t0 + a, color = colors[i % colors.length];
      if (n % colors.length === 1 && i === n - 1) color = colors[1 % colors.length];   // שני פלחים צמודים לא באותו צבע
      var p = make('path', 'fx-wheel__seg', {
        d: 'M0 0L' + (R * Math.cos(t0)).toFixed(2) + ' ' + (R * Math.sin(t0)).toFixed(2) + 'A' + R + ' ' + R + ' 0 0 1 ' + (R * Math.cos(t1)).toFixed(2) + ' ' + (R * Math.sin(t1)).toFixed(2) + 'Z',
        fill: color
      });
      rotor.appendChild(p);
      segs.push(p);
      var label = li.textContent.trim(), size = Math.min(12, 58 / (Math.max(4, label.length) * 0.55));
      var tx = make('text', 'fx-wheel__label', { transform: 'rotate(' + ((t0 + a / 2) * 180 / Math.PI).toFixed(2) + ') translate(65 0)', fill: lum(color) > 0.55 ? '#14141a' : '#ffffff', 'font-size': size.toFixed(1), direction: rtl ? 'rtl' : 'ltr' });
      tx.textContent = label;
      rotor.appendChild(tx);
    });
    for (var i = 0; i < n; i++) {
      var tp = i * a - a / 2 - Math.PI / 2;
      rotor.appendChild(make('circle', 'fx-wheel__peg', { cx: (101 * Math.cos(tp)).toFixed(2), cy: (101 * Math.sin(tp)).toFixed(2), r: 3.6 }));
    }
    svg.appendChild(rotor);
    var pointer = document.createElement('span'), btn = el.querySelector('.fx-wheel__spin') || document.createElement('button'), result = document.createElement('p');
    pointer.className = 'fx-wheel__pointer';
    pointer.setAttribute('aria-hidden', 'true');
    btn.type = 'button';
    btn.className = 'fx-wheel__spin';
    if (!btn.textContent.trim()) btn.textContent = el.getAttribute('data-button') || (rtl ? 'סובבו' : 'Spin');
    result.className = 'fx-wheel__result';
    result.setAttribute('role', 'status');
    stage.appendChild(svg);
    stage.appendChild(pointer);
    stage.appendChild(btn);
    el.insertBefore(stage, el.firstChild);
    el.appendChild(result);
    el.classList.add('is-ready');

    var st = el.__fxWheel = {
      theta: 0, spin: null, drag: null, flap: 0, fv: 0, peg: 0, running: false, busy: false,
      sound: el.getAttribute('data-sound') === 'true',
      prefix: el.getAttribute('data-result') || (rtl ? 'יצא לכם:' : 'You got:'),
      colors: (el.getAttribute('data-confetti') || '#ffd21f,#1d4ce0,#e5432b,#0a7b4e,#ffffff').split(',')
    };
    function unlock() {                                      // הצליל נפתח רק אחרי נגיעה של הגולש
      if (!st.sound || audio) return;
      try { audio = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {}
    }
    function place() { rotor.setAttribute('transform', 'rotate(' + (st.theta * 180 / Math.PI).toFixed(3) + ')'); }
    function winner() { return mod(Math.round(-st.theta / a), n); }
    function finish(counted) {
      st.busy = false;
      btn.disabled = false;
      if (!counted) { result.textContent = el.getAttribute('data-weak') || (rtl ? 'סובבו חזק יותר' : 'Spin harder'); return; }
      var i = winner();
      segs.forEach(function (s, k) { s.classList.toggle('is-win', k === i); });
      result.textContent = st.prefix + ' ' + items[i].textContent.trim();
      el.dispatchEvent(new CustomEvent('fx:result', { bubbles: true, detail: { index: i, label: items[i].textContent.trim() } }));
      if (!REDUCE) {
        var r = stage.getBoundingClientRect();
        confetti(r.left + r.width / 2, r.top + r.height * 0.3, st.colors);
      }
    }
    function frame(now) {
      if (st.spin) {
        var t = Math.min((now - st.spin.t0) / 1000, st.spin.end), e = Math.exp(-K * t);
        st.theta = st.spin.th0 + st.spin.s * ((st.spin.w0 + C) / K * (1 - e) - C * t);
        st.omega = st.spin.s * Math.max(0, (st.spin.w0 + C) * e - C);
        if (t >= st.spin.end) { var sp = st.spin; st.spin = null; finish(sp.dist > TAU * 0.9); }
      }
      var peg = Math.floor((st.theta + a / 2) / a);            // פין עבר את המחוג: המחוג נכפף ונשמעת נקישה
      if (peg !== st.peg) {
        var w = Math.abs(st.omega || 0);
        st.flap = -Math.sign(st.omega || 1) * Math.min(32, 8 + w * 2.2);
        if (st.sound) tick(Math.min(1, 0.3 + w / 12));
        st.peg = peg;
      }
      st.fv = (st.fv + (0 - st.flap) * 0.3) * 0.62;
      st.flap += st.fv;
      pointer.style.transform = 'rotate(' + st.flap.toFixed(2) + 'deg)';
      place();
      if (st.spin || st.drag || Math.abs(st.flap) > 0.05 || Math.abs(st.fv) > 0.05) requestAnimationFrame(frame);
      else st.running = false;
    }
    function wake() { if (!st.running) { st.running = true; requestAnimationFrame(frame); } }
    function launch(w0) {                                    // שחרור במהירות w0: הנוסחה הסגורה של החיכוך אומרת בדיוק איפה הוא יעצור
      var s = w0 < 0 ? -1 : 1, w = Math.abs(w0);
      st.spin = { t0: performance.now(), th0: st.theta, s: s, w0: w, end: Math.log((w + C) / C) / K, dist: travel(w) };
      st.busy = true;
      btn.disabled = true;
      result.textContent = '';
      segs.forEach(function (sg) { sg.classList.remove('is-win'); });
      wake();
    }

    btn.addEventListener('click', function () {             // הכפתור בוחר פרס לפי המשקלים, ומסובב בדיוק אליו
      if (st.busy) return;
      unlock();
      var weights = items.map(function (li) { var w = parseFloat(li.getAttribute('data-weight')); return isNaN(w) ? 1 : Math.max(0, w); });
      var sum = weights.reduce(function (x, y) { return x + y; }, 0), pick = Math.random() * sum, idx = 0;
      while (idx < n - 1 && pick > weights[idx]) { pick -= weights[idx]; idx++; }
      var off = (Math.random() - 0.5) * 0.7;
      var goal = -(idx + off) * a, dist = mod(goal - st.theta, TAU) + TAU * (4 + Math.floor(Math.random() * 2));
      if (REDUCE) { st.theta += dist; place(); finish(true); return; }
      launch(speedFor(dist));
    });

    // גרירה: מסובבים את הגלגל ביד וזורקים
    function ang(e) { var r = stage.getBoundingClientRect(); return Math.atan2(e.clientY - r.top - r.height / 2, e.clientX - r.left - r.width / 2); }
    stage.addEventListener('pointerdown', function (e) {
      if (e.target === btn || st.busy || (e.pointerType === 'mouse' && e.button !== 0)) return;
      unlock();
      st.drag = { id: e.pointerId, a: ang(e), t: performance.now(), w: 0 };
      st.omega = 0;
      stage.classList.add('is-dragging');
      try { stage.setPointerCapture(e.pointerId); } catch (err) {}
      wake();
    });
    stage.addEventListener('pointermove', function (e) {
      var d = st.drag;
      if (!d || e.pointerId !== d.id) return;
      var now = performance.now(), na = ang(e), da = na - d.a;
      if (da > Math.PI) da -= TAU; else if (da < -Math.PI) da += TAU;
      st.theta += da;
      d.w = d.w * 0.5 + da / Math.max((now - d.t) / 1000, 0.001) * 0.5;
      st.omega = d.w;
      d.a = na;
      d.t = now;
    });
    function up(e) {
      var d = st.drag;
      if (!d || (e && e.pointerId !== d.id)) return;
      st.drag = null;
      stage.classList.remove('is-dragging');
      var w = performance.now() - d.t < 100 ? Math.max(-40, Math.min(40, d.w)) : 0;
      if (Math.abs(w) > 0.6) launch(w); else st.omega = 0;
    }
    stage.addEventListener('pointerup', up);
    stage.addEventListener('pointercancel', function (e) {         // הדפדפן לקח את התנועה לגלילה: עוצרים בלי לזרוק
      if (!st.drag || e.pointerId !== st.drag.id) return;
      st.drag = null;
      st.omega = 0;
      stage.classList.remove('is-dragging');
    });
    place();
    el.fxWheel = { spin: function () { btn.click(); } };
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-wheel'), setup);
  }
  (window.FX = window.FX || {}).wheel = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-strings · מיתרים */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var NS = 'http://www.w3.org/2000/svg';
  var SCALE = [0, 2, 4, 7, 9];                              // סולם פנטטוני: כל צירוף של מיתרים נשמע טוב
  var audio = null, list = [], running = false, last = 0;

  // צליל של מיתר נפרט (Karplus-Strong): רעש קצר שעובר שוב ושוב דרך ממוצע, ונהיה צליל נקי שדועך
  function pluckBuffer(freq) {
    var rate = audio.sampleRate, len = Math.floor(rate * 1.8), buf = audio.createBuffer(1, len, rate), out = buf.getChannelData(0);
    var period = Math.max(2, Math.round(rate / freq)), ring = new Float32Array(period), i;
    for (i = 0; i < period; i++) ring[i] = Math.random() * 2 - 1;
    for (i = 0; i < len; i++) {
      var k = i % period, next = (k + 1) % period;
      out[i] = ring[k];
      ring[k] = (ring[k] + ring[next]) * 0.5 * 0.996;
    }
    return buf;
  }
  function play(st, s, power) {
    if (!st.sound || !audio) return;
    if (!s.buf) s.buf = pluckBuffer(s.freq);
    var src = audio.createBufferSource(), g = audio.createGain();
    src.buffer = s.buf;
    g.gain.value = Math.min(0.35, 0.08 + power * 0.3);
    src.connect(g).connect(audio.destination);
    src.start();
  }

  function layout(st) {
    var W = st.el.clientWidth, H = st.el.clientHeight, n = st.strings.length, pad = st.vertical ? H * 0.08 : W * 0.06;
    st.W = W;
    st.H = H;
    st.svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
    st.strings.forEach(function (s, i) {
      var t = (i + 0.5) / n;
      s.pos = st.vertical ? W * (0.06 + 0.88 * t) : H * (0.08 + 0.84 * t);
      s.a = pad;
      s.b = (st.vertical ? H : W) - pad;
      var w = st.thick + (st.thin - st.thick) * (i / Math.max(1, n - 1));   // מיתרים עבים בצד אחד ודקים בשני
      s.line.style.strokeWidth = w + 'px';
      s.glow.style.strokeWidth = (w + 1.5) + 'px';
    });
    st.strings.forEach(draw.bind(null, st));
  }

  function draw(st, s) {
    var mid = s.a + (s.b - s.a) * s.gp, c = s.pos + s.d * 2, d;
    d = st.vertical ? 'M' + s.pos + ' ' + s.a + 'Q' + c.toFixed(2) + ' ' + mid.toFixed(1) + ' ' + s.pos + ' ' + s.b
      : 'M' + s.a + ' ' + s.pos + 'Q' + mid.toFixed(1) + ' ' + c.toFixed(2) + ' ' + s.b + ' ' + s.pos;
    s.line.setAttribute('d', d);
    s.glow.setAttribute('d', d);
    s.glow.style.opacity = Math.min(1, Math.abs(s.d) / 14 + s.e).toFixed(3);
  }

  function release(st, s, power) {
    s.held = false;
    s.v = 0;
    s.e = Math.min(1, power);
    play(st, s, power);
    wake();
  }

  // תנועת העכבר: מיתר שהעכבר חוצה לאט נתפס ונמתח איתו, ומיתר שחוצים מהר נפרט מיד
  function move(st, x0, y0, x1, y1) {
    var along1 = st.vertical ? y1 : x1, cross0 = st.vertical ? x0 : y0, cross1 = st.vertical ? x1 : y1;
    var speed = Math.abs(cross1 - cross0);
    st.strings.forEach(function (s) {
      var inside = along1 > s.a && along1 < s.b;
      if (s.held) {
        s.d = cross1 - s.pos;
        s.gp = Math.max(0.08, Math.min(0.92, (along1 - s.a) / (s.b - s.a)));
        if (Math.abs(s.d) > st.pull || !inside) { var p = Math.abs(s.d) / st.pull; s.d = Math.sign(s.d) * Math.min(Math.abs(s.d), st.pull); release(st, s, p); }
        else wake();
        return;
      }
      if (!inside || (cross0 - s.pos) * (cross1 - s.pos) > 0 || cross0 === cross1) return;
      s.gp = Math.max(0.08, Math.min(0.92, (along1 - s.a) / (s.b - s.a)));
      if (speed > 26) {                                     // חציה מהירה: פריטה
        s.d = Math.sign(cross1 - cross0) * Math.min(st.pull, 6 + speed * 0.35);
        release(st, s, Math.min(1, speed / 70));
      } else {                                               // חציה איטית: המיתר נתפס ונמתח
        s.held = true;
        s.d = cross1 - s.pos;
        wake();
      }
    });
  }

  function frame(now) {
    var dt = last ? Math.min((now - last) / 1000, 0.033) : 0.016, again = false;
    last = now;
    list.forEach(function (st) {
      st.strings.forEach(function (s) {
        if (s.held) { draw(st, s); again = true; return; }
        if (Math.abs(s.d) < 0.05 && Math.abs(s.v) < 0.5 && s.e < 0.01) { if (s.d || s.e) { s.d = 0; s.e = 0; draw(st, s); } return; }
        // קפיץ עם ריסון: המיתר רוטט ודועך, ומיתרים עבים רוטטים לאט יותר
        var steps = 4, h = dt / steps;
        for (var k = 0; k < steps; k++) {
          s.v += (-s.k * s.d - s.c * s.v) * h;
          s.d += s.v * h;
        }
        s.e *= Math.exp(-dt * 2.2);
        draw(st, s);
        again = true;
      });
    });
    if (again) requestAnimationFrame(frame);
    else { running = false; last = 0; }
  }
  function wake() {
    if (!running && list.length) { running = true; last = 0; requestAnimationFrame(frame); }
  }

  function setup(el) {
    if (el.__fxStrings) return;
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var n = Math.max(2, Math.min(40, Math.round(num('data-count', 12))));
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('class', 'fx-strings__svg');
    svg.setAttribute('aria-hidden', 'true');
    el.insertBefore(svg, el.firstChild);
    var base = num('data-root', 196);                          // התו הנמוך ביותר, בהרץ (סול)
    var st = el.__fxStrings = {
      el: el, svg: svg, strings: [], W: 0, H: 0,
      vertical: el.getAttribute('data-dir') !== 'horizontal',  // מיתרים עומדים כברירת מחדל, כדי שבמגע מחליקים לצד
      pull: num('data-pull', 38),                             // כמה רחוק אפשר למתוח מיתר לפני שהוא משתחרר
      thick: num('data-thick', 3.2), thin: num('data-thin', 1.2),
      sound: el.getAttribute('data-sound') === 'true', lx: null, ly: null
    };
    for (var i = 0; i < n; i++) {
      var line = document.createElementNS(NS, 'path'), glow = document.createElementNS(NS, 'path');
      line.setAttribute('class', 'fx-strings__line');
      glow.setAttribute('class', 'fx-strings__glow');
      svg.appendChild(line);
      svg.appendChild(glow);
      var oct = Math.floor(i / SCALE.length), deg = SCALE[i % SCALE.length], t = i / Math.max(1, n - 1);
      st.strings.push({
        line: line, glow: glow, pos: 0, a: 0, b: 0, d: 0, v: 0, e: 0, gp: 0.5, held: false, buf: null,
        freq: base * Math.pow(2, oct + deg / 12),
        k: Math.pow(2 * Math.PI * (5 + 6 * t), 2), c: 3.2 + 2 * t   // תדר החזותי ודעיכה לכל מיתר
      });
    }
    layout(st);
    if (REDUCE) return;
    list.push(st);

    function local(e) { var r = el.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
    el.addEventListener('pointermove', function (e) {
      var p = local(e);
      if (st.lx !== null) move(st, st.lx, st.ly, p[0], p[1]);
      st.lx = p[0];
      st.ly = p[1];
    });
    function leave() {
      st.lx = st.ly = null;
      st.strings.forEach(function (s) { if (s.held) release(st, s, Math.abs(s.d) / st.pull); });
    }
    el.addEventListener('pointerleave', leave);
    el.addEventListener('pointerup', function (e) { if (e.pointerType !== 'mouse') leave(); });
    el.addEventListener('pointercancel', leave);
    el.addEventListener('pointerdown', function (e) { var p = local(e); st.lx = p[0]; st.ly = p[1]; });

    // כפתור צליל, אם יש: הצליל נפתח רק אחרי לחיצה של הגולש
    var btn = el.querySelector('.fx-strings__sound');
    function setSound(on) {
      st.sound = on;
      if (on && !audio) { try { audio = new (window.AudioContext || window.webkitAudioContext)(); } catch (err) { st.sound = false; } }
      if (audio && audio.state === 'suspended') audio.resume();
      if (btn) btn.setAttribute('aria-pressed', st.sound ? 'true' : 'false');
    }
    if (btn) {
      btn.setAttribute('aria-pressed', 'false');
      btn.addEventListener('click', function () { setSound(!st.sound); });
    }
    if (st.sound) {                                            // data-sound="true": נפתח בנגיעה הראשונה
      st.sound = false;
      el.addEventListener('pointerdown', function first() { setSound(true); el.removeEventListener('pointerdown', first); });
    }
    el.fxStrings = {
      sound: setSound,
      pluck: function (i, power) { var s = st.strings[i]; if (!s) return; s.d = st.pull * (power || 0.8); s.gp = 0.5; release(st, s, power || 0.8); }
    };
    if ('ResizeObserver' in window) new ResizeObserver(function () { layout(st); }).observe(el);
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-strings'), setup);
  }
  (window.FX = window.FX || {}).strings = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-deck · ערימת כרטיסים */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var ARROW = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  function setup(el) {
    if (el.__fxDeck) return;
    var cards = Array.prototype.slice.call(el.children);
    if (cards.length < 2) return;
    var cs = getComputedStyle(el), rtl = cs.direction === 'rtl';
    var depth = parseFloat(cs.getPropertyValue('--fx-deck-depth')) || 14, tilt = parseFloat(cs.getPropertyValue('--fx-deck-tilt')) || 18;
    var order = cards.map(function (c, i) { return i; }), drag = null, busy = false;
    var out = rtl ? 1 : -1;                                 // לאן הכרטיס הנוכחי עף כשעוברים לבא: בעברית ימינה

    var nav = document.createElement('div'), prev = document.createElement('button'), next = document.createElement('button'), count = document.createElement('span');
    nav.className = 'fx-deck__nav';
    prev.type = next.type = 'button';
    prev.innerHTML = next.innerHTML = ARROW;
    prev.setAttribute('aria-label', el.getAttribute('data-prev') || (rtl ? 'הקודם' : 'Previous'));
    next.setAttribute('aria-label', el.getAttribute('data-next') || (rtl ? 'הבא' : 'Next'));
    next.querySelector('svg').style.transform = rtl ? 'scaleX(-1)' : '';
    prev.querySelector('svg').style.transform = rtl ? '' : 'scaleX(-1)';
    count.setAttribute('aria-live', 'polite');
    nav.appendChild(prev);
    nav.appendChild(count);
    nav.appendChild(next);
    if (el.getAttribute('data-nav') !== 'false') el.appendChild(nav);
    el.classList.add('is-ready');

    // מיקום כל כרטיס לפי העומק שלו בערימה. p: כמה הכרטיס העליון כבר זז הצידה (0 עד 1)
    function layout(p) {
      p = p || 0;
      order.forEach(function (ci, k) {
        var c = cards[ci], d = Math.max(0, k - p);
        c.classList.toggle('is-top', k === 0);
        c.style.zIndex = cards.length - k;
        if (k === 0 && drag) return;
        if (c.classList.contains('is-flying')) return;
        c.style.transform = 'translateY(' + (d * depth).toFixed(1) + 'px) scale(' + (1 - d * 0.045).toFixed(4) + ')';
        c.style.opacity = d > 3 ? '0' : '1';
        if (k === 0) { c.removeAttribute('aria-hidden'); c.removeAttribute('inert'); }
        else { c.setAttribute('aria-hidden', 'true'); c.setAttribute('inert', ''); }
      });
      count.textContent = (order[0] + 1) + ' / ' + cards.length;
    }

    function fly(dir, vx, vy) {                              // הכרטיס העליון עף לצד, ואחר כך חוזר לתחתית הערימה
      if (busy) return;
      var ci = order[0], c = cards[ci], w = el.offsetWidth;
      var from = c.style.transform || 'none', x = dir * (w * 1.3 + Math.abs(vx) * 120), y = (vy || 0) * 120 - 30;
      order.push(order.shift());
      if (REDUCE || !c.animate) { layout(); return; }
      busy = true;
      c.classList.add('is-flying');
      var a = c.animate([{ transform: from }, { transform: 'translate(' + x.toFixed(0) + 'px,' + y.toFixed(0) + 'px) rotate(' + (dir * tilt * 1.8) + 'deg)' }],
        { duration: 420, easing: 'cubic-bezier(.3, .6, .4, 1)', fill: 'forwards' });
      layout();
      a.onfinish = function () {
        c.style.transition = 'none';
        c.style.opacity = '0';
        c.classList.remove('is-flying');
        a.cancel();
        layout();
        c.getBoundingClientRect();
        c.style.transition = '';
        busy = false;
      };
    }
    function back() {                                         // הכרטיס האחרון חוזר מהצד לראש הערימה
      if (busy) return;
      order.unshift(order.pop());
      var c = cards[order[0]];
      if (REDUCE || !c.animate) { layout(); return; }
      busy = true;
      c.classList.add('is-flying');
      c.style.opacity = '1';
      var a = c.animate([{ transform: 'translate(' + (out * el.offsetWidth * 1.2) + 'px,-30px) rotate(' + (out * tilt * 1.5) + 'deg)' }, { transform: 'none' }],
        { duration: 480, easing: 'cubic-bezier(.2, .9, .25, 1.1)' });
      layout();
      a.onfinish = function () { c.classList.remove('is-flying'); c.style.transform = 'translateY(0px) scale(1)'; busy = false; };
    }

    next.addEventListener('click', function () { fly(out, 0, 0); });
    prev.addEventListener('click', back);
    el.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowLeft') { e.preventDefault(); if (rtl) fly(out, 0, 0); else back(); }
      if (e.key === 'ArrowRight') { e.preventDefault(); if (rtl) back(); else fly(out, 0, 0); }
    });

    // גרירה: הכרטיס העליון נע עם היד ונוטה. אחרי שליש רוחב, או בזריקה מהירה, הוא עף
    el.addEventListener('pointerdown', function (e) {
      var c = e.target.closest('.fx-deck > *');
      if (!c || busy || c !== cards[order[0]] || (e.pointerType === 'mouse' && e.button !== 0)) return;
      drag = { id: e.pointerId, c: c, x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY, t: performance.now(), vx: 0, vy: 0, moved: 0 };
      c.classList.add('is-dragging');
      try { c.setPointerCapture(e.pointerId); } catch (err) {}
    });
    el.addEventListener('pointermove', function (e) {
      if (!drag || e.pointerId !== drag.id) return;
      var now = performance.now(), dt = Math.max(now - drag.t, 1);
      drag.vx = drag.vx * 0.5 + (e.clientX - drag.x) / dt * 0.5;
      drag.vy = drag.vy * 0.5 + (e.clientY - drag.y) / dt * 0.5;
      drag.x = e.clientX;
      drag.y = e.clientY;
      drag.t = now;
      var dx = e.clientX - drag.sx, dy = e.clientY - drag.sy, w = el.offsetWidth;
      drag.moved = Math.max(drag.moved, Math.abs(dx) + Math.abs(dy));
      drag.c.style.transform = 'translate(' + dx.toFixed(1) + 'px,' + (dy * 0.6).toFixed(1) + 'px) rotate(' + (dx / w * tilt).toFixed(2) + 'deg)';
      layout(Math.min(1, Math.abs(dx) / (w * 0.35)));           // הכרטיסים מתחת עולים שלב
    });
    function up(e) {
      if (!drag || (e && e.pointerId !== drag.id)) return;
      var d = drag, dx = d.x - d.sx, w = el.offsetWidth;
      drag = null;
      d.c.classList.remove('is-dragging');
      if (d.moved > 6) d.c.__fxMoved = true;
      if (Math.abs(dx) > w * 0.32 || Math.abs(d.vx) > 0.65) fly(Math.sign(dx || d.vx), d.vx, d.vy);
      else layout();                                          // לא מספיק: חוזר למקום עם קפיצה
    }
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', function (e) {              // הדפדפן לקח את התנועה לגלילה: הכרטיס חוזר למקום
      if (!drag || e.pointerId !== drag.id) return;
      drag.c.classList.remove('is-dragging');
      drag = null;
      layout();
    });
    el.addEventListener('click', function (e) {
      var c = e.target.closest('.fx-deck > *');
      if (c && c.__fxMoved) { e.preventDefault(); e.stopPropagation(); c.__fxMoved = false; }
    }, true);
    if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '0');
    el.fxDeck = { next: function () { fly(out, 0, 0); }, prev: back };
    layout();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-deck'), setup);
  }
  (window.FX = window.FX || {}).deck = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-stack · ערימה בגלילה */
(function () {
  'use strict';
  if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) {   // בלי תנועה: רשימה רגילה
    (window.FX = window.FX || {}).stack = function () {};
    return;
  }
  var list = [], running = false;

  // לכל כרטיס: כמה כרטיסים כבר עלו עליו, כמספר שבור. ככל שיותר, הוא קטן, נוטה אחורה ומחשיך
  function update(st) {
    var rects = st.cards.map(function (c) { return c.getBoundingClientRect(); }), changed = false;
    st.cards.forEach(function (c, i) {
      var depth = 0, r = rects[i];
      for (var j = i + 1; j < rects.length; j++) depth += Math.max(0, Math.min(1, (r.bottom - rects[j].top) / r.height));
      if (Math.abs(depth - c.__d) < 0.002) return;
      c.__d = depth;
      changed = true;
      c.style.transform = 'perspective(1200px) translateY(' + (-depth * 6).toFixed(2) + 'px) rotateX(' + (Math.min(depth, 3) * st.tilt).toFixed(2) + 'deg) scale(' + (1 - Math.min(depth, 4) * st.shrink).toFixed(4) + ')';
      c.__shade.style.opacity = Math.min(0.6, depth * st.dark).toFixed(3);
    });
    return changed;
  }

  function frame() {
    var again = false;
    list.forEach(function (st) { if (st.visible && update(st)) again = true; });
    if (again) requestAnimationFrame(frame); else running = false;
  }
  function wake() {
    if (!running && list.length) { running = true; requestAnimationFrame(frame); }
  }

  function setup(el) {
    if (el.__fxStack) return;
    var cards = Array.prototype.slice.call(el.children);
    if (cards.length < 2) return;
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    cards.forEach(function (c, i) {
      c.style.setProperty('--fx-i', i);
      c.style.position = 'sticky';                         // גם אם יש position אחר ב-style, הערימה צריכה sticky
      var shade = document.createElement('span');
      shade.className = 'fx-stack__shade';
      shade.setAttribute('aria-hidden', 'true');
      c.appendChild(shade);
      c.__shade = shade;
      c.__d = -1;
    });
    el.classList.add('is-ready');
    var st = el.__fxStack = {
      el: el, cards: cards, visible: true,
      shrink: num('data-shrink', 0.05),      // כמה כל כרטיס שעולה מקטין את מה שמאחוריו
      tilt: num('data-tilt', 3),             // כמה מעלות הוא נוטה אחורה
      dark: num('data-dark', 0.16)           // כמה הוא מחשיך
    };
    list.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible) wake();
      }).observe(el);
    }
    update(st);
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-stack'), setup);
  }
  window.addEventListener('scroll', wake, { passive: true, capture: true });
  window.addEventListener('resize', wake);
  (window.FX = window.FX || {}).stack = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-story · סיפור בגלילה */
(function () {
  'use strict';
  var mm = window.matchMedia;
  var REDUCE = mm && mm('(prefers-reduced-motion: reduce)').matches;
  var POSES = [[-14, 5, 70], [12, -3, 30], [-8, -6, 62], [15, 4, 24], [-12, 2, 55], [9, -5, 35]];   // הטיה לכל שלב: סיבוב לצד, סיבוב קדימה, מיקום הברק
  var list = [], running = false;

  function show(st, b) {
    var a = st.active;
    if (a === b) return;
    st.active = b;
    var dir = b > a ? 1 : -1, va = st.views[a], vb = st.views[b];
    st.steps.forEach(function (s, i) { s.classList.toggle('is-active', i === b); });
    st.dots.forEach(function (d, i) { d.classList.toggle('is-on', i === b); });
    var pose = POSES[b % POSES.length];
    st.device.style.setProperty('--fx-ry', (st.rtl ? -pose[0] : pose[0]) + 'deg');
    st.device.style.setProperty('--fx-rx', pose[1] + 'deg');
    st.device.style.setProperty('--fx-gx', pose[2] + '%');
    vb.classList.add('is-on');
    if (REDUCE || !vb.animate || a < 0) {
      st.views.forEach(function (v, i) { v.classList.toggle('is-on', i === b); });
      return;
    }
    // המסך החדש נכנס מלמטה (או מלמעלה כשחוזרים), והישן נדחק אחורה ומחשיך
    vb.style.zIndex = 2;
    va.style.zIndex = 1;
    vb.animate([{ transform: 'translateY(' + (dir * 100) + '%)' }, { transform: 'none' }], { duration: 650, easing: 'cubic-bezier(.2, .8, .2, 1)' });
    var out = va.animate([{ transform: 'none', filter: 'brightness(1)' }, { transform: 'translateY(' + (-dir * 22) + '%) scale(.92)', filter: 'brightness(.55)' }], { duration: 650, easing: 'cubic-bezier(.2, .8, .2, 1)' });
    out.onfinish = function () { if (st.active !== a) va.classList.remove('is-on'); };
  }

  // מרכז הטקסט של שלב, לא של כל השורה: בטלפון הטקסט יושב בתחתית השורה, מתחת למכשיר
  function middle(li) {
    var a = li.firstElementChild, z = li.lastElementChild;
    if (!a) { var r = li.getBoundingClientRect(); return r.top + r.height / 2; }
    return (a.getBoundingClientRect().top + z.getBoundingClientRect().bottom) / 2;
  }
  function update(st) {
    var anchor = window.innerHeight * (mm && mm('(max-width: 47.5rem)').matches ? 0.88 : 0.72), b = 0;
    st.steps.forEach(function (s, i) { if (middle(s) < anchor) b = i; });   // השלב האחרון שהטקסט שלו עבר את הקו
    show(st, b);
  }

  function frame() {
    running = false;
    list.forEach(function (st) { if (st.visible) update(st); });
  }
  function wake() {
    if (!running) { running = true; requestAnimationFrame(frame); }
  }

  function setup(el) {
    if (el.__fxStory) return;
    var device = el.querySelector('.fx-story__device'), views = el.querySelectorAll('.fx-story__view'), steps = el.querySelectorAll('.fx-story__steps > li');
    if (!device || !views.length || !steps.length) return;
    var n = Math.min(views.length, steps.length), dotsEl = document.createElement('div');
    dotsEl.className = 'fx-story__dots';
    dotsEl.setAttribute('aria-hidden', 'true');
    var dots = [];
    for (var i = 0; i < n; i++) { var d = document.createElement('i'); dotsEl.appendChild(d); dots.push(d); }
    device.appendChild(dotsEl);
    var st = el.__fxStory = {
      el: el, device: device, views: Array.prototype.slice.call(views, 0, n), steps: Array.prototype.slice.call(steps, 0, n), dots: dots,
      active: -1, visible: true, rtl: getComputedStyle(el).direction === 'rtl'
    };
    st.views.forEach(function (v, i) { if (i) v.setAttribute('aria-hidden', 'true'); });
    show(st, 0);
    list.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible) wake();
      }).observe(el);
    }
    update(st);
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-story'), setup);
  }
  window.addEventListener('scroll', wake, { passive: true, capture: true });
  window.addEventListener('resize', wake);
  (window.FX = window.FX || {}).story = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-fluid · דיו נוזלי */
(function () {
  'use strict';
  var mm = window.matchMedia;
  if (mm && mm('(prefers-reduced-motion: reduce)').matches) {          // בלי תנועה: רק צבע הרקע
    (window.FX = window.FX || {}).fluid = function () {};
    return;
  }
  var FINE = mm && mm('(hover: hover) and (pointer: fine)').matches;

  // שיידרים: כולם מציירים ריבוע שמכסה את כל המרקם, וכל פיקסל מחשב את המצב החדש שלו
  var VS = 'precision highp float;attribute vec2 aPosition;varying vec2 vUv,vL,vR,vT,vB;uniform vec2 texelSize;' +
    'void main(){vUv=aPosition*.5+.5;vL=vUv-vec2(texelSize.x,0.);vR=vUv+vec2(texelSize.x,0.);vT=vUv+vec2(0.,texelSize.y);vB=vUv-vec2(0.,texelSize.y);gl_Position=vec4(aPosition,0.,1.);}';
  var HEAD = '#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\nprecision mediump sampler2D;varying highp vec2 vUv,vL,vR,vT,vB;';
  var FS = {
    splat: HEAD + 'uniform sampler2D uTarget;uniform float aspectRatio,radius;uniform vec3 color;uniform vec2 point;' +
      'void main(){vec2 p=vUv-point;p.x*=aspectRatio;vec3 s=exp(-dot(p,p)/radius)*color;gl_FragColor=vec4(texture2D(uTarget,vUv).xyz+s,1.);}',
    advect: HEAD + 'uniform sampler2D uVelocity,uSource;uniform vec2 texelSize,dyeTexelSize;uniform float dt,dissipation;' +
      'vec4 bilerp(sampler2D s,vec2 uv,vec2 ts){vec2 st=uv/ts-.5;vec2 i=floor(st);vec2 f=fract(st);' +
      'vec4 a=texture2D(s,(i+vec2(.5,.5))*ts),b=texture2D(s,(i+vec2(1.5,.5))*ts),c=texture2D(s,(i+vec2(.5,1.5))*ts),d=texture2D(s,(i+vec2(1.5,1.5))*ts);' +
      'return mix(mix(a,b,f.x),mix(c,d,f.x),f.y);}' +
      'void main(){\n#ifdef MANUAL\nvec2 c=vUv-dt*bilerp(uVelocity,vUv,texelSize).xy*texelSize;vec4 r=bilerp(uSource,c,dyeTexelSize);\n#else\n' +
      'vec2 c=vUv-dt*texture2D(uVelocity,vUv).xy*texelSize;vec4 r=texture2D(uSource,c);\n#endif\ngl_FragColor=r/(1.+dissipation*dt);}',
    divergence: HEAD + 'uniform sampler2D uVelocity;void main(){float L=texture2D(uVelocity,vL).x,R=texture2D(uVelocity,vR).x,T=texture2D(uVelocity,vT).y,B=texture2D(uVelocity,vB).y;' +
      'vec2 C=texture2D(uVelocity,vUv).xy;if(vL.x<0.)L=-C.x;if(vR.x>1.)R=-C.x;if(vT.y>1.)T=-C.y;if(vB.y<0.)B=-C.y;gl_FragColor=vec4(.5*(R-L+T-B),0.,0.,1.);}',
    curl: HEAD + 'uniform sampler2D uVelocity;void main(){float L=texture2D(uVelocity,vL).y,R=texture2D(uVelocity,vR).y,T=texture2D(uVelocity,vT).x,B=texture2D(uVelocity,vB).x;gl_FragColor=vec4(.5*(R-L-T+B),0.,0.,1.);}',
    vorticity: HEAD + 'uniform sampler2D uVelocity,uCurl;uniform float curl,dt;void main(){float L=texture2D(uCurl,vL).x,R=texture2D(uCurl,vR).x,T=texture2D(uCurl,vT).x,B=texture2D(uCurl,vB).x,C=texture2D(uCurl,vUv).x;' +
      'vec2 f=.5*vec2(abs(T)-abs(B),abs(R)-abs(L));f/=length(f)+.0001;f*=curl*C;f.y*=-1.;vec2 v=texture2D(uVelocity,vUv).xy+f*dt;gl_FragColor=vec4(clamp(v,-1000.,1000.),0.,1.);}',
    pressure: HEAD + 'uniform sampler2D uPressure,uDivergence;void main(){float L=texture2D(uPressure,vL).x,R=texture2D(uPressure,vR).x,T=texture2D(uPressure,vT).x,B=texture2D(uPressure,vB).x;' +
      'gl_FragColor=vec4((L+R+B+T-texture2D(uDivergence,vUv).x)*.25,0.,0.,1.);}',
    gradient: HEAD + 'uniform sampler2D uPressure,uVelocity;void main(){float L=texture2D(uPressure,vL).x,R=texture2D(uPressure,vR).x,T=texture2D(uPressure,vT).x,B=texture2D(uPressure,vB).x;' +
      'vec2 v=texture2D(uVelocity,vUv).xy-vec2(R-L,T-B);gl_FragColor=vec4(v,0.,1.);}',
    clear: HEAD + 'uniform sampler2D uTexture;uniform float value;void main(){gl_FragColor=value*texture2D(uTexture,vUv);}',
    display: HEAD + 'uniform sampler2D uTexture;uniform vec3 bg;void main(){vec3 c=texture2D(uTexture,vUv).rgb;float a=max(c.r,max(c.g,c.b));' +
      'vec3 hue=c/max(a,.0001);gl_FragColor=vec4(mix(bg,hue,1.-exp(-a*2.6)),1.);}'
  };

  function hex(c) {
    var x = document.createElement('canvas').getContext('2d');
    x.fillStyle = '#000';
    x.fillStyle = c;
    var m = /^#(..)(..)(..)/.exec(x.fillStyle);
    return m ? [parseInt(m[1], 16) / 255, parseInt(m[2], 16) / 255, parseInt(m[3], 16) / 255] : [0, 0, 0];
  }

  function setup(el) {
    if (el.__fxFluid) return;
    el.__fxFluid = true;
    var canvas = document.createElement('canvas');
    canvas.className = 'fx-fluid__canvas';
    canvas.setAttribute('aria-hidden', 'true');
    var opts = { alpha: false, depth: false, stencil: false, antialias: false, preserveDrawingBuffer: false };
    var gl = canvas.getContext('webgl2', opts), gl2 = !!gl;
    if (!gl) gl = canvas.getContext('webgl', opts);
    if (!gl) return;                                         // בלי WebGL נשאר רק הרקע

    // פורמט מרקם שאפשר לצייר אליו במספרים עשרוניים. בלי זה אין סימולציה
    var type, linear;
    if (gl2) { gl.getExtension('EXT_color_buffer_float'); type = gl.HALF_FLOAT; linear = true; }
    else {
      var hf = gl.getExtension('OES_texture_half_float');
      linear = !!gl.getExtension('OES_texture_half_float_linear');
      type = hf && hf.HALF_FLOAT_OES;
      if (!type) return;
    }
    function renderable(internal, format) {
      var t = gl.createTexture(), f = gl.createFramebuffer();
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texImage2D(gl.TEXTURE_2D, 0, internal, 4, 4, 0, format, type, null);
      gl.bindFramebuffer(gl.FRAMEBUFFER, f);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
      var ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      gl.deleteTexture(t);
      gl.deleteFramebuffer(f);
      return ok ? { internal: internal, format: format } : null;
    }
    var RGBA = gl2 ? renderable(gl.RGBA16F, gl.RGBA) : renderable(gl.RGBA, gl.RGBA);
    if (!RGBA) return;
    var RG = gl2 ? renderable(gl.RG16F, gl.RG) || RGBA : RGBA, R1 = gl2 ? renderable(gl.R16F, gl.RED) || RG : RGBA;

    function compile(kind, src) {
      var s = gl.createShader(kind);
      gl.shaderSource(s, src);
      gl.compileShader(s);
      return gl.getShaderParameter(s, gl.COMPILE_STATUS) ? s : null;
    }
    var vs = compile(gl.VERTEX_SHADER, VS), P = {};
    if (!vs) return;
    for (var k in FS) {
      var src = (k === 'advect' && !linear ? '#define MANUAL\n' : '') + FS[k], fs = compile(gl.FRAGMENT_SHADER, src);
      if (!fs) return;
      var p = gl.createProgram();
      gl.attachShader(p, vs);
      gl.attachShader(p, fs);
      gl.bindAttribLocation(p, 0, 'aPosition');
      gl.linkProgram(p);
      if (!gl.getProgramParameter(p, gl.LINK_STATUS)) return;
      var u = {}, count = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
      for (var j = 0; j < count; j++) { var name = gl.getActiveUniform(p, j).name; u[name] = gl.getUniformLocation(p, name); }
      P[k] = { p: p, u: u };
    }
    var buf = gl.createBuffer(), ibuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, -1, 1, 1, 1, 1, -1]), gl.STATIC_DRAW);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ibuf);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array([0, 1, 2, 0, 2, 3]), gl.STATIC_DRAW);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(0);

    el.insertBefore(canvas, el.firstChild);
    el.classList.add('is-ready');
    var cs = getComputedStyle(el);
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var cfg = {
      sim: 128, dye: FINE ? 1024 : 512,
      dyeFade: num('data-fade', 1.1),             // כמה מהר הדיו דוהה
      velFade: 0.25, pressure: 0.8, iter: 20,
      curl: num('data-curl', 28),                 // כמה הדיו מסתלסל
      radius: num('data-size', 0.28) / 100,       // גודל הכתם של העכבר
      force: 6000
    };
    var colors = (cs.getPropertyValue('--fx-fluid-colors') || '#ffd21f,#1d4ce0,#e5432b').split(',').map(function (c) { return hex(c.trim()); });
    var bg = hex(cs.getPropertyValue('--fx-fluid-bg').trim() || '#0b0f2a');
    var velocity, dye, divergence, curlT, pressure, ci = 0, visible = true, running = false, last = 0, lastMove = 0, nextAuto = 0;

    function fbo(w, h, fmt, filter) {
      gl.activeTexture(gl.TEXTURE0);
      var t = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, fmt.internal, w, h, 0, fmt.format, type, null);
      var f = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, f);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
      gl.viewport(0, 0, w, h);
      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      return { t: t, f: f, w: w, h: h, tx: 1 / w, ty: 1 / h, use: function (id) { gl.activeTexture(gl.TEXTURE0 + id); gl.bindTexture(gl.TEXTURE_2D, t); return id; } };
    }
    function pair(w, h, fmt, filter) {
      var a = fbo(w, h, fmt, filter), b = fbo(w, h, fmt, filter);
      return { w: w, h: h, tx: 1 / w, ty: 1 / h, get read() { return a; }, get write() { return b; }, swap: function () { var t = a; a = b; b = t; } };
    }
    function res(n) {
      var a = canvas.width / canvas.height, lo = Math.round(n), hi = Math.round(n * (a < 1 ? 1 / a : a));
      return a > 1 ? [hi, lo] : [lo, hi];
    }
    function build() {
      var s = res(cfg.sim), d = res(cfg.dye), f = linear ? gl.LINEAR : gl.NEAREST;
      velocity = pair(s[0], s[1], RG, f);
      dye = pair(d[0], d[1], RGBA, f);
      divergence = fbo(s[0], s[1], R1, gl.NEAREST);
      curlT = fbo(s[0], s[1], R1, gl.NEAREST);
      pressure = pair(s[0], s[1], R1, gl.NEAREST);
    }
    function size() {
      var r = el.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      var w = Math.max(1, Math.round(r.width * dpr)), h = Math.max(1, Math.round(r.height * dpr));
      if (w === canvas.width && h === canvas.height && velocity) return;
      canvas.width = w;
      canvas.height = h;
      build();
    }
    function blit(target) {
      if (target) { gl.viewport(0, 0, target.w, target.h); gl.bindFramebuffer(gl.FRAMEBUFFER, target.f); }
      else { gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight); gl.bindFramebuffer(gl.FRAMEBUFFER, null); }
      gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0);
    }
    function use(prog) { gl.useProgram(prog.p); return prog.u; }

    // כתם: מוסיף מהירות לנוזל וצבע לדיו בנקודה אחת
    function splat(x, y, dx, dy, c) {
      var u = use(P.splat), a = canvas.width / canvas.height;
      gl.uniform1i(u.uTarget, velocity.read.use(0));
      gl.uniform1f(u.aspectRatio, a);
      gl.uniform2f(u.point, x, y);
      gl.uniform3f(u.color, dx, dy, 0);
      gl.uniform1f(u.radius, cfg.radius * (a > 1 ? a : 1));
      blit(velocity.write);
      velocity.swap();
      gl.uniform1i(u.uTarget, dye.read.use(0));
      gl.uniform3f(u.color, c[0], c[1], c[2]);
      blit(dye.write);
      dye.swap();
    }
    function color(k) { var c = colors[(k === undefined ? ci : k) % colors.length]; return [c[0] * 0.15, c[1] * 0.15, c[2] * 0.15]; }
    function burst(n) {                                      // כמה כתמים אקראיים בבת אחת
      for (var i = 0; i < n; i++) {
        var c = colors[Math.floor(Math.random() * colors.length)];
        splat(Math.random(), Math.random(), (Math.random() - 0.5) * 1800, (Math.random() - 0.5) * 1800, [c[0] * 0.9, c[1] * 0.9, c[2] * 0.9]);
      }
    }

    function step(dt) {
      gl.disable(gl.BLEND);
      var u = use(P.curl);
      gl.uniform2f(u.texelSize, velocity.tx, velocity.ty);
      gl.uniform1i(u.uVelocity, velocity.read.use(0));
      blit(curlT);
      u = use(P.vorticity);                                    // מחזק מערבולות קטנות, וכך הדיו מסתלסל
      gl.uniform2f(u.texelSize, velocity.tx, velocity.ty);
      gl.uniform1i(u.uVelocity, velocity.read.use(0));
      gl.uniform1i(u.uCurl, curlT.use(1));
      gl.uniform1f(u.curl, cfg.curl);
      gl.uniform1f(u.dt, dt);
      blit(velocity.write);
      velocity.swap();
      u = use(P.divergence);
      gl.uniform2f(u.texelSize, velocity.tx, velocity.ty);
      gl.uniform1i(u.uVelocity, velocity.read.use(0));
      blit(divergence);
      u = use(P.clear);
      gl.uniform1i(u.uTexture, pressure.read.use(0));
      gl.uniform1f(u.value, cfg.pressure);
      blit(pressure.write);
      pressure.swap();
      u = use(P.pressure);                                     // לחץ: הנוזל לא נדחס, אז מה שנכנס צריך לצאת
      gl.uniform2f(u.texelSize, velocity.tx, velocity.ty);
      gl.uniform1i(u.uDivergence, divergence.use(0));
      for (var i = 0; i < cfg.iter; i++) {
        gl.uniform1i(u.uPressure, pressure.read.use(1));
        blit(pressure.write);
        pressure.swap();
      }
      u = use(P.gradient);
      gl.uniform2f(u.texelSize, velocity.tx, velocity.ty);
      gl.uniform1i(u.uPressure, pressure.read.use(0));
      gl.uniform1i(u.uVelocity, velocity.read.use(1));
      blit(velocity.write);
      velocity.swap();
      u = use(P.advect);                                       // הזרם נושא איתו את עצמו ואת הדיו
      gl.uniform2f(u.texelSize, velocity.tx, velocity.ty);
      if (u.dyeTexelSize) gl.uniform2f(u.dyeTexelSize, velocity.tx, velocity.ty);
      var v = velocity.read.use(0);
      gl.uniform1i(u.uVelocity, v);
      gl.uniform1i(u.uSource, v);
      gl.uniform1f(u.dt, dt);
      gl.uniform1f(u.dissipation, cfg.velFade);
      blit(velocity.write);
      velocity.swap();
      if (u.dyeTexelSize) gl.uniform2f(u.dyeTexelSize, dye.tx, dye.ty);
      gl.uniform1i(u.uVelocity, velocity.read.use(0));
      gl.uniform1i(u.uSource, dye.read.use(1));
      gl.uniform1f(u.dissipation, cfg.dyeFade);
      blit(dye.write);
      dye.swap();
    }
    function render() {
      var u = use(P.display);
      gl.uniform1i(u.uTexture, dye.read.use(0));
      gl.uniform3f(u.bg, bg[0], bg[1], bg[2]);
      blit(null);
    }
    function frame(now) {
      if (!visible || gl.isContextLost()) { running = false; return; }
      var dt = last ? Math.min((now - last) / 1000, 0.0167) : 0.0167;
      last = now;
      size();
      if (auto && now - lastMove > 2500 && now > nextAuto) {   // כשאף אחד לא נוגע, כתם אקראי מדי פעם
        nextAuto = now + 1100 + Math.random() * 900;
        var c = colors[Math.floor(Math.random() * colors.length)];
        var a = Math.random() * Math.PI * 2;
        splat(0.2 + Math.random() * 0.6, 0.2 + Math.random() * 0.6, Math.cos(a) * 1600, Math.sin(a) * 1600, [c[0] * 0.6, c[1] * 0.6, c[2] * 0.6]);
      }
      step(dt);
      render();
      requestAnimationFrame(frame);
    }
    function wake() {
      if (!running && visible) { running = true; last = 0; requestAnimationFrame(frame); }
    }

    var auto = el.getAttribute('data-auto') !== 'false', px = null, py = null;
    function local(e) { var r = el.getBoundingClientRect(); return [(e.clientX - r.left) / r.width, 1 - (e.clientY - r.top) / r.height, r]; }
    el.addEventListener('pointermove', function (e) {
      var p = local(e), now = performance.now();
      lastMove = now;
      if (px !== null && p[2].width) {
        var a = p[2].width / p[2].height, dx = (p[0] - px) * (a > 1 ? a : 1), dy = (p[1] - py) / (a < 1 ? a : 1);
        if (Math.abs(dx) + Math.abs(dy) > 0.0004) splat(p[0], p[1], dx * cfg.force, dy * cfg.force, color());
      }
      px = p[0];
      py = p[1];
    });
    el.addEventListener('pointerleave', function () { px = py = null; });
    el.addEventListener('pointerdown', function (e) {        // לחיצה: צבע חדש וכתם גדול
      var p = local(e);
      ci++;
      lastMove = performance.now();
      var c = color();
      for (var i = 0; i < 6; i++) {
        var a = i / 6 * Math.PI * 2;
        splat(p[0], p[1], Math.cos(a) * 900, Math.sin(a) * 900, [c[0] * 2.5, c[1] * 2.5, c[2] * 2.5]);
      }
      if (e.pointerType !== 'mouse') { px = p[0]; py = p[1]; }
    });
    el.addEventListener('pointerup', function (e) { if (e.pointerType !== 'mouse') px = py = null; });
    setInterval(function () { if (performance.now() - lastMove < 900) ci++; }, 1600);   // הצבע של העכבר מתחלף לאט
    canvas.addEventListener('webglcontextlost', function (e) { e.preventDefault(); visible = false; canvas.style.display = 'none'; });

    size();
    burst(5);
    el.fxFluid = { splash: function () { burst(6); } };
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        visible = entries[entries.length - 1].isIntersecting;
        if (visible) wake();
      }).observe(el);
    }
    wake();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-fluid'), setup);
  }
  (window.FX = window.FX || {}).fluid = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-flock · להקת מטוסים */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var list = [], running = false, last = 0;

  // מטוס נייר: כנף עליונה בהירה, כנף תחתונה כהה וקו קיפול. מצויר כשהחרטום פונה ימינה
  function plane(ctx, color, shade) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(13, 0); ctx.lineTo(-9, -7); ctx.lineTo(-4, 0);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = shade;
    ctx.beginPath();
    ctx.moveTo(13, 0); ctx.lineTo(-4, 0); ctx.lineTo(-9, 7);
    ctx.closePath();
    ctx.fill();
  }

  function step(st, dt) {
    var n = st.n, x = st.x, y = st.y, vx = st.vx, vy = st.vy, W = st.W, H = st.H, k = dt * 60;
    var R2 = st.R * st.R, S2 = st.sep * st.sep, px = st.px, py = st.py, i, j;
    for (i = 0; i < n; i++) {
      var ax = 0, ay = 0, cx = 0, cy = 0, sx = 0, sy = 0, c = 0;
      for (j = 0; j < n; j++) {                              // שכנים: מתיישרים, מתקרבים, ושומרים מרחק
        if (i === j) continue;
        var dx = x[j] - x[i], dy = y[j] - y[i];
        if (dx > W / 2) dx -= W; else if (dx < -W / 2) dx += W;
        if (dy > H / 2) dy -= H; else if (dy < -H / 2) dy += H;
        var d2 = dx * dx + dy * dy;
        if (d2 > R2) continue;
        ax += vx[j]; ay += vy[j]; cx += dx; cy += dy; c++;
        if (d2 < S2 && d2 > 0.01) { sx -= dx / d2; sy -= dy / d2; }
      }
      var fx = 0, fy = 0;
      if (c) {
        fx += (ax / c - vx[i]) * 0.045 + cx / c * 0.0035 + sx * 1.6;
        fy += (ay / c - vy[i]) * 0.045 + cy / c * 0.0035 + sy * 1.6;
      }
      if (px !== null) {                                     // העכבר: הלהקה עפה אחריו, אבל לא נכנסת בו
        var mx = px - x[i], my = py - y[i], md = Math.sqrt(mx * mx + my * my) || 1;
        if (md < st.reach) { var pull = md < 70 ? -0.09 : 0.012; fx += mx / md * pull * 4; fy += my / md * pull * 4; }
      }
      st.ang[i] += (Math.random() - 0.5) * 0.12;             // שיטוט קטן, כדי שהתנועה לא תהיה מכנית
      fx += Math.cos(st.ang[i]) * 0.02;
      fy += Math.sin(st.ang[i]) * 0.02;
      var ox = vx[i], oy = vy[i];
      vx[i] += fx * k;
      vy[i] += fy * k;
      var sp = Math.sqrt(vx[i] * vx[i] + vy[i] * vy[i]) || 1, max = st.max * st.z[i], min = st.min * st.z[i];
      if (sp > max) { vx[i] *= max / sp; vy[i] *= max / sp; } else if (sp < min) { vx[i] *= min / sp; vy[i] *= min / sp; }
      var turn = Math.atan2(vy[i], vx[i]) - Math.atan2(oy, ox);
      if (turn > Math.PI) turn -= Math.PI * 2; else if (turn < -Math.PI) turn += Math.PI * 2;
      st.bank[i] += (Math.max(-0.7, Math.min(0.7, turn * 10)) - st.bank[i]) * 0.15;   // מטוס שפונה נוטה על הכנף
      x[i] += vx[i] * k;
      y[i] += vy[i] * k;
      if (x[i] < -20) x[i] += W + 40; else if (x[i] > W + 20) x[i] -= W + 40;   // יוצא מצד אחד ונכנס מהשני
      if (y[i] < -20) y[i] += H + 40; else if (y[i] > H + 20) y[i] -= H + 40;
    }
  }

  function draw(st) {
    var ctx = st.ctx;
    ctx.setTransform(st.dpr, 0, 0, st.dpr, 0, 0);
    ctx.clearRect(0, 0, st.W, st.H);
    for (var q = 0; q < st.n; q++) {
      var i = st.order[q], z = st.z[i];
      ctx.save();
      ctx.globalAlpha = 0.35 + 0.65 * (z - 0.5) / 0.7;
      ctx.translate(st.x[i], st.y[i]);
      ctx.rotate(Math.atan2(st.vy[i], st.vx[i]));
      ctx.scale(z * st.size, z * st.size * (1 - Math.abs(st.bank[i]) * 0.6));
      if (i % 8 === 0) plane(ctx, st.accent, st.accentShade); else plane(ctx, st.color, st.shade);
      ctx.restore();
    }
  }

  function frame(now) {
    var dt = last ? Math.min((now - last) / 1000, 0.05) : 0.016, again = false;
    last = now;
    list.forEach(function (st) {
      if (!st.visible) return;
      again = true;
      step(st, dt);
      draw(st);
    });
    if (again) requestAnimationFrame(frame);
    else { running = false; last = 0; }
  }
  function wake() {
    if (!running && list.length) { running = true; last = 0; requestAnimationFrame(frame); }
  }

  function setup(el) {
    if (el.__fxFlock) return;
    var canvas = document.createElement('canvas'), ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.className = 'fx-flock__canvas';
    canvas.setAttribute('aria-hidden', 'true');
    el.insertBefore(canvas, el.firstChild);
    el.classList.add('is-ready');
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var cs = getComputedStyle(el);
    function rgba(c, a) {
      var x = document.createElement('canvas').getContext('2d');
      x.fillStyle = c;
      var m = /^#(..)(..)(..)/.exec(x.fillStyle);
      return m ? 'rgba(' + parseInt(m[1], 16) + ',' + parseInt(m[2], 16) + ',' + parseInt(m[3], 16) + ',' + a + ')' : c;
    }
    var color = cs.getPropertyValue('--fx-flock-color').trim() || '#fff', accent = cs.getPropertyValue('--fx-flock-accent').trim() || '#ffd21f';
    var st = el.__fxFlock = {
      el: el, canvas: canvas, ctx: ctx, n: 0, W: 0, H: 0, dpr: 1, visible: true, px: null, py: null,
      density: num('data-count', 0),         // מספר המטוסים. בלי זה, לפי גודל האזור
      size: num('data-size', 1.25),          // גודל המטוסים
      R: 80, sep: 30, max: num('data-speed', 2.6), min: 1.2, reach: 340,
      color: color, shade: rgba(color, 0.62), accent: accent, accentShade: rgba(accent, 0.7)
    };
    function resize() {
      var r = el.getBoundingClientRect();
      st.W = Math.max(1, r.width);
      st.H = Math.max(1, r.height);
      st.dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(st.W * st.dpr);
      canvas.height = Math.round(st.H * st.dpr);
      var n = st.density || Math.round(Math.max(18, Math.min(110, st.W * st.H / 9000)));
      if (n !== st.n) {
        st.n = n;
        st.x = new Float32Array(n); st.y = new Float32Array(n); st.vx = new Float32Array(n); st.vy = new Float32Array(n);
        st.z = new Float32Array(n); st.ang = new Float32Array(n); st.bank = new Float32Array(n);
        for (var i = 0; i < n; i++) {
          var a = Math.random() * Math.PI * 2;
          st.x[i] = Math.random() * st.W;
          st.y[i] = Math.random() * st.H;
          st.vx[i] = Math.cos(a) * 2;
          st.vy[i] = Math.sin(a) * 2;
          st.z[i] = 0.5 + Math.random() * 0.7;              // עומק: מטוסים רחוקים קטנים, דהויים ואיטיים
          st.ang[i] = a;
        }
        st.order = Array.prototype.slice.call(st.z).map(function (z, i) { return i; }).sort(function (a, b) { return st.z[a] - st.z[b]; });
      }
      draw(st);
    }
    resize();
    if (REDUCE) return;                                      // בלי תנועה: המטוסים קפואים במקום
    list.push(st);
    function local(e) { var r = el.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
    el.addEventListener('pointermove', function (e) { var p = local(e); st.px = p[0]; st.py = p[1]; });
    el.addEventListener('pointerleave', function () { st.px = st.py = null; });
    el.addEventListener('pointerup', function (e) { if (e.pointerType !== 'mouse') st.px = st.py = null; });
    el.addEventListener('pointerdown', function (e) {        // לחיצה מפזרת את הלהקה
      var p = local(e);
      for (var i = 0; i < st.n; i++) {
        var dx = st.x[i] - p[0], dy = st.y[i] - p[1], d = Math.sqrt(dx * dx + dy * dy) || 1;
        if (d < 260) { var f = (1 - d / 260) * 9; st.vx[i] += dx / d * f; st.vy[i] += dy / d * f; }
      }
    });
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible) wake();
      }).observe(el);
    }
    if ('ResizeObserver' in window) new ResizeObserver(resize).observe(el);
    wake();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-flock'), setup);
  }
  (window.FX = window.FX || {}).flock = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();
