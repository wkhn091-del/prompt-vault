/* fx-curtain · מסך פתיחה */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var ease = function (t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };

  function setup(root) {
    if (root.fxCurtain) return;
    var local = root.hasAttribute('data-local');
    var host = local ? root.parentElement : document.documentElement;
    function num(name, d) { var v = parseFloat(root.getAttribute(name)); return isNaN(v) ? d : v; }
    var panels = Math.max(1, Math.round(num('data-panels', 5)));
    var time = num('data-time', 1700);           // כמה זמן הספירה עד 100
    var timers = [], raf = 0, busy = false;

    root.setAttribute('aria-hidden', 'true');
    root.classList.add('is-run');
    var html = '';
    ['b', 'a'].forEach(function (k) {
      html += '<div class="fx-curtain__layer fx-curtain__layer--' + k + '">' + new Array(panels + 1).join('<i></i>') + '</div>';
    });
    html += '<div class="fx-curtain__hud"><div class="fx-curtain__line"><span class="fx-curtain__count">0</span></div>' +
      (root.getAttribute('data-name') ? '<div class="fx-curtain__line"><span class="fx-curtain__name"></span></div>' : '') +
      '<div class="fx-curtain__bar"></div></div>';
    root.innerHTML = html;
    var hud = root.querySelector('.fx-curtain__hud'), count = root.querySelector('.fx-curtain__count'), bar = root.querySelector('.fx-curtain__bar');
    if (root.getAttribute('data-name')) root.querySelector('.fx-curtain__name').textContent = root.getAttribute('data-name');
    var strips = { a: root.querySelectorAll('.fx-curtain__layer--a i'), b: root.querySelectorAll('.fx-curtain__layer--b i') };
    var ins = (local ? host : document).querySelectorAll('.fx-curtain-in');
    Array.prototype.forEach.call(ins, function (el, i) { el.style.setProperty('--fx-curtain-i', i); });

    function later(fn, ms) { timers.push(setTimeout(fn, ms)); }
    function clear() { timers.forEach(clearTimeout); timers = []; cancelAnimationFrame(raf); }
    function setStrips(list, y, dur, delayFn) {
      Array.prototype.forEach.call(list, function (s, i) {
        s.style.transition = dur ? 'transform ' + dur + 'ms cubic-bezier(.76, 0, .24, 1) ' + delayFn(i) + 'ms' : 'none';
        s.style.transform = 'translate3d(0,' + y + ',0)';
      });
    }
    // הרצועות יוצאות בסדר הקריאה: בעברית מימין לשמאל, באנגלית משמאל לימין
    function order(i) {
      var from = root.getAttribute('data-from') || 'start';
      return from === 'center' ? Math.abs(i - (panels - 1) / 2) : from === 'end' ? panels - 1 - i : i;
    }
    function finish() {
      clear();
      busy = false;
      root.classList.add('is-gone');
      host.classList.remove('fx-curtain-lock', 'fx-curtain-run');
      host.classList.add('fx-curtain-done');
      root.dispatchEvent(new CustomEvent('fx:curtain-done', { bubbles: true }));
    }
    function open() {
      var dur = parseFloat(getComputedStyle(root).getPropertyValue('--fx-curtain-time')) * 1000 || 950;
      hud.classList.add('is-up');
      later(function () {
        host.classList.add('fx-curtain-done');
        setStrips(strips.a, '-101%', dur, function (i) { return order(i) * 70; });
        setStrips(strips.b, '-101%', dur, function (i) { return 150 + order(i) * 70; });
      }, 380);
      later(finish, 380 + 150 + dur + panels * 70 + 60);
    }
    function play() {
      clear();
      busy = true;
      root.classList.remove('is-gone');
      host.classList.remove('fx-curtain-done');
      host.classList.add('fx-curtain-run');
      if (!local) host.classList.add('fx-curtain-lock');
      hud.classList.add('is-reset', 'is-down');
      hud.classList.remove('is-up');
      setStrips(strips.a, '0', 0); setStrips(strips.b, '0', 0);
      count.textContent = '0';
      bar.style.transform = 'scaleX(0)';
      void root.offsetWidth;
      hud.classList.remove('is-reset');
      if (REDUCE) {
        hud.classList.remove('is-down');
        count.textContent = '100';
        bar.style.transform = 'scaleX(1)';
        later(function () {
          root.style.transition = 'opacity .4s ease';
          root.style.opacity = '0';
          host.classList.add('fx-curtain-done');
          later(function () { root.style.opacity = ''; root.style.transition = ''; finish(); }, 420);
        }, 450);
        return;
      }
      later(function () { hud.classList.remove('is-down'); }, 60);
      // הספירה מאטה ועוצרת לרגע בכמה מקומות, כמו טעינה אמיתית
      var stops = [0, 0.16, 0.24, 0.52, 0.6, 0.86, 1], t0 = performance.now() + 250;
      function step(now) {
        var t = Math.max(0, Math.min(1, (now - t0) / time));
        var seg = Math.min(stops.length - 2, Math.floor(t * (stops.length - 1))), f = t * (stops.length - 1) - seg;
        var v = stops[seg] + (stops[seg + 1] - stops[seg]) * ease(f);
        count.textContent = String(Math.round(v * 100));
        bar.style.transform = 'scaleX(' + v.toFixed(4) + ')';
        if (t < 1) raf = requestAnimationFrame(step); else later(open, 180);
      }
      raf = requestAnimationFrame(step);
      later(finish, time + 4200);                 // רשת ביטחון
    }
    function skip() { if (busy && !REDUCE) { clear(); count.textContent = '100'; bar.style.transform = 'scaleX(1)'; open(); } }
    root.addEventListener('click', skip);
    if (!local) document.addEventListener('keydown', function (e) { if (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ') skip(); });

    root.fxCurtain = { play: play, skip: skip };
    var once = root.getAttribute('data-once') === 'session', seen = false;
    try { seen = once && sessionStorage.getItem('fx-curtain') === '1'; if (once) sessionStorage.setItem('fx-curtain', '1'); } catch (e) { seen = false; }
    if (seen) { host.classList.add('fx-curtain-done'); root.classList.add('is-gone'); return; }
    if (!local || root.getAttribute('data-auto') !== 'false') play();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-curtain'), setup);
  }
  (window.FX = window.FX || {}).curtain = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-expand · חלון שנפתח */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var items = [], raf = 0;
  var clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };
  var ease = function (t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };

  function clipped(root) {
    for (var p = root.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      var o = getComputedStyle(p);
      if (/(auto|scroll|hidden)/.test(o.overflowY + o.overflowX)) return true;
    }
    return false;
  }

  function update(st) {
    var r = st.root.getBoundingClientRect(), H = st.stage.offsetHeight;
    var span = Math.max(1, r.height - H), p = clamp(-r.top / span, 0, 1);
    if (st.manual) st.stage.style.transform = 'translate3d(0,' + clamp(-r.top, 0, span).toFixed(1) + 'px,0)';
    if (Math.abs(p - st.p) < 0.0005 && !st.dirty) return;
    st.p = p; st.dirty = false;
    var e = ease(clamp(p / 0.72, 0, 1)), h = st.hole, W = st.stage.offsetWidth;
    // החלון: מהמקום של החור בכותרת ועד כל המסך
    var t = h.top * (1 - e), b = (H - h.bottom) * (1 - e), s = h.left * (1 - e), en = (W - h.right) * (1 - e), rad = st.radius * (1 - e);
    st.frame.style.clipPath = 'inset(' + t.toFixed(1) + 'px ' + en.toFixed(1) + 'px ' + b.toFixed(1) + 'px ' + s.toFixed(1) + 'px round ' + rad.toFixed(1) + 'px)';
    st.media.style.transform = 'scale(' + (1.35 - 0.35 * e).toFixed(4) + ')';
    // המילים זזות החוצה לשני הצדדים ונעלמות
    var push = W * 0.55 * e, fade = 1 - clamp(p / 0.5, 0, 1);
    st.before.forEach(function (el) { el.style.transform = 'translate3d(' + (st.rtl ? push : -push).toFixed(1) + 'px,0,0)'; el.style.opacity = fade.toFixed(3); });
    st.after.forEach(function (el) { el.style.transform = 'translate3d(' + (st.rtl ? -push : push).toFixed(1) + 'px,0,0)'; el.style.opacity = fade.toFixed(3); });
    if (st.tail) {
      var a = clamp((p - 0.74) / 0.2, 0, 1);
      st.tail.style.opacity = a.toFixed(3);
      st.tail.style.transform = 'translate3d(0,' + ((1 - a) * 30).toFixed(1) + 'px,0)';
      st.tail.classList.toggle('is-on', a > 0.5);
    }
    if (p !== st.lastP) { st.lastP = p; st.root.style.setProperty('--fx-expand-p', p.toFixed(3)); }
  }
  function measure(st) {
    // מודדים את החור במצב הפתיחה, בלי ההזזות
    st.before.concat(st.after).forEach(function (el) { el.style.transform = 'none'; });
    var sr = st.stage.getBoundingClientRect(), hr = st.holeEl.getBoundingClientRect();
    st.hole = { top: hr.top - sr.top, bottom: hr.bottom - sr.top, left: hr.left - sr.left, right: hr.right - sr.left };
    st.radius = parseFloat(getComputedStyle(st.holeEl).borderTopLeftRadius) || 0;
    st.rtl = getComputedStyle(st.root).direction === 'rtl';
    st.dirty = true;
  }
  function frame() {
    raf = 0;
    items.forEach(function (st) { if (st.visible) update(st); });
  }
  function wake() { if (!raf) raf = requestAnimationFrame(frame); }

  function setup(root) {
    if (root.fxExpand) return;
    var title = root.querySelector('.fx-expand__title'), holeEl = root.querySelector('.fx-expand__hole'), media = root.querySelector('.fx-expand__media');
    if (!title || !holeEl || !media) return;
    var scroll = parseFloat(root.getAttribute('data-scroll'));
    if (!isNaN(scroll)) root.style.setProperty('--fx-expand-scroll', String(scroll * 100));
    var stage = document.createElement('div');
    stage.className = 'fx-expand__stage';
    var frameEl = document.createElement('div');
    frameEl.className = 'fx-expand__frame';
    holeEl.style.borderRadius = 'var(--fx-expand-radius)';
    var tail = root.querySelector('.fx-expand__after');
    root.insertBefore(stage, root.firstChild);
    stage.appendChild(frameEl);
    frameEl.appendChild(media);
    stage.appendChild(title);
    if (tail) stage.appendChild(tail);
    var kids = Array.prototype.slice.call(title.children), at = kids.indexOf(holeEl);
    var st = { root: root, stage: stage, frame: frameEl, media: media, holeEl: holeEl, tail: tail, before: kids.slice(0, at), after: kids.slice(at + 1), p: -1, visible: false, manual: false };
    root.fxExpand = { refresh: function () { measure(st); wake(); } };
    if (REDUCE) {
      // מצב שקט: התמונה נשארת בחלון הקטן, בלי תנועה
      root.classList.add('is-still');
      var still = function () {
        measure(st);
        st.frame.style.clipPath = 'inset(' + st.hole.top + 'px ' + (stage.offsetWidth - st.hole.right) + 'px ' + (stage.offsetHeight - st.hole.bottom) + 'px ' + st.hole.left + 'px round ' + st.radius + 'px)';
        st.media.style.transform = 'scale(1.1)';
      };
      requestAnimationFrame(still);
      if ('ResizeObserver' in window) new ResizeObserver(still).observe(stage);
      if (document.fonts && document.fonts.ready) document.fonts.ready.then(still);
      return;
    }
    if (clipped(root)) { st.manual = true; stage.classList.add('is-manual'); }
    measure(st);
    if ('ResizeObserver' in window) new ResizeObserver(function () { measure(st); wake(); }).observe(stage);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { measure(st); wake(); });
    items.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (en) { st.visible = en[en.length - 1].isIntersecting; wake(); }, { rootMargin: '50px 0px' }).observe(root);
    } else st.visible = true;
    wake();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-expand'), setup);
  }
  window.addEventListener('scroll', wake, { passive: true });
  window.addEventListener('resize', wake);
  (window.FX = window.FX || {}).expand = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-deck · חפיסה */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var items = [], raf = 0;
  var clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };
  var ease = function (t) { return 1 - Math.pow(1 - t, 3); };

  function clipped(root) {
    for (var p = root.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      var o = getComputedStyle(p);
      if (/(auto|scroll|hidden)/.test(o.overflowY + o.overflowX)) return true;
    }
    return false;
  }

  function update(st) {
    var r = st.root.getBoundingClientRect(), H = st.stage.offsetHeight, n = st.cards.length;
    var span = Math.max(1, r.height - H), p = clamp(-r.top / span, 0, 1);
    if (st.manual) st.stage.style.transform = 'translate3d(0,' + clamp(-r.top, 0, span).toFixed(1) + 'px,0)';
    if (Math.abs(p - st.p) < 0.0004) return;
    st.p = p;
    var f = p * (n - 1);
    for (var i = 0; i < n; i++) {
      var c = st.cards[i], enter = i === 0 ? 1 : ease(clamp(f - (i - 1), 0, 1));
      var back = clamp(f - i, 0, 2);                         // כמה שקפים כבר יושבים על השקף הזה
      var b1 = Math.min(back, 1), y = (1 - enter) * 100, s = 1 - b1 * st.scale - Math.max(0, back - 1) * st.scale * 0.5;
      var rot = b1 * st.tilt * (i % 2 ? -1 : 1);
      c.style.transform = 'translate3d(0,' + (y - b1 * 3).toFixed(3) + '%,0) scale(' + s.toFixed(4) + ') rotate(' + rot.toFixed(3) + 'deg)';
      c.style.borderRadius = (b1 * st.radius).toFixed(1) + 'px';
      c.style.setProperty('--fx-deck-dim', (b1 * st.dim).toFixed(3));
      c.style.visibility = back >= 1.98 || enter <= 0.001 ? 'hidden' : '';
      if (st.media[i]) st.media[i].style.transform = 'translate3d(0,' + ((1 - enter) * -14 + b1 * 6).toFixed(2) + '%,0)';
      var on = f > i - 0.5 && f <= i + 0.5;
      if (on && st.active !== i) {
        st.active = i;
        st.root.dispatchEvent(new CustomEvent('fx:deck', { bubbles: true, detail: { index: i } }));
        st.root.setAttribute('data-deck-at', String(i + 1));
      }
    }
  }
  function frame() {
    raf = 0;
    items.forEach(function (st) { if (st.visible) update(st); });
  }
  function wake() { if (!raf) raf = requestAnimationFrame(frame); }

  function setup(root) {
    if (root.fxDeck) return;
    var cards = Array.prototype.slice.call(root.querySelectorAll(':scope > .fx-deck__card'));
    if (!cards.length) return;
    function num(name, d) { var v = parseFloat(root.getAttribute(name)); return isNaN(v) ? d : v; }
    var stage = document.createElement('div');
    stage.className = 'fx-deck__stage';
    root.insertBefore(stage, cards[0]);
    cards.forEach(function (c, i) { stage.appendChild(c); c.style.zIndex = String(i + 1); });
    root.style.setProperty('--fx-deck-n', String(cards.length));
    var st = {
      root: root, stage: stage, cards: cards, p: -1, active: -1, visible: false, manual: false,
      media: cards.map(function (c) { return c.querySelector('.fx-deck__media'); }),
      scale: num('data-scale', 0.1),          // כמה שקף מתכווץ כשהבא עולה עליו
      tilt: num('data-tilt', 2.5),            // בכמה מעלות הוא נוטה
      dim: num('data-dim', 0.55),             // כמה הוא מתכהה
      radius: parseFloat(getComputedStyle(root).getPropertyValue('--fx-deck-radius')) || 22
    };
    root.fxDeck = {
      go: function (i) {
        var r = root.getBoundingClientRect(), span = r.height - stage.offsetHeight;
        var y = window.scrollY + r.top + span * clamp(i, 0, cards.length - 1) / Math.max(1, cards.length - 1);
        window.scrollTo({ top: y, behavior: REDUCE ? 'auto' : 'smooth' });
      }
    };
    if (REDUCE || (clipped(root) && root.getAttribute('data-manual') === 'false')) { root.classList.add('is-flat'); return; }
    if (clipped(root)) { st.manual = true; stage.classList.add('is-manual'); }
    items.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (en) { st.visible = en[en.length - 1].isIntersecting; wake(); }, { rootMargin: '50px 0px' }).observe(root);
    } else st.visible = true;
    wake();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-deck'), setup);
  }
  window.addEventListener('scroll', wake, { passive: true });
  window.addEventListener('resize', function () { items.forEach(function (st) { st.p = -1; }); wake(); });
  (window.FX = window.FX || {}).deck = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-words · מילים נדלקות */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var items = [], raf = 0;
  var clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };

  function clipped(root) {
    for (var p = root.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      var o = getComputedStyle(p);
      if (/(auto|scroll|hidden)/.test(o.overflowY + o.overflowX)) return true;
    }
    return false;
  }
  // מפצלים כל קטע טקסט למילים, בלי לגעת בתגיות שמסביב (mark, b, a וכו')
  function split(node, words) {
    Array.prototype.slice.call(node.childNodes).forEach(function (n) {
      if (n.nodeType === 3) {
        var parts = n.textContent.split(/(\s+)/), frag = document.createDocumentFragment();
        parts.forEach(function (t) {
          if (!t) return;
          if (/^\s+$/.test(t)) { frag.appendChild(document.createTextNode(t)); return; }
          var w = document.createElement('span');
          w.className = 'fx-words__w';
          w.textContent = t;
          frag.appendChild(w);
          words.push(w);
        });
        n.parentNode.replaceChild(frag, n);
      } else if (n.nodeType === 1 && !/^(svg|img|br|script|style)$/i.test(n.tagName)) split(n, words);
    });
  }

  function update(st) {
    var r = st.root.getBoundingClientRect(), vh = window.innerHeight, p;
    if (st.pin) {
      var H = st.stage.offsetHeight, span = Math.max(1, r.height - H);
      if (st.manual) st.stage.style.transform = 'translate3d(0,' + clamp(-r.top, 0, span).toFixed(1) + 'px,0)';
      p = clamp(-r.top / span, 0, 1);
    } else {
      var t = st.text.getBoundingClientRect();
      p = clamp((vh * 0.85 - t.top) / Math.max(1, t.height + vh * 0.35), 0, 1);
    }
    if (Math.abs(p - st.p) < 0.0004) return;
    st.p = p;
    var n = st.words.length, soft = st.soft, lit = p * (n + soft) - soft * 0.5, dim = st.dim;
    for (var i = 0; i < n; i++) {
      var v = clamp((lit - i) / soft + 0.5, 0, 1);
      if (v !== st.vals[i]) {
        st.vals[i] = v;
        st.words[i].style.opacity = (dim + (1 - dim) * v).toFixed(3);
      }
    }
    st.marks.forEach(function (m) {
      var a = st.vals[m.from] || 0, b = st.vals[m.to] || 0, k = clamp((a + b) / 2 * 1.15, 0, 1);
      m.el.style.setProperty('--fx-words-m', k.toFixed(3));
      m.el.classList.toggle('is-lit', k > 0.55);
    });
  }
  function frame() {
    raf = 0;
    items.forEach(function (st) { if (st.visible) update(st); });
  }
  function wake() { if (!raf) raf = requestAnimationFrame(frame); }

  function setup(root) {
    if (root.fxWords) return;
    var text = root.querySelector('.fx-words__text') || root.firstElementChild;
    if (!text) return;
    var scroll = parseFloat(root.getAttribute('data-scroll'));
    if (!isNaN(scroll)) root.style.setProperty('--fx-words-scroll', String(scroll * 100));
    var stage = document.createElement('div');
    stage.className = 'fx-words__stage';
    root.insertBefore(stage, text);
    stage.appendChild(text);
    var words = [];
    split(text, words);
    var marks = Array.prototype.map.call(text.querySelectorAll('mark'), function (m) {
      var ws = m.querySelectorAll('.fx-words__w');
      return { el: m, from: words.indexOf(ws[0]), to: words.indexOf(ws[ws.length - 1]) };
    });
    var st = {
      root: root, stage: stage, text: text, words: words, marks: marks, vals: [], p: -1, visible: false, manual: false,
      pin: root.getAttribute('data-pin') !== 'false',
      soft: Math.max(1, parseFloat(root.getAttribute('data-soft')) || 4),        // על כמה מילים מתפרס המעבר
      dim: parseFloat(getComputedStyle(root).getPropertyValue('--fx-words-dim')) || 0.16
    };
    root.fxWords = { words: words.length };
    if (REDUCE) { root.classList.add('is-still'); return; }
    if (st.pin && clipped(root)) { st.manual = true; stage.classList.add('is-manual'); }
    items.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (en) { st.visible = en[en.length - 1].isIntersecting; wake(); }, { rootMargin: '50px 0px' }).observe(root);
    } else st.visible = true;
    wake();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-words'), setup);
  }
  window.addEventListener('scroll', wake, { passive: true });
  window.addEventListener('resize', function () { items.forEach(function (st) { st.p = -1; }); wake(); });
  (window.FX = window.FX || {}).words = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-tunnel · מנהרה */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var items = [], raf = 0;
  var clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };

  function clipped(root) {
    for (var p = root.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      var o = getComputedStyle(p);
      if (/(auto|scroll|hidden)/.test(o.overflowY + o.overflowX)) return true;
    }
    return false;
  }

  // המיקום של כל פריט: תמונות על ספירלה סביב המרכז, מילים במרכז
  function layout(st) {
    var W = st.stage.offsetWidth, H = st.stage.offsetHeight, rx = Math.min(W * 0.34, 620), ry = Math.min(H * 0.3, 340), k = 0;
    st.parts.forEach(function (it, i) {
      it.z = -(i + 1) * st.gap;
      if (it.word || it.end) { it.x = 0; it.y = 0; }
      else {
        var a = k * 2.399963 + 0.6;
        it.x = Math.cos(a) * rx * (W < 640 ? 0.75 : 1);
        it.y = Math.sin(a) * ry;
        k++;
      }
      it.w = it.el.offsetWidth; it.h = it.el.offsetHeight;
    });
    st.total = st.parts.length * st.gap;
    st.p = -1;
  }
  function update(st) {
    var r = st.root.getBoundingClientRect(), H = st.stage.offsetHeight, span = Math.max(1, r.height - H);
    if (st.manual) st.stage.style.transform = 'translate3d(0,' + clamp(-r.top, 0, span).toFixed(1) + 'px,0)';
    var p = clamp(-r.top / span, 0, 1);
    st.cur += (st.tx - st.cur) * 0.08; st.cury += (st.ty - st.cury) * 0.08;
    var still = Math.abs(st.tx - st.cur) < 0.001 && Math.abs(st.ty - st.cury) < 0.001;
    if (Math.abs(p - st.p) < 0.0002 && still) return false;
    st.p = p;
    var cam = st.gap * 0.55 + p * (st.total - st.gap * 0.55), P = st.persp;     // מתחילים כשהפריט הראשון כבר קרוב
    st.world.style.transform = 'rotateX(' + (-st.cury * 4).toFixed(3) + 'deg) rotateY(' + (st.cur * 6).toFixed(3) + 'deg)';
    st.parts.forEach(function (it) {
      var z = it.z + cam, o;
      // מתגלה מרחוק, ונעלם רגע לפני שהוא עובר את המצלמה
      var reach = it.end ? 1.3 : it.word ? 2.5 : 5;           // מאיזה מרחק (בפריטים) רואים אותו
      var far = clamp(1 - (-z - st.gap * reach) / st.gap, 0, 1);
      var near = it.end ? 1 : clamp((P * (it.word ? 0.35 : 0.8) - z) / (P * 0.35), 0, 1);
      o = far * near;
      if (it.end) z = Math.min(z, 0);
      it.el.style.transform = 'translate3d(' + (it.x - it.w / 2).toFixed(1) + 'px,' + (it.y - it.h / 2).toFixed(1) + 'px,' + z.toFixed(1) + 'px)';
      it.el.style.opacity = o.toFixed(3);
      it.el.style.visibility = o < 0.002 ? 'hidden' : '';
    });
    var at = Math.min(st.parts.length - 1, Math.floor(p * st.parts.length));
    if (at !== st.at) { st.at = at; st.root.dispatchEvent(new CustomEvent('fx:tunnel', { bubbles: true, detail: { index: at, progress: p } })); }
    return !still;
  }
  function frame() {
    raf = 0;
    var again = false;
    items.forEach(function (st) { if (st.visible && update(st)) again = true; });
    if (again) wake();
  }
  function wake() { if (!raf) raf = requestAnimationFrame(frame); }

  function setup(root) {
    if (root.fxTunnel) return;
    var kids = Array.prototype.slice.call(root.children);
    if (!kids.length) return;
    var scroll = parseFloat(root.getAttribute('data-scroll'));
    if (!isNaN(scroll)) root.style.setProperty('--fx-tunnel-scroll', String(scroll * 100));
    var stage = document.createElement('div'), world = document.createElement('div');
    stage.className = 'fx-tunnel__stage';
    world.className = 'fx-tunnel__world';
    stage.appendChild(world);
    root.appendChild(stage);
    var parts = kids.map(function (el) {
      el.classList.add('fx-tunnel__item');
      world.appendChild(el);
      return { el: el, word: el.classList.contains('fx-tunnel__word'), end: el.classList.contains('fx-tunnel__end'), x: 0, y: 0, z: 0, w: 0, h: 0 };
    });
    var st = { root: root, stage: stage, world: world, parts: parts, p: -1, at: -1, visible: false, manual: false, tx: 0, ty: 0, cur: 0, cury: 0,
      gap: parseFloat(root.getAttribute('data-gap')) || 600 };       // המרחק בין פריט לפריט, בפיקסלים
    root.fxTunnel = { refresh: function () { layout(st); wake(); } };
    if (REDUCE) { root.classList.add('is-flat'); return; }
    if (clipped(root)) { st.manual = true; stage.classList.add('is-manual'); }
    function measure() { st.persp = parseFloat(getComputedStyle(stage).perspective) || 900; layout(st); wake(); }
    measure();
    if ('ResizeObserver' in window) new ResizeObserver(measure).observe(stage);
    Array.prototype.forEach.call(root.querySelectorAll('img'), function (img) { if (!img.complete) img.addEventListener('load', measure, { once: true }); });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(measure);
    // העכבר מטה את המנהרה קצת, כדי שירגישו את העומק
    stage.addEventListener('pointermove', function (e) {
      if (e.pointerType !== 'mouse') return;
      var b = stage.getBoundingClientRect();
      st.tx = ((e.clientX - b.left) / b.width - 0.5) * 2;
      st.ty = ((e.clientY - b.top) / b.height - 0.5) * 2;
      wake();
    });
    stage.addEventListener('pointerleave', function () { st.tx = 0; st.ty = 0; wake(); });
    items.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (en) { st.visible = en[en.length - 1].isIntersecting; wake(); }, { rootMargin: '50px 0px' }).observe(root);
    } else st.visible = true;
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-tunnel'), setup);
  }
  window.addEventListener('scroll', wake, { passive: true });
  window.addEventListener('resize', wake);
  (window.FX = window.FX || {}).tunnel = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-trail · שובל תמונות */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var TOUCH = window.matchMedia && matchMedia('(hover: none)').matches;

  function setup(root) {
    if (root.fxTrail) return;
    var list = (root.getAttribute('data-images') || '').split('|').map(function (s) { return s.trim(); }).filter(Boolean);
    Array.prototype.forEach.call(root.querySelectorAll('.fx-trail__pool img'), function (img) { list.push(img.currentSrc || img.src); });
    if (!list.length) return;
    function num(name, d) { var v = parseFloat(root.getAttribute(name)); return isNaN(v) ? d : v; }
    var gap = num('data-gap', 90);                 // כל כמה פיקסלים של תנועה יוצאת תמונה
    var layer = document.createElement('div');
    layer.className = 'fx-trail__layer';
    layer.setAttribute('aria-hidden', 'true');
    root.insertBefore(layer, root.firstChild);
    var pool = [], next = 0, pic = 0, z = 1, last = null, visible = false, autoRaf = 0, autoOn = false, lastHuman = 0;
    for (var i = 0; i < 16; i++) {
      var c = document.createElement('figure');
      c.className = 'fx-trail__card';
      var im = document.createElement('img');
      im.alt = ''; im.decoding = 'async';
      c.appendChild(im);
      layer.appendChild(c);
      pool.push(c);
    }
    var life = function () { return parseFloat(getComputedStyle(root).getPropertyValue('--fx-trail-life')) || 1300; };

    function spawn(x, y, dx, dy) {
      var c = pool[next];
      next = (next + 1) % pool.length;
      var img = c.firstChild, src = list[pic % list.length];
      pic++;
      if (img.getAttribute('src') !== src) img.setAttribute('src', src);
      if (c.__anim) c.__anim.cancel();
      var rot = (Math.random() * 2 - 1) * 9 + Math.max(-8, Math.min(8, (dx || 0) * 0.15));
      var drift = Math.max(-60, Math.min(60, (dx || 0) * 1.2)), fall = 50 + Math.random() * 40;
      c.style.zIndex = String(++z);
      var base = 'translate(' + x + 'px,' + y + 'px) translate(-50%,-50%) ';
      c.__anim = c.animate([
        { transform: base + 'scale(.3) rotate(' + (rot * 2) + 'deg)', opacity: 0 },
        { transform: base + 'scale(1.04) rotate(' + rot + 'deg)', opacity: 1, offset: 0.14 },
        { transform: base + 'scale(1) rotate(' + rot + 'deg)', opacity: 1, offset: 0.55 },
        { transform: 'translate(' + (x + drift) + 'px,' + (y + fall) + 'px) translate(-50%,-50%) scale(.55) rotate(' + (rot * 1.8) + 'deg)', opacity: 0 }
      ], { duration: life(), easing: 'cubic-bezier(.2, .7, .3, 1)', fill: 'both' });
      root.dispatchEvent(new CustomEvent('fx:trail', { bubbles: true, detail: { src: src } }));
    }
    function local(e) { var b = root.getBoundingClientRect(); return { x: e.clientX - b.left, y: e.clientY - b.top }; }
    root.addEventListener('pointermove', function (e) {
      if (REDUCE || e.pointerType === 'touch') return;
      lastHuman = performance.now();
      stopAuto();
      var p = local(e);
      if (!last) { last = p; return; }
      var dx = p.x - last.x, dy = p.y - last.y, d = Math.hypot(dx, dy);
      if (d >= gap) { spawn(p.x, p.y, dx, dy); last = p; }
    });
    root.addEventListener('pointerleave', function () { last = null; });
    // בטלפון: נגיעה מפזרת כמה תמונות סביב האצבע
    root.addEventListener('pointerdown', function (e) {
      if (REDUCE || e.pointerType !== 'touch') return;
      lastHuman = performance.now();
      stopAuto();
      var p = local(e);
      for (var k = 0; k < 3; k++) spawn(p.x + (k - 1) * 46, p.y + (k % 2 ? -30 : 20), (k - 1) * 30, 0);
    });

    // הדגמה אוטומטית: סמן דמיוני מצייר שמונה כשהאזור על המסך ואף אחד לא נוגע
    var autoMode = root.getAttribute('data-auto') || 'touch';
    var wantAuto = !REDUCE && (autoMode === 'always' || (autoMode === 'touch' && TOUCH));
    var t0 = 0, prevP = null;
    function autoStep(now) {
      autoRaf = 0;
      if (!autoOn) return;
      if (!t0) t0 = now;
      var b = root.getBoundingClientRect(), t = (now - t0) / 1000;
      var p = { x: b.width * (0.5 + 0.34 * Math.sin(t * 0.9)), y: b.height * (0.52 + 0.26 * Math.sin(t * 1.8)) };
      if (!prevP) prevP = p;
      var dx = p.x - prevP.x, dy = p.y - prevP.y;
      if (Math.hypot(dx, dy) >= gap * 1.1) { spawn(p.x, p.y, dx, dy); prevP = p; }
      autoRaf = requestAnimationFrame(autoStep);
    }
    function startAuto() { if (wantAuto && !autoOn && performance.now() - lastHuman > 2500) { autoOn = true; t0 = 0; prevP = null; autoRaf = requestAnimationFrame(autoStep); } }
    function stopAuto() { autoOn = false; cancelAnimationFrame(autoRaf); autoRaf = 0; }
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (en) {
        visible = en[en.length - 1].isIntersecting;
        if (visible) startAuto(); else stopAuto();
      }, { threshold: 0.4 }).observe(root);
    }
    setInterval(function () { if (visible) startAuto(); }, 1500);

    root.fxTrail = {
      spawn: function (x, y) { spawn(x, y, 0, 0); },
      play: function () { wantAuto = !REDUCE; lastHuman = 0; stopAuto(); startAuto(); },
      stop: function () { wantAuto = false; stopAuto(); }
    };
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-trail'), setup);
  }
  (window.FX = window.FX || {}).trail = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-collage · קולאז' זרוק */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var FINE = window.matchMedia && matchMedia('(hover: hover) and (pointer: fine)').matches;
  var items = [], raf = 0;
  var clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };

  function frame() {
    raf = 0;
    var again = false;
    items.forEach(function (st) { if (st.visible && step(st)) again = true; });
    if (again) wake();
  }
  function wake() { if (!raf) raf = requestAnimationFrame(frame); }

  function step(st) {
    var r = st.root.getBoundingClientRect(), vh = window.innerHeight, moving = false;
    // כמה המרכז של האזור רחוק ממרכז המסך: לפי זה כל תמונה זזה בקצב שלה
    var off = (r.top + r.height / 2) - vh / 2;
    st.parts.forEach(function (it) {
      if (!it.held && (Math.abs(it.vx) > 0.05 || Math.abs(it.vy) > 0.05)) {
        it.x += it.vx; it.y += it.vy;
        it.vx *= 0.93; it.vy *= 0.93;
        // נתקעת בקצה? קופצת חזרה
        var b = it.bounds;
        if (it.x < b.minX) { it.x = b.minX; it.vx = Math.abs(it.vx) * 0.6; }
        if (it.x > b.maxX) { it.x = b.maxX; it.vx = -Math.abs(it.vx) * 0.6; }
        if (it.y < b.minY) { it.y = b.minY; it.vy = Math.abs(it.vy) * 0.6; }
        if (it.y > b.maxY) { it.y = b.maxY; it.vy = -Math.abs(it.vy) * 0.6; }
        moving = true;
      }
      var par = REDUCE ? 0 : -off * it.depth * 0.35;
      var tilt = clamp(it.vx * 0.9, -22, 22);
      it.tilt += (tilt - it.tilt) * 0.2;
      if (Math.abs(tilt - it.tilt) > 0.05) moving = true;
      it.el.style.setProperty('--dx', it.x.toFixed(1) + 'px');
      it.el.style.setProperty('--dy', (it.y + par).toFixed(1) + 'px');
      it.el.style.setProperty('--rr', 'calc(var(--r, 0deg) + ' + it.tilt.toFixed(2) + 'deg)');
    });
    return moving;
  }

  function setup(root) {
    if (root.fxCollage) return;
    var els = Array.prototype.filter.call(root.children, function (el) { return /^(IMG|FIGURE)$/.test(el.tagName) || el.classList.contains('fx-collage__item'); });
    if (!els.length) return;
    var lang = (root.closest('[lang]') || document.documentElement).getAttribute('lang') || 'he';
    var label = document.createElement('div');
    label.className = 'fx-collage__label';
    label.textContent = root.getAttribute('data-label') || (/^he/.test(lang) ? 'גררו וזרקו' : 'Drag & throw');
    label.setAttribute('aria-hidden', 'true');
    root.appendChild(label);
    var top = els.length + 1;
    var st = { root: root, visible: false, parts: els.map(function (el, i) {
      el.classList.add('fx-collage__item');
      el.setAttribute('draggable', 'false');
      if (!el.style.getPropertyValue('--x')) {
        // בלי מיקום: מפזרים על רשת סביב המרכז
        var cols = Math.ceil(Math.sqrt(els.length)), c = i % cols, rI = Math.floor(i / cols);
        el.style.setProperty('--x', (6 + c * (78 / cols) + (rI % 2) * 6) + '%');
        el.style.setProperty('--y', (8 + rI * (70 / Math.ceil(els.length / cols))) + '%');
        el.style.setProperty('--r', ((i * 37) % 13 - 6) + 'deg');
      }
      return { el: el, x: 0, y: 0, vx: 0, vy: 0, tilt: 0, held: false, depth: parseFloat(el.getAttribute('data-depth')) || ((i % 3) * 0.25 + 0.15), bounds: null };
    }) };
    function bounds() {
      var R = root.getBoundingClientRect();
      st.parts.forEach(function (it) {
        var w = it.el.offsetWidth, h = it.el.offsetHeight, x0 = it.el.offsetLeft, y0 = it.el.offsetTop;
        it.bounds = { minX: -x0 - w * 0.3, maxX: R.width - x0 - w * 0.7, minY: -y0 - h * 0.3, maxY: R.height - y0 - h * 0.7 };
      });
    }
    bounds();
    if ('ResizeObserver' in window) new ResizeObserver(bounds).observe(root);

    // נחיתה: התמונות נופלות למקום כשהאזור נכנס למסך
    var landed = false;
    function land() {
      if (landed || REDUCE || !st.parts[0].el.animate) return;
      landed = true;
      st.parts.forEach(function (it, i) {
        it.el.animate([
          { translate: '0 -75vh', rotate: ((i % 2 ? 1 : -1) * 24) + 'deg', opacity: 0 },
          { translate: '0 0', rotate: '0deg', opacity: 1 }
        ], { duration: 950, delay: i * 85, easing: 'cubic-bezier(.2, 1.25, .45, 1)', fill: 'backwards' });
      });
    }

    // גרירה וזריקה, רק עם עכבר. בטלפון נגיעה מקפיצה את התמונה למעלה
    if (FINE) root.classList.add('is-drag');
    st.parts.forEach(function (it) {
      var hist = [];
      it.el.addEventListener('pointerdown', function (e) {
        it.el.style.zIndex = String(++top);
        if (e.pointerType !== 'mouse' && e.pointerType !== 'pen') {
          if (!REDUCE) it.el.animate([{ translate: '0 0' }, { translate: '0 -14px' }, { translate: '0 0' }], { duration: 380, easing: 'ease-out' });
          return;
        }
        e.preventDefault();
        it.held = true;
        it.el.classList.add('is-held');
        it.el.setPointerCapture(e.pointerId);
        it.grab = { x: e.clientX - it.x, y: e.clientY - it.y };
        it.vx = it.vy = 0;
        hist = [{ x: e.clientX, y: e.clientY, t: performance.now() }];
      });
      it.el.addEventListener('pointermove', function (e) {
        if (!it.held) return;
        it.x = clamp(e.clientX - it.grab.x, it.bounds.minX, it.bounds.maxX);
        it.y = clamp(e.clientY - it.grab.y, it.bounds.minY, it.bounds.maxY);
        hist.push({ x: e.clientX, y: e.clientY, t: performance.now() });
        if (hist.length > 6) hist.shift();
        var a = hist[0], b = hist[hist.length - 1], dt = Math.max(16, b.t - a.t);
        it.vx = (b.x - a.x) / dt * 16; it.vy = (b.y - a.y) / dt * 16;
        wake();
      });
      function drop() {
        if (!it.held) return;
        it.held = false;
        it.el.classList.remove('is-held');
        if (REDUCE || performance.now() - hist[hist.length - 1].t > 90) { it.vx = it.vy = 0; }
        wake();
      }
      it.el.addEventListener('pointerup', drop);
      it.el.addEventListener('pointercancel', drop);
      it.el.addEventListener('pointerenter', function (e) { if (FINE && e.pointerType === 'mouse') label.classList.add('is-on'); });
      it.el.addEventListener('pointerleave', function () { if (!it.held) label.classList.remove('is-on'); });
    });
    root.addEventListener('pointermove', function (e) {
      if (!FINE || e.pointerType !== 'mouse') return;
      var R = root.getBoundingClientRect();
      label.style.left = (e.clientX - R.left) + 'px';
      label.style.top = (e.clientY - R.top) + 'px';
    });
    root.addEventListener('pointerup', function () { label.classList.remove('is-on'); });

    root.fxCollage = {
      reset: function () { st.parts.forEach(function (it) { it.x = it.y = it.vx = it.vy = 0; }); wake(); },
      drop: function () { landed = false; land(); }
    };
    items.push(st);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (en) {
        var e = en[en.length - 1];
        st.visible = e.isIntersecting;
        if (e.isIntersecting && e.intersectionRatio > 0.25) land();
        wake();
      }, { threshold: [0, 0.3] }).observe(root);
    } else { st.visible = true; land(); }
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-collage'), setup);
  }
  window.addEventListener('scroll', wake, { passive: true });
  window.addEventListener('resize', wake);
  (window.FX = window.FX || {}).collage = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-mood · צבעי העמוד */
(function () {
  'use strict';
  var items = [], raf = 0, probe = null;
  var clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };

  // כל צבע שהדפדפן מכיר הופך ל-rgb, כדי שאפשר יהיה לערבב
  function rgb(c) {
    if (!probe) { probe = document.createElement('i'); probe.style.display = 'none'; document.body.appendChild(probe); }
    probe.style.color = '';
    probe.style.color = c;
    var m = getComputedStyle(probe).color.match(/[\d.]+/g) || [0, 0, 0];
    return [+m[0], +m[1], +m[2]];
  }
  function mix(a, b, t) { return 'rgb(' + Math.round(a[0] + (b[0] - a[0]) * t) + ',' + Math.round(a[1] + (b[1] - a[1]) * t) + ',' + Math.round(a[2] + (b[2] - a[2]) * t) + ')'; }

  function apply(st, i, j, t) {
    var a = st.parts[i], b = st.parts[j], key = i + ':' + j + ':' + t.toFixed(3);
    if (key === st.key) return;
    st.key = key;
    var names = ['--fx-mood-bg', '--fx-mood-fg', '--fx-mood-accent'];
    for (var k = 0; k < 3; k++) {
      if (!a.c[k]) continue;
      st.root.style.setProperty(names[k], t <= 0 || !b.c[k] ? a.raw[k] : mix(a.c[k], b.c[k], t));
    }
    var now = t < 0.5 ? i : j;
    if (now !== st.at) {
      st.at = now;
      st.parts.forEach(function (p, n) { p.el.classList.toggle('is-mood', n === now); });
      st.root.setAttribute('data-mood-at', String(now));
      st.root.dispatchEvent(new CustomEvent('fx:mood', { bubbles: true, detail: { index: now, colors: st.parts[now].raw } }));
    }
  }
  function update(st) {
    if (!st.parts.length) return;
    var line = window.innerHeight * st.line, i, n = st.parts.length, hit = -1;
    for (i = 0; i < n; i++) {
      var r = st.parts[i].el.getBoundingClientRect();
      st.parts[i].top = r.top; st.parts[i].bottom = r.bottom;
      if (r.top <= line && r.bottom > line) hit = i;
    }
    // בקצה העליון או התחתון של העמוד: החלק הראשון או האחרון שרואים, גם אם הוא קצר מחצי מסך
    var se = document.scrollingElement || document.documentElement;
    if (se.scrollTop + window.innerHeight >= se.scrollHeight - 2) { for (i = n - 1; i >= 0; i--) if (st.parts[i].top < window.innerHeight && st.parts[i].bottom > 0) { hit = i; break; } }
    else if (se.scrollTop < 2 && st.parts[0].top >= 0 && st.parts[0].top < line) hit = 0;
    if (hit < 0) {
      // בין חלקים, או לפני הראשון: הקרוב ביותר
      var best = 0, d = Infinity;
      for (i = 0; i < n; i++) { var dd = Math.min(Math.abs(st.parts[i].top - line), Math.abs(st.parts[i].bottom - line)); if (dd < d) { d = dd; best = i; } }
      hit = best;
    }
    if (!st.scrub) { apply(st, hit, hit, 0); return; }
    // מצב גלילה: הצבע מתערבב לפי המרחק מהגבול בין חלק לחלק
    var band = window.innerHeight * 0.18, p = st.parts[hit];
    if (hit < n - 1 && p.bottom - line < band) apply(st, hit, hit + 1, clamp(0.5 - (p.bottom - line) / (2 * band), 0, 1));
    else if (hit > 0 && line - p.top < band) apply(st, hit - 1, hit, clamp(0.5 + (line - p.top) / (2 * band), 0, 1));
    else apply(st, hit, hit, 0);
  }
  function frame() { raf = 0; items.forEach(update); }
  function wake() { if (!raf) raf = requestAnimationFrame(frame); }

  function setup(root) {
    if (root.fxMood) return;
    var parts = Array.prototype.filter.call(root.querySelectorAll('[data-mood]'), function (el) {
      return el !== root && el.parentElement.closest('.fx-mood') === root;
    }).map(function (el) {
      var raw = el.getAttribute('data-mood').split(',').map(function (s) { return s.trim(); }).filter(Boolean);
      return { el: el, raw: raw, c: raw.map(rgb) };
    });
    var st = { root: root, parts: parts, at: -1, key: '', scrub: root.getAttribute('data-mode') === 'scrub',
      line: clamp(parseFloat(root.getAttribute('data-line')) || 0.5, 0, 1) };     // איפה במסך עובר הקו שמחליט, 0.5 זה האמצע
    root.fxMood = { refresh: function () { st.key = ''; wake(); } };
    // הצבע הראשון נקבע בלי מעבר, כדי שלא יהבהב בטעינה
    root.classList.add('is-instant');
    update(st);
    requestAnimationFrame(function () { requestAnimationFrame(function () { root.classList.remove('is-instant'); }); });
    items.push(st);
  }

  function init(scope) {
    var list = Array.prototype.slice.call((scope || document).querySelectorAll('.fx-mood'));
    if (scope && scope.classList && scope.classList.contains('fx-mood')) list.unshift(scope);
    if (!scope && document.body.classList.contains('fx-mood') && list.indexOf(document.body) < 0) list.unshift(document.body);
    list.forEach(setup);
  }
  window.addEventListener('scroll', wake, { passive: true });
  window.addEventListener('resize', wake);
  (window.FX = window.FX || {}).mood = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-glide · גלילה חלקה */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var on = false, running = false, target = 0, current = 0, raf = 0, last = 0, ours = -1, ease = 0.1, mult = 1, root = null;
  var clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };
  var max = function () { return Math.max(0, document.documentElement.scrollHeight - window.innerHeight); };

  // האם הגלגלת צריכה לגלול אלמנט פנימי (תיבת קוד, רשימה ארוכה) ולא את העמוד
  function inner(el, dy) {
    for (; el && el !== document.body && el !== document.documentElement; el = el.parentElement) {
      if (el.hasAttribute && el.hasAttribute('data-glide-ignore')) return true;
      var o = getComputedStyle(el).overflowY;
      if ((o === 'auto' || o === 'scroll') && el.scrollHeight > el.clientHeight + 1) {
        if (dy > 0 ? el.scrollTop + el.clientHeight < el.scrollHeight - 1 : el.scrollTop > 0) return true;
      }
      if (/^(TEXTAREA|SELECT)$/.test(el.tagName)) return true;
    }
    return false;
  }
  function tick(now) {
    raf = 0;
    if (!running) return;
    var dt = Math.min(64, now - (last || now)) / 16.667;
    last = now;
    current += (target - current) * (1 - Math.pow(1 - ease, dt || 1));
    if (Math.abs(target - current) < 0.4) { current = target; running = false; }
    ours = Math.round(current);
    window.scrollTo(0, current);
    if (running) raf = requestAnimationFrame(tick);
  }
  function go() { if (!running) { running = true; last = 0; } if (!raf) raf = requestAnimationFrame(tick); }
  function onWheel(e) {
    if (!on || e.defaultPrevented || e.ctrlKey || e.metaKey) return;
    if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
    if (inner(e.target, e.deltaY)) return;
    e.preventDefault();
    var unit = e.deltaMode === 1 ? 40 : e.deltaMode === 2 ? window.innerHeight : 1;
    if (!running) target = current = window.scrollY;
    target = clamp(target + e.deltaY * unit * mult, 0, max());
    go();
  }
  // גלילה שלא באה מאיתנו (מקלדת, פס הגלילה, קישור): עוצרים ומסתנכרנים
  function onScroll() {
    if (Math.abs(window.scrollY - ours) > 2) { running = false; target = current = window.scrollY; }
  }
  function to(where) {
    var y = typeof where === 'number' ? where : where && where.getBoundingClientRect
      ? where.getBoundingClientRect().top + window.scrollY - (parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop) || 0) - (parseFloat(getComputedStyle(where).scrollMarginTop) || 0)
      : null;
    if (y == null) return;
    if (!on) { window.scrollTo({ top: y, behavior: REDUCE ? 'auto' : 'smooth' }); return; }
    if (!running) target = current = window.scrollY;
    target = clamp(y, 0, max());
    go();
  }
  function onClick(e) {
    if (!on || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey) return;
    var a = e.target.closest && e.target.closest('a[href^="#"]');
    if (!a || a.hasAttribute('data-glide-ignore')) return;
    var id = decodeURIComponent(a.getAttribute('href').slice(1)), el = id ? document.getElementById(id) : document.body;
    if (!el) return;
    e.preventDefault();
    to(id ? el : 0);
    if (history.pushState) history.pushState(null, '', '#' + id);
    // המקלדת והקורא ממשיכים מהמקום החדש
    if (id) {
      if (!el.hasAttribute('tabindex') && !/^(A|BUTTON|INPUT|SELECT|TEXTAREA)$/.test(el.tagName)) el.setAttribute('tabindex', '-1');
      el.focus({ preventScroll: true });
    }
  }
  function start() {
    if (REDUCE || on) return;
    on = true;
    document.documentElement.style.scrollBehavior = 'auto';   // אחרת הדפדפן מחליק כל צעד שלנו פעם שנייה
    target = current = window.scrollY;
    if (root) root.classList.add('is-gliding');
  }
  function stop() {
    on = false; running = false;
    document.documentElement.style.scrollBehavior = '';
    if (root) root.classList.remove('is-gliding');
  }

  function init() {
    root = document.querySelector('html.fx-glide, body.fx-glide');
    if (!root || init.done) return;
    init.done = true;
    var e = parseFloat(root.getAttribute('data-ease')), m = parseFloat(root.getAttribute('data-wheel'));
    if (!isNaN(e)) ease = clamp(e, 0.02, 1);       // קטן יותר: חלק ואיטי יותר
    if (!isNaN(m)) mult = clamp(m, 0.2, 3);         // כמה רחוק כל סיבוב של הגלגלת
    window.addEventListener('wheel', onWheel, { passive: false });
    window.addEventListener('scroll', onScroll, { passive: true });
    document.addEventListener('click', onClick);
    window.addEventListener('resize', function () { target = clamp(target, 0, max()); });
    start();
  }
  var api = (window.FX = window.FX || {}).glide = function () { init(); };
  api.start = function () { init(); start(); };
  api.stop = stop;
  api.to = to;
  api.isOn = function () { return on; };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
