/* fx-header · כותרת חכמה */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  function setup(el) {
    if (el.__fxHeader) return;
    var sel = el.getAttribute('data-root'), root = sel ? document.querySelector(sel) : null;   // גלילה בתוך אלמנט במקום בעמוד
    var rtl = getComputedStyle(el).direction === 'rtl';
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var st = el.__fxHeader = {
      offset: num('data-offset', 24),                      // אחרי כמה פיקסלים של גלילה הכותרת מתכווצת
      hide: el.getAttribute('data-hide') !== 'false' && !REDUCE,
      scrolled: false, hidden: false, anchor: 0, active: -1, raf: 0, lock: false, timer: 0, h: 0
    };

    var bar = null;
    if (el.getAttribute('data-progress') !== 'false') {      // פס התקדמות הקריאה
      bar = document.createElement('span');
      bar.className = 'fx-header__progress';
      bar.setAttribute('aria-hidden', 'true');
      el.style.setProperty('--fx-header-from', rtl ? 'right' : 'left');
      el.appendChild(bar);
    }

    // קישורי התפריט שמובילים לאזורים בעמוד: הקישור של האזור שקוראים עכשיו מסומן
    var nav = el.querySelector('nav') || el, links = [], targets = [], ink = null, placed = false;
    Array.prototype.forEach.call(nav.querySelectorAll('a[href^="#"]'), function (a) {
      var id = decodeURIComponent(a.getAttribute('href').slice(1)), t = id && document.getElementById(id);
      if (t) { links.push(a); targets.push(t); }
    });
    if (links.length && nav !== el) {
      if (getComputedStyle(nav).position === 'static') nav.style.position = 'relative';
      ink = document.createElement('span');
      ink.className = 'fx-header__ink';
      ink.setAttribute('aria-hidden', 'true');
      nav.appendChild(ink);
    }

    function y() { return root ? root.scrollTop : window.pageYOffset; }
    function viewH() { return root ? root.clientHeight : window.innerHeight; }
    function maxY() { return root ? root.scrollHeight - root.clientHeight : document.documentElement.scrollHeight - window.innerHeight; }
    function top0() { return root ? root.getBoundingClientRect().top : 0; }

    function placeInk(i) {
      if (!ink) return;
      if (i < 0 || !links[i].offsetWidth) { ink.classList.remove('is-on'); return; }
      var nr = nav.getBoundingClientRect(), ar = links[i].getBoundingClientRect();
      ink.style.width = ar.width + 'px';
      ink.style.transform = 'translateX(' + (ar.left - nr.left - nav.clientLeft).toFixed(1) + 'px)';
      ink.classList.add('is-on');
      if (!placed) { placed = true; ink.offsetWidth; ink.classList.add('is-placed'); }   // בפעם הראשונה בלי החלקה מהצד
    }
    function spy(force) {
      var line = top0() + el.offsetHeight + viewH() * 0.3, cur = -1;
      for (var i = 0; i < targets.length; i++) if (targets[i].getBoundingClientRect().top <= line) cur = i;
      if (maxY() - y() < 4 && y() > 0) cur = targets.length - 1;          // בסוף העמוד: האזור האחרון
      if (cur === st.active && !force) return;
      st.active = cur;
      links.forEach(function (a, k) {
        if (k === cur) a.setAttribute('aria-current', 'location'); else a.removeAttribute('aria-current');
        a.classList.toggle('is-active', k === cur);
      });
      placeInk(cur);
    }

    function update(force) {
      st.raf = 0;
      var cy = y(), h = el.offsetHeight;
      var on = st.scrolled ? cy > st.offset : cy > st.offset + 4;
      if (on !== st.scrolled) { st.scrolled = on; el.classList.toggle('is-scrolled', on); }
      if (st.hide) {                                         // גוללים למטה: הכותרת מפנה מקום. קצת למעלה: היא חוזרת
        if (cy < h * 1.5 || st.lock || el.querySelector('[aria-expanded="true"]')) { st.hidden = false; st.anchor = cy; }
        else if (st.hidden) { if (cy > st.anchor) st.anchor = cy; else if (st.anchor - cy > 12) { st.hidden = false; st.anchor = cy; } }
        else if (cy < st.anchor) st.anchor = cy;
        else if (cy - st.anchor > 12) { st.hidden = true; st.anchor = cy; }
        el.classList.toggle('is-hidden', st.hidden);
      }
      if (bar) { var m = maxY(); bar.style.transform = 'scaleX(' + (m > 0 ? Math.min(1, Math.max(0, cy / m)) : 0).toFixed(4) + ')'; }
      if (links.length) spy(force);
      if (h !== st.h) { st.h = h; (root || document.documentElement).style.setProperty('--fx-header-h', h + 'px'); }
    }
    function onScroll() {
      clearTimeout(st.timer);
      st.timer = setTimeout(function () { st.lock = false; st.anchor = y(); }, 180);
      if (!st.raf) st.raf = requestAnimationFrame(function () { update(false); });
    }
    (root || window).addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', function () { requestAnimationFrame(function () { update(true); }); });
    if ('ResizeObserver' in window) new ResizeObserver(function () { if (placed) placeInk(st.active); }).observe(nav);

    // לחיצה על קישור בתפריט: גלילה רכה לאזור, בלי שהכותרת תסתיר את הכותרת שלו
    el.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a[href^="#"]');
      if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      var id = decodeURIComponent(a.getAttribute('href').slice(1)), t = id ? document.getElementById(id) : null;
      if (!t && id) return;
      e.preventDefault();
      var to = t ? t.getBoundingClientRect().top - top0() + y() - el.offsetHeight + 1 : 0;
      st.lock = true;
      st.hidden = false;
      el.classList.remove('is-hidden');
      (root || window).scrollTo({ top: Math.max(0, to), behavior: REDUCE ? 'auto' : 'smooth' });
      if (!root && history.pushState) history.pushState(null, '', id ? '#' + id : location.pathname + location.search);
      if (t) {
        if (!t.hasAttribute('tabindex')) { t.setAttribute('tabindex', '-1'); t.classList.add('fx-header__target'); }
        t.focus({ preventScroll: true });
      }
    });

    el.fxHeader = { update: function () { update(true); } };
    update(true);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { update(true); });
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-header'), setup);
  }
  (window.FX = window.FX || {}).header = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-reveal · חשיפה בגלילה */
(function () {
  'use strict';
  if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) {   // בלי תנועה: הכול גלוי מההתחלה
    (window.FX = window.FX || {}).reveal = function () {};
    return;
  }
  var io = 'IntersectionObserver' in window ? new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      var st = en.target.__fxReveal;
      if (!st) return;
      if (en.isIntersecting) show(st);
      else if (st.repeat && en.boundingClientRect.top > 0) hide(st);   // יצא מלמטה: ייכנס שוב כשיחזרו אליו
    });
  }, { rootMargin: '0px 0px -8% 0px' }) : null;

  function show(st) { if (!st.shown) { st.shown = true; st.el.classList.add('is-in'); } }
  function hide(st) { if (st.shown) { st.shown = false; st.el.classList.remove('is-in'); } }

  // מפרקים כותרת לשורות כפי שהדפדפן שובר אותן, וכל שורה נכנסת בנפרד
  function split(st) {
    var el = st.el;
    if (st.html === undefined) st.html = el.innerHTML; else el.innerHTML = st.html;
    var parts = [];
    Array.prototype.slice.call(el.childNodes).forEach(function (n) {
      if (n.nodeType === 3) {
        n.textContent.split(/\s+/).forEach(function (w) {
          if (!w) return;
          var s = document.createElement('span');
          s.textContent = w;
          parts.push(s);
        });
      } else if (n.nodeName === 'BR') parts.push(null);
      else if (n.nodeType === 1) parts.push(n);
    });
    el.textContent = '';
    parts.forEach(function (p, i) {
      if (!p) return;
      if (i && parts[i - 1]) el.appendChild(document.createTextNode(' '));
      el.appendChild(p);
    });
    var lines = [], line = null, top = null;
    parts.forEach(function (p) {
      if (!p) { line = null; return; }
      var t = p.getBoundingClientRect().top;
      if (!line || t > top + 3) { line = []; lines.push(line); top = t; }
      line.push(p);
    });
    el.textContent = '';
    lines.forEach(function (ws, i) {
      var outer = document.createElement('span'), inner = document.createElement('span');
      outer.className = 'fx-reveal__line';
      inner.className = 'fx-reveal__lin';
      inner.style.setProperty('--fx-i', i);
      ws.forEach(function (w, k) { if (k) inner.appendChild(document.createTextNode(' ')); inner.appendChild(w); });
      outer.appendChild(inner);
      el.appendChild(outer);
    });
    st.w = el.offsetWidth;
  }

  function setup(el) {
    if (el.__fxReveal) return;
    var mode = el.getAttribute('data-reveal') || 'up', rtl = getComputedStyle(el).direction === 'rtl';
    var st = el.__fxReveal = { el: el, mode: mode, shown: false, repeat: el.getAttribute('data-repeat') === 'true' };
    el.style.setProperty('--fx-reveal-dir', rtl ? 1 : -1);
    if (mode === 'wipe') el.style.setProperty('--fx-reveal-wipe', rtl ? 'inset(0 0 0 100%)' : 'inset(0 100% 0 0)');
    var delay = parseFloat(el.getAttribute('data-delay'));
    if (!isNaN(delay)) el.style.setProperty('--fx-reveal-delay', delay + 'ms');
    if (el.hasAttribute('data-stagger')) {                   // כל ילד נכנס אחרי הקודם
      var gap = parseFloat(el.getAttribute('data-stagger'));
      if (!isNaN(gap)) el.style.setProperty('--fx-reveal-stagger', gap + 'ms');
      Array.prototype.forEach.call(el.children, function (c, i) { c.style.setProperty('--fx-i', i); });
    }
    if (mode === 'lines') {
      split(st);
      if ('ResizeObserver' in window) new ResizeObserver(function () { if (Math.abs(el.offsetWidth - st.w) > 1) split(st); }).observe(el);
      if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { split(st); });
    }
    el.classList.add('is-armed');
    el.fxReveal = {
      replay: function () {                                    // מתחילים מחדש: מסתירים ונכנסים שוב
        hide(st);
        el.offsetWidth;
        var r = el.getBoundingClientRect();
        if (r.top < innerHeight && r.bottom > 0) requestAnimationFrame(function () { show(st); });
      }
    };
    if (io) io.observe(el); else show(st);
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-reveal'), setup);
  }
  (window.FX = window.FX || {}).reveal = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-tabs · לשוניות */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var uid = 0;

  function setup(el) {
    if (el.__fxTabs) return;
    var list = el.querySelector(':scope > .fx-tabs__list');
    var panels = Array.prototype.filter.call(el.children, function (c) { return c !== list; });
    if (!panels.length) return;
    var id = 'fx-tabs-' + (++uid), rtl = getComputedStyle(el).direction === 'rtl', tabs;
    if (list) tabs = Array.prototype.slice.call(list.querySelectorAll('button, a')).slice(0, panels.length);
    else {                                                   // אין רשימה: בונים לשוניות מ-data-tab של כל אזור
      list = document.createElement('div');
      list.className = 'fx-tabs__list';
      tabs = panels.map(function (p, i) {
        var b = document.createElement('button');
        b.textContent = p.getAttribute('data-tab') || ('לשונית ' + (i + 1));
        list.appendChild(b);
        return b;
      });
      el.insertBefore(list, el.firstChild);
    }
    var wrap = document.createElement('div');
    wrap.className = 'fx-tabs__panels';
    el.insertBefore(wrap, panels[0]);
    panels.forEach(function (p) { wrap.appendChild(p); });
    var ink = document.createElement('span');
    ink.className = 'fx-tabs__ink';
    ink.setAttribute('aria-hidden', 'true');
    list.appendChild(ink);

    list.setAttribute('role', 'tablist');
    tabs.forEach(function (b, i) {
      var p = panels[i];
      if (b.tagName === 'BUTTON') b.type = 'button';
      b.classList.add('fx-tabs__tab');
      b.setAttribute('role', 'tab');
      b.id = b.id || id + '-tab-' + i;
      p.id = p.id || id + '-panel-' + i;
      b.setAttribute('aria-controls', p.id);
      p.classList.add('fx-tabs__panel');
      p.setAttribute('role', 'tabpanel');
      p.setAttribute('aria-labelledby', b.id);
      p.tabIndex = 0;
      b.addEventListener('click', function (e) { if (b.tagName === 'A') e.preventDefault(); select(i); });
    });

    var n = tabs.length, cur = -1, cleanup = null;
    function placeInk(instant) {
      var b = tabs[cur];
      if (instant) ink.style.transition = 'none';
      ink.style.width = b.offsetWidth + 'px';
      ink.style.transform = 'translateX(' + b.offsetLeft + 'px)';
      if (instant) { ink.offsetWidth; ink.style.transition = ''; }
    }
    function select(i, focus, instant) {
      i = (i + n) % n;
      if (i === cur) { if (focus) tabs[i].focus(); return; }
      if (cleanup) cleanup();                                       // מעבר קודם שעוד רץ: מסיימים אותו מיד
      var old = cur >= 0 ? panels[cur] : null, neu = panels[i], dir = i > cur ? 1 : -1;
      cur = i;
      tabs.forEach(function (b, k) { b.setAttribute('aria-selected', k === i ? 'true' : 'false'); b.tabIndex = k === i ? 0 : -1; });
      if (focus) tabs[i].focus();
      placeInk(instant || !old);
      if (old && list.scrollWidth > list.clientWidth) tabs[i].scrollIntoView({ block: 'nearest', inline: 'center', behavior: REDUCE ? 'auto' : 'smooth' });
      if (!old || instant || REDUCE || !wrap.animate) {
        panels.forEach(function (p, k) { p.hidden = k !== i; });
        return;
      }
      var h0 = wrap.offsetHeight;
      old.style.position = 'absolute';                              // הישן יוצא מעל, החדש כבר תופס את המקום
      old.style.inset = '0 0 auto 0';
      neu.hidden = false;
      var h1 = wrap.offsetHeight, x = 40 * dir * (rtl ? -1 : 1), ease = 'cubic-bezier(.2, .8, .2, 1)';
      wrap.classList.add('is-moving');
      var a1 = old.animate([{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'translateX(' + (-x) + 'px)' }], { duration: 240, easing: 'ease-in', fill: 'forwards' });
      var a2 = neu.animate([{ opacity: 0, transform: 'translateX(' + x + 'px)' }, { opacity: 1, transform: 'none' }], { duration: 420, delay: 80, easing: ease, fill: 'backwards' });
      var a3 = wrap.animate([{ height: h0 + 'px' }, { height: h1 + 'px' }], { duration: 420, easing: ease });
      var done = false;
      cleanup = function () {
        if (done) return;
        done = true;
        cleanup = null;
        a1.cancel(); a2.cancel(); a3.cancel();
        if (panels[cur] !== old) old.hidden = true;
        old.style.position = '';
        old.style.inset = '';
        wrap.classList.remove('is-moving');
      };
      a2.onfinish = cleanup;
      el.dispatchEvent(new CustomEvent('fx:tab', { bubbles: true, detail: { index: i, tab: tabs[i], panel: neu } }));
    }

    // מקלדת: חצים עוברים בין הלשוניות (בעברית שמאלה = הבאה), Home ו-End לקצוות
    list.addEventListener('keydown', function (e) {
      var i = tabs.indexOf(document.activeElement);
      if (i < 0) return;
      var next = rtl ? 'ArrowLeft' : 'ArrowRight', prev = rtl ? 'ArrowRight' : 'ArrowLeft';
      if (e.key === next) select(i + 1, true);
      else if (e.key === prev) select(i - 1, true);
      else if (e.key === 'Home') select(0, true);
      else if (e.key === 'End') select(n - 1, true);
      else return;
      e.preventDefault();
    });
    // במסך מגע: החלקה על התוכן עוברת ללשונית הבאה או הקודמת
    var sw = null;
    wrap.addEventListener('pointerdown', function (e) { sw = e.pointerType === 'mouse' ? null : { x: e.clientX, y: e.clientY }; });
    wrap.addEventListener('pointerup', function (e) {
      if (!sw) return;
      var dx = e.clientX - sw.x, dy = e.clientY - sw.y;
      sw = null;
      if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) select(cur + ((dx > 0) === rtl ? 1 : -1));
    });
    wrap.addEventListener('pointercancel', function () { sw = null; });

    var start = 0;
    tabs.forEach(function (b, k) { if (b.getAttribute('aria-selected') === 'true') start = k; });
    var hash = decodeURIComponent(location.hash.slice(1));
    panels.forEach(function (p, k) { if (hash && p.id === hash) start = k; });
    el.classList.add('is-ready');
    select(start, false, true);
    window.addEventListener('hashchange', function () {
      var h = decodeURIComponent(location.hash.slice(1));
      panels.forEach(function (p, k) { if (h && p.id === h) select(k); });
    });
    if ('ResizeObserver' in window) new ResizeObserver(function () { placeInk(true); }).observe(list);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { placeInk(true); });
    el.__fxTabs = true;
    el.fxTabs = { select: function (i) { select(i); } };
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-tabs'), setup);
  }
  (window.FX = window.FX || {}).tabs = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-faq · שאלות נפוצות */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var EASE = 'cubic-bezier(.2, .8, .2, 1)';

  // טקסט להשוואה: בלי ניקוד, בלי גרשיים ובלי סימני פיסוק
  function norm(s) {
    return s.toLowerCase().replace(/[֑-ׇ]/g, '').replace(/["'`׳״]/g, '').replace(/[-‐-―.,:;!?()]/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function esc(s) { return s.replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  // גובה שמשתנה ברכות. מתחילים מהגובה הנוכחי, גם אם תנועה קודמת נעצרה באמצע
  function slide(node, item, key, show, done) {
    var from = item[key] ? node.offsetHeight : (show ? 0 : node.offsetHeight);
    if (item[key]) { item[key].onfinish = null; item[key].cancel(); }
    var to = show ? node.scrollHeight : 0;
    node.style.overflow = 'hidden';
    var a = item[key] = node.animate([{ height: from + 'px', opacity: show ? 0.2 : 1 }, { height: to + 'px', opacity: show ? 1 : 0 }], { duration: show ? 360 : 260, easing: show ? EASE : 'cubic-bezier(.4, 0, .2, 1)' });
    a.onfinish = function () { item[key] = null; node.style.overflow = ''; if (done) done(); };
  }

  function setup(el) {
    if (el.__fxFaq) return;
    var single = el.getAttribute('data-single') === 'true', items = [];
    Array.prototype.forEach.call(el.querySelectorAll('details'), function (d) {
      var sum = d.querySelector('summary');
      if (!sum) return;
      var body = document.createElement('div'), inner = document.createElement('div'), q = document.createElement('span'), icon = document.createElement('span');
      body.className = 'fx-faq__body';
      inner.className = 'fx-faq__inner';
      while (sum.nextSibling) inner.appendChild(sum.nextSibling);
      body.appendChild(inner);
      d.appendChild(body);
      q.className = 'fx-faq__q';
      while (sum.firstChild) q.appendChild(sum.firstChild);
      icon.className = 'fx-faq__icon';
      icon.setAttribute('aria-hidden', 'true');
      sum.appendChild(q);
      sum.appendChild(icon);
      var it = { d: d, body: body, q: q, html: q.innerHTML, plain: q.textContent, text: norm(q.textContent + ' ' + inner.textContent), open: d.open, visible: true, a: null, v: null };
      d.classList.toggle('is-open', d.open);
      sum.addEventListener('click', function (e) { e.preventDefault(); toggle(it, !it.open); });
      items.push(it);
    });
    if (!items.length) return;
    el.__fxFaq = true;

    function toggle(it, open, instant) {
      if (open === it.open) return;
      it.open = open;
      it.d.classList.toggle('is-open', open);
      if (open && single) items.forEach(function (o) { if (o !== it) toggle(o, false); });   // רק שאלה אחת פתוחה בכל רגע
      if (REDUCE || instant || !it.body.animate) { it.d.open = open; return; }
      if (open) { it.d.open = true; slide(it.body, it, 'a', true); }
      else slide(it.body, it, 'a', false, function () { if (!it.open) it.d.open = false; });
    }

    // חיפוש: שאלות שלא מתאימות נאספות, ומילות החיפוש מסומנות בשאלות שנשארו
    var input = null, count = null, empty = null, q = el.getAttribute('data-search');
    if (q !== null) {
      var box = document.createElement('div');
      box.className = 'fx-faq__search';
      input = document.createElement('input');
      input.type = 'search';
      input.placeholder = q && q !== 'true' ? q : 'חיפוש בשאלות';
      input.setAttribute('aria-label', input.placeholder);
      input.autocomplete = 'off';
      count = document.createElement('p');
      count.className = 'fx-faq__count';
      count.setAttribute('aria-live', 'polite');
      box.appendChild(input);
      box.appendChild(count);
      items[0].d.parentNode.insertBefore(box, items[0].d);
      empty = document.createElement('p');
      empty.className = 'fx-faq__empty';
      empty.hidden = true;
      empty.textContent = el.getAttribute('data-empty') || 'לא מצאנו שאלה כזאת. נסו מילה אחרת, או פשוט שאלו אותנו.';
      var last = items[items.length - 1].d;
      last.parentNode.insertBefore(empty, last.nextSibling);
      var t = 0;
      input.addEventListener('input', function () { clearTimeout(t); t = setTimeout(search, 120); });
    }
    function setVisible(it, v) {
      if (it.visible === v) return;
      it.visible = v;
      if (REDUCE || !it.d.animate) { it.d.hidden = !v; return; }
      if (v) { it.d.hidden = false; slide(it.d, it, 'v', true); }
      else slide(it.d, it, 'v', false, function () { if (!it.visible) it.d.hidden = true; });
    }
    function mark(it, raw) {
      if (!raw.length) { it.q.innerHTML = it.html; return; }
      var re = new RegExp('(' + raw.map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }).join('|') + ')', 'gi');
      it.q.innerHTML = it.plain.split(re).map(function (part, i) { return i % 2 ? '<mark class="fx-faq__mark">' + esc(part) + '</mark>' : esc(part); }).join('');
    }
    function search() {
      var value = input.value, words = norm(value).split(' ').filter(Boolean), raw = value.trim().split(/\s+/).filter(function (w) { return w.length > 1; }), shown = 0;
      items.forEach(function (it) {
        var ok = words.every(function (w) { return it.text.indexOf(w) >= 0; });
        if (ok) shown++;
        setVisible(it, ok);
        mark(it, ok ? raw : []);
      });
      empty.hidden = shown > 0;
      count.textContent = !words.length ? '' : shown === 0 ? 'לא נמצאו שאלות' : shown === 1 ? 'נמצאה שאלה אחת' : 'נמצאו ' + shown + ' שאלות';
    }

    // קישור ישיר לשאלה (#id של details) פותח אותה
    var target = location.hash && document.getElementById(decodeURIComponent(location.hash.slice(1)));
    if (target && el.contains(target)) {
      var d = target.closest('details');
      items.forEach(function (it) { if (it.d === d) toggle(it, true, true); });
    }
    el.fxFaq = {
      open: function (i) { if (items[i]) toggle(items[i], true); },
      close: function (i) { if (items[i]) toggle(items[i], false); },
      search: function (text) { if (input) { input.value = text; search(); } }
    };
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-faq'), setup);
  }
  (window.FX = window.FX || {}).faq = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-highlight · סימון מרקר */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var NS = 'http://www.w3.org/2000/svg';
  var io = 'IntersectionObserver' in window ? new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (!en.isIntersecting) return;
      en.target.classList.add('is-in');
      io.unobserve(en.target);
    });
  }, { rootMargin: '0px 0px -12% 0px', threshold: 0.6 }) : null;

  // קו או עיגול שנבנים לפי הגודל האמיתי של המילה, כדי שהעובי יישאר אחיד
  function draw(st) {
    var r = st.svg.getBoundingClientRect(), w = Math.max(2, r.width), h = Math.max(2, r.height), d;
    st.svg.setAttribute('viewBox', '0 0 ' + w.toFixed(1) + ' ' + h.toFixed(1));
    if (st.style === 'underline') {
      var sx = st.rtl ? w - 2 : 2, ex = st.rtl ? 2 : w - 2;
      var L = function (t) { return (sx + (ex - sx) * t).toFixed(1); };
      d = 'M' + sx.toFixed(1) + ' ' + (h * .62).toFixed(1) + ' C' + L(.3) + ' ' + (h * .15).toFixed(1) + ' ' + L(.62) + ' ' + (h * .98).toFixed(1) + ' ' + ex.toFixed(1) + ' ' + (h * .38).toFixed(1);
    } else {
      var cx = w / 2, cy = h / 2, rx = w / 2 - 3, ry = h / 2 - 3, pts = [], turn = st.rtl ? -1 : 1;
      for (var i = 0; i <= 56; i++) {
        var t = i / 56, a = -Math.PI * 0.6 + turn * t * (Math.PI * 2 + 0.55), k = 1 + 0.035 * Math.sin(t * 9) - t * 0.06;
        pts.push((cx + Math.cos(a) * rx * k).toFixed(1) + ' ' + (cy + Math.sin(a) * ry * k + t * 3).toFixed(1));
      }
      d = 'M' + pts.join(' L');
    }
    st.path.setAttribute('d', d);
  }

  function setup(el) {
    if (el.__fxHighlight) return;
    var style = el.getAttribute('data-style') || 'marker', rtl = getComputedStyle(el).direction === 'rtl';
    var st = el.__fxHighlight = { el: el, style: style, rtl: rtl };
    el.style.setProperty('--fx-highlight-from', rtl ? '100%' : '0%');
    if (style === 'underline' || style === 'circle') {
      st.svg = document.createElementNS(NS, 'svg');
      st.path = document.createElementNS(NS, 'path');
      st.svg.setAttribute('class', 'fx-highlight__svg');
      st.svg.setAttribute('aria-hidden', 'true');
      st.svg.setAttribute('focusable', 'false');
      st.path.setAttribute('pathLength', '1');
      st.svg.appendChild(st.path);
      el.appendChild(st.svg);
      draw(st);
      if ('ResizeObserver' in window) new ResizeObserver(function () { draw(st); }).observe(el);
      if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { draw(st); });
    }
    // כמה סימונים באותה פסקה: אחד אחרי השני
    var block = el.parentNode.closest('p, li, h1, h2, h3, h4, h5, h6, blockquote, dd, td') || el.parentNode;
    var order = Array.prototype.indexOf.call(block.querySelectorAll('.fx-highlight'), el);
    el.style.setProperty('--fx-delay', ((parseFloat(el.getAttribute('data-delay')) || 0) + Math.max(0, order) * 380) + 'ms');
    el.fxHighlight = {
      replay: function () {
        if (REDUCE) return;
        el.classList.remove('is-in');
        el.offsetWidth;
        requestAnimationFrame(function () { el.classList.add('is-in'); });
      }
    };
    if (REDUCE) return;                                      // בלי תנועה: הסימון מופיע מוכן
    el.classList.add('is-armed');
    if (io) io.observe(el); else el.classList.add('is-in');
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-highlight'), setup);
  }
  (window.FX = window.FX || {}).highlight = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-filter · סינון חלק */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var EASE = 'cubic-bezier(.2, .8, .2, 1)';

  function setup(el) {
    if (el.__fxFilter) return;
    var btns = Array.prototype.slice.call(el.querySelectorAll('[data-filter]')), first = el.querySelector('[data-tags]');
    if (!first || !btns.length) return;
    el.__fxFilter = true;
    var list = el.querySelector('.fx-filter__list') || first.parentNode;
    list.classList.add('fx-filter__list');
    var items = Array.prototype.filter.call(list.children, function (c) { return c.hasAttribute('data-tags'); });
    function tags(it) { return (it.getAttribute('data-tags') || '').split(/[\s,]+/).filter(Boolean); }
    function fits(it, f) { return !f || f === '*' || f === 'all' || tags(it).indexOf(f) >= 0; }

    if (el.getAttribute('data-count') === 'true') btns.forEach(function (b) {   // כמה פריטים יש בכל קטגוריה
      var s = document.createElement('span'), f = b.getAttribute('data-filter');
      s.className = 'fx-filter__n';
      s.setAttribute('aria-hidden', 'true');
      s.textContent = items.filter(function (it) { return fits(it, f); }).length;
      b.appendChild(s);
    });
    btns.forEach(function (b) { if (b.tagName === 'BUTTON') b.type = 'button'; });
    var status = document.createElement('p');
    status.className = 'fx-filter__status';
    status.setAttribute('role', 'status');
    list.parentNode.insertBefore(status, list.nextSibling);

    var cur = null, leaving = [];
    function park(it) {                                         // פריט שיצא: מסתירים ומנקים את המיקום הזמני
      it.hidden = true;
      it.getAnimations && it.getAnimations().forEach(function (a) { a.cancel(); });
      ['position', 'left', 'top', 'width', 'height', 'margin', 'pointerEvents', 'zIndex'].forEach(function (k) { it.style[k] = ''; });
    }
    function apply(f, instant) {
      if (f === cur) return;
      cur = f;
      btns.forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-filter') === f ? 'true' : 'false'); });
      leaving.forEach(park);
      leaving = [];
      items.forEach(function (it) { if (it.getAnimations) it.getAnimations().forEach(function (a) { a.finish(); }); });
      var lr = list.getBoundingClientRect(), h0 = list.offsetHeight, before = [];
      items.forEach(function (it, i) { before[i] = it.hidden ? null : it.getBoundingClientRect(); });
      var enter = [];
      items.forEach(function (it, i) {
        var keep = fits(it, f);
        if (!it.hidden && !keep) {                               // יוצא: נשאר רגע במקום הישן, מעל האחרים, ונעלם
          var r = before[i];
          it.style.position = 'absolute';
          it.style.margin = '0';
          it.style.left = (r.left - lr.left - list.clientLeft) + 'px';
          it.style.top = (r.top - lr.top - list.clientTop) + 'px';
          it.style.width = r.width + 'px';
          it.style.height = r.height + 'px';
          it.style.pointerEvents = 'none';
          it.style.zIndex = '1';
          leaving.push(it);
        } else if (it.hidden && keep) { it.hidden = false; enter.push(it); }
      });
      var shown = items.filter(function (it) { return !it.hidden && leaving.indexOf(it) < 0; }).length;
      status.textContent = shown === items.length ? 'מוצגים כל ' + shown + ' הפריטים' : 'מוצגים ' + shown + ' מתוך ' + items.length;
      el.dispatchEvent(new CustomEvent('fx:filter', { bubbles: true, detail: { filter: f, shown: shown } }));
      if (instant || REDUCE || !list.animate) { leaving.forEach(park); leaving = []; return; }
      var h1 = list.offsetHeight;
      leaving.forEach(function (it) {
        it.animate([{ opacity: 1, transform: 'scale(1)' }, { opacity: 0, transform: 'scale(.9)' }], { duration: 220, easing: 'ease-in', fill: 'forwards' })
          .onfinish = function () { if (leaving.indexOf(it) >= 0) { leaving.splice(leaving.indexOf(it), 1); park(it); } };
      });
      items.forEach(function (it, i) {                          // מי שנשאר: מחליק מהמקום הישן לחדש
        if (it.hidden || leaving.indexOf(it) >= 0) return;
        if (enter.indexOf(it) >= 0) {
          it.animate([{ opacity: 0, transform: 'scale(.92)' }, { opacity: 1, transform: 'none' }], { duration: 380, delay: 150, easing: EASE, fill: 'backwards' });
          return;
        }
        var r0 = before[i], r1 = it.getBoundingClientRect(), dx = r0.left - r1.left, dy = r0.top - r1.top;
        if (Math.abs(dx) > .5 || Math.abs(dy) > .5) it.animate([{ transform: 'translate(' + dx + 'px,' + dy + 'px)' }, { transform: 'none' }], { duration: 480, easing: EASE });
      });
      if (h0 !== h1) list.animate([{ height: h0 + 'px' }, { height: h1 + 'px' }], { duration: 480, easing: EASE });
    }

    btns.forEach(function (b) { b.addEventListener('click', function () { apply(b.getAttribute('data-filter')); }); });
    var start = btns.filter(function (b) { return b.getAttribute('aria-pressed') === 'true' || b.classList.contains('is-active'); })[0] || btns[0];
    apply(start.getAttribute('data-filter'), true);
    el.fxFilter = { set: function (f) { apply(f); } };
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-filter'), setup);
  }
  (window.FX = window.FX || {}).filter = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-compare · לפני ואחרי */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var KNOB = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6 3 12l6 6M15 6l6 6-6 6"/></svg>';

  function setup(el) {
    if (el.__fxCompare) return;
    var imgs = el.querySelectorAll(':scope > img');
    if (imgs.length < 2) return;
    var rtl = getComputedStyle(el).direction === 'rtl';
    function attr(name, d) { var v = el.getAttribute(name); return v === null ? d : v; }
    var after = document.createElement('div'), line = document.createElement('div'), range = document.createElement('input');
    after.className = 'fx-compare__after';
    after.appendChild(imgs[1]);
    el.appendChild(after);
    line.className = 'fx-compare__line';
    line.innerHTML = '<span class="fx-compare__knob">' + KNOB + '</span>';
    el.appendChild(line);
    var labels = [['before', attr('data-before', 'לפני')], ['after', attr('data-after', 'אחרי')]].map(function (l) {
      if (!l[1]) return null;
      var s = document.createElement('span');
      s.className = 'fx-compare__label fx-compare__label--' + l[0];
      s.textContent = l[1];
      s.setAttribute('aria-hidden', 'true');
      el.appendChild(s);
      return s;
    });
    var start = Math.min(100, Math.max(0, parseFloat(attr('data-start', '50')) || 50));
    range.type = 'range';
    range.className = 'fx-compare__range';
    range.min = 0;
    range.max = 100;
    range.step = 1;
    range.value = start;
    range.setAttribute('aria-label', attr('data-label', 'השוואה בין לפני לאחרי. החצים מזיזים את הקו'));
    el.appendChild(range);

    var st = el.__fxCompare = { p: start, target: start, raf: 0, drag: null, touched: false };
    function render() {
      var w = el.clientWidth, x = (rtl ? 1 - st.p / 100 : st.p / 100) * w;
      line.style.transform = 'translateX(' + x.toFixed(1) + 'px)';
      after.style.clipPath = rtl ? 'inset(0 ' + st.p.toFixed(2) + '% 0 0)' : 'inset(0 0 0 ' + st.p.toFixed(2) + '%)';
      if (labels[0]) labels[0].style.opacity = st.p < 16 ? 0 : 1;   // תווית שהקו מתקרב אליה נעלמת
      if (labels[1]) labels[1].style.opacity = st.p > 84 ? 0 : 1;
      if (Math.round(st.p) !== +range.value) range.value = Math.round(st.p);
      range.setAttribute('aria-valuetext', Math.round(st.p) + '%');
    }
    function tick() {
      st.raf = 0;
      var d = st.target - st.p;
      if (Math.abs(d) < 0.05) st.p = st.target;
      else { st.p += d * (st.drag ? 0.45 : 0.18); st.raf = requestAnimationFrame(tick); }
      render();
    }
    function go(p, instant) {
      st.target = Math.min(100, Math.max(0, p));
      if (instant || REDUCE) { st.p = st.target; render(); }
      else if (!st.raf) st.raf = requestAnimationFrame(tick);
    }
    function at(e) { var r = el.getBoundingClientRect(), t = (e.clientX - r.left) / r.width; return (rtl ? 1 - t : t) * 100; }

    el.addEventListener('pointerdown', function (e) {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      st.touched = true;
      st.drag = { id: e.pointerId };
      el.classList.add('is-dragging');
      try { el.setPointerCapture(e.pointerId); } catch (err) {}
      go(at(e));
    });
    el.addEventListener('pointermove', function (e) { if (st.drag && e.pointerId === st.drag.id) go(at(e)); });
    function end(e) { if (st.drag && e.pointerId === st.drag.id) { st.drag = null; el.classList.remove('is-dragging'); } }
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
    range.addEventListener('input', function () { st.touched = true; go(+range.value, true); });
    range.addEventListener('focus', function () { if (range.matches(':focus-visible')) el.classList.add('is-focus'); });
    range.addEventListener('blur', function () { el.classList.remove('is-focus'); });

    // רמז קטן כשהתמונה נכנסת למסך בפעם הראשונה: הקו זז קצת לשני הצדדים
    if (!REDUCE && attr('data-hint', 'true') !== 'false' && 'IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (entries) {
        if (!entries[entries.length - 1].isIntersecting) return;
        io.disconnect();
        [[0, 13], [520, -11], [1040, 0]].forEach(function (s) { setTimeout(function () { if (!st.touched) go(start + s[1]); }, 300 + s[0]); });
      }, { threshold: 0.6 });
      io.observe(el);
    }
    if ('ResizeObserver' in window) new ResizeObserver(render).observe(el);
    render();
    el.fxCompare = { set: function (p) { go(p); } };
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-compare'), setup);
  }
  (window.FX = window.FX || {}).compare = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-lightbox · גלריה עם הגדלה */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var EASE = 'cubic-bezier(.2, .8, .2, 1)';
  function icon(d) { return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '"/></svg>'; }
  var CLOSE = icon('M6 6l12 12M18 6 6 18'), LEFT = icon('M15 5l-7 7 7 7'), RIGHT = icon('M9 5l7 7-7 7');

  function setup(el) {
    if (el.__fxLightbox) return;
    var links = Array.prototype.filter.call(el.querySelectorAll('a'), function (a) { return a.querySelector('img'); });
    if (!links.length) return;
    el.__fxLightbox = true;
    var rtl = getComputedStyle(el).direction === 'rtl', n = links.length;
    var ov, bg, img, ui, cap, count, bClose, bPrev, bNext, cur = -1, drag = null, saved = null;

    function thumb(i) { return links[i].querySelector('img'); }
    function full(i) { var h = links[i].getAttribute('href'); return h && h !== '#' ? links[i].href : thumb(i).currentSrc || thumb(i).src; }
    function caption(i) {
      var a = links[i], f = a.closest('figure'), c = f && f.querySelector('figcaption');
      return (a.getAttribute('data-caption') || (c && c.textContent) || thumb(i).alt || '').trim();
    }
    // המקום של התמונה הגדולה: כמה שיותר גדול, עם מרווח לכפתורים
    function fit(i) {
      var t = thumb(i), nw = t.naturalWidth || 4, nh = t.naturalHeight || 5, W = innerWidth, H = innerHeight;
      var px = W > 700 ? 88 : 12, top = W > 700 ? 64 : 70, bottom = W > 700 ? 64 : 120, s = Math.min((W - px * 2) / nw, (H - top - bottom) / nh);
      var w = nw * s, h = nh * s;
      return { left: (W - w) / 2, top: top + (H - top - bottom - h) / 2, width: w, height: h };
    }
    function place(r) {
      img.style.left = r.left + 'px';
      img.style.top = r.top + 'px';
      img.style.width = r.width + 'px';
      img.style.height = r.height + 'px';
    }
    // מעוף בין התמונה הקטנה לגדולה: אותה תמונה מוגדלת, עם חיתוך שנפתח כמו בתמונה הקטנה
    function fly(tr, r, back) {
      var s = Math.max(tr.width / r.width, tr.height / r.height);
      var cw = (r.width * s - tr.width) / 2 / s, ch = (r.height * s - tr.height) / 2 / s;
      var dx = tr.left + tr.width / 2 - r.left - r.width * s / 2, dy = tr.top + tr.height / 2 - r.top - r.height * s / 2;
      var rad = parseFloat(getComputedStyle(links[cur]).borderTopLeftRadius) || 0;
      var small = { transform: 'translate(' + dx + 'px,' + dy + 'px) scale(' + s + ')', clipPath: 'inset(' + ch + 'px ' + cw + 'px round ' + (rad / s) + 'px)' };
      var big = { transform: 'translate(0px,0px) scale(1)', clipPath: 'inset(0px 0px round 6px)' };
      return img.animate(back ? [big, small] : [small, big], { duration: back ? 340 : 440, easing: EASE, fill: 'both' });
    }
    function source(i) { links.forEach(function (a, k) { a.classList.toggle('is-source', k === i); }); }
    function texts() {
      cap.textContent = caption(cur);
      count.textContent = (cur + 1) + ' / ' + n;
      img.alt = thumb(cur).alt || '';
      [cur - 1, cur + 1].forEach(function (k) { var p = new Image(); p.src = full((k + n) % n); });   // טוענים מראש את השכנות
    }
    function setSrc(i) {
      var t = thumb(i), big = full(i);
      img.src = t.currentSrc || t.src;
      if (big !== img.src) { var p = new Image(); p.onload = function () { if (cur === i) img.src = big; }; p.src = big; }
    }

    function build() {
      ov = document.createElement('div');
      ov.className = 'fx-lightbox__overlay';
      ov.dir = rtl ? 'rtl' : 'ltr';
      ov.setAttribute('role', 'dialog');
      ov.setAttribute('aria-modal', 'true');
      ov.setAttribute('aria-label', el.getAttribute('data-label') || 'תמונות בגדול');
      var tint = getComputedStyle(el).getPropertyValue('--fx-lightbox-bg').trim();   // התצוגה יושבת מחוץ לגלריה, אז מעבירים אליה את הצבע
      if (tint) ov.style.setProperty('--fx-lightbox-bg', tint);
      ov.innerHTML = '<div class="fx-lightbox__bg"></div><img class="fx-lightbox__img" alt="" draggable="false"><div class="fx-lightbox__ui">' +
        '<button type="button" class="fx-lightbox__btn fx-lightbox__close" aria-label="סגירה">' + CLOSE + '</button>' +
        '<button type="button" class="fx-lightbox__btn fx-lightbox__prev" aria-label="התמונה הקודמת">' + (rtl ? RIGHT : LEFT) + '</button>' +
        '<button type="button" class="fx-lightbox__btn fx-lightbox__next" aria-label="התמונה הבאה">' + (rtl ? LEFT : RIGHT) + '</button>' +
        '<p class="fx-lightbox__bar"><span class="fx-lightbox__cap"></span><span class="fx-lightbox__count"></span></p></div>';
      bg = ov.querySelector('.fx-lightbox__bg');
      img = ov.querySelector('.fx-lightbox__img');
      ui = ov.querySelector('.fx-lightbox__ui');
      cap = ov.querySelector('.fx-lightbox__cap');
      count = ov.querySelector('.fx-lightbox__count');
      bClose = ov.querySelector('.fx-lightbox__close');
      bPrev = ov.querySelector('.fx-lightbox__prev');
      bNext = ov.querySelector('.fx-lightbox__next');
      if (n < 2) { bPrev.hidden = true; bNext.hidden = true; }
      bClose.addEventListener('click', close);
      bPrev.addEventListener('click', function () { go(-1); });
      bNext.addEventListener('click', function () { go(1); });
      // גרירה: הצידה מחליפה תמונה, למטה סוגרת. לחיצה על הרקע סוגרת
      ov.addEventListener('pointerdown', function (e) {
        if (e.target.closest('button')) return;
        drag = { id: e.pointerId, x: e.clientX, y: e.clientY, dx: 0, dy: 0, axis: null, t: performance.now() };
        try { ov.setPointerCapture(e.pointerId); } catch (err) {}
      });
      ov.addEventListener('pointermove', function (e) {
        if (!drag || e.pointerId !== drag.id) return;
        drag.dx = e.clientX - drag.x;
        drag.dy = e.clientY - drag.y;
        if (!drag.axis && Math.abs(drag.dx) + Math.abs(drag.dy) > 8) drag.axis = Math.abs(drag.dx) > Math.abs(drag.dy) ? 'x' : 'y';
        if (drag.axis === 'x' && n > 1) img.style.transform = 'translateX(' + drag.dx + 'px)';
        if (drag.axis === 'y') {
          var k = Math.max(0, drag.dy);
          img.style.transform = 'translateY(' + k + 'px) scale(' + (1 - Math.min(k, 400) / 1600) + ')';
          bg.style.opacity = 1 - Math.min(k, 300) / 420;
        }
      });
      function up(e) {
        if (!drag || e.pointerId !== drag.id) return;
        var d = drag, fast = performance.now() - d.t < 260;
        drag = null;
        if (!d.axis) { if (e.type === 'pointerup' && e.target === bg) close(); return; }
        if (d.axis === 'x' && n > 1 && (Math.abs(d.dx) > 80 || (fast && Math.abs(d.dx) > 30))) { go((d.dx > 0) === rtl ? 1 : -1, d.dx); return; }
        if (d.axis === 'y' && (d.dy > 120 || (fast && d.dy > 50))) { close(); return; }
        var from = img.style.transform;
        img.style.transform = '';
        bg.style.opacity = '';
        if (!REDUCE) img.animate([{ transform: from }, { transform: 'none' }], { duration: 300, easing: EASE });
      }
      ov.addEventListener('pointerup', up);
      ov.addEventListener('pointercancel', up);
    }

    function lock(on) {
      var de = document.documentElement;
      if (on) {
        saved = [de.style.overflow, de.style.scrollbarGutter];
        if (innerWidth > de.clientWidth) de.style.scrollbarGutter = 'stable';
        de.style.overflow = 'hidden';
      } else if (saved) { de.style.overflow = saved[0]; de.style.scrollbarGutter = saved[1]; saved = null; }
    }
    function onKey(e) {
      if (e.key === 'Escape') close();
      else if (e.key === 'ArrowLeft') go(rtl ? 1 : -1);
      else if (e.key === 'ArrowRight') go(rtl ? -1 : 1);
      else if (e.key === 'Tab') {                               // הפוקוס נשאר בתוך התצוגה
        var f = [bClose, bPrev, bNext].filter(function (b) { return !b.hidden; }), i = f.indexOf(document.activeElement);
        f[(i + (e.shiftKey ? -1 : 1) + f.length) % f.length].focus();
      } else return;
      e.preventDefault();
    }
    function onResize() { if (cur >= 0) place(fit(cur)); }

    function open(i) {
      if (!ov) build();
      if (ov.parentNode) return;
      cur = i;
      lock(true);
      document.body.appendChild(ov);
      setSrc(i);
      texts();
      var r = fit(i);
      place(r);
      img.style.transform = '';
      bg.style.opacity = '';
      bClose.focus({ preventScroll: true });
      document.addEventListener('keydown', onKey);
      window.addEventListener('resize', onResize);
      if (REDUCE || !img.animate) return;
      source(i);
      var a = fly(thumb(i).getBoundingClientRect(), r);
      a.onfinish = function () { a.cancel(); source(-1); };
      bg.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 320, easing: 'ease-out' });
      ui.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 260, delay: 180, fill: 'backwards' });
    }
    function go(step, dragged) {
      if (n < 2) return;
      var i = (cur + step + n) % n, r = fit(i), shift = 140 * (step > 0 ? 1 : -1) * (rtl ? -1 : 1);
      if (!REDUCE && img.animate) {                             // התמונה הישנה יוצאת לצד אחד, החדשה נכנסת מהשני
        var ghost = img.cloneNode();
        ghost.style.transform = img.style.transform;
        ov.insertBefore(ghost, ui);
        ghost.animate([{ transform: ghost.style.transform || 'none', opacity: 1 }, { transform: 'translateX(' + (-shift) + 'px)', opacity: 0 }], { duration: 260, easing: 'ease-in', fill: 'forwards' })
          .onfinish = function () { ghost.remove(); };
      }
      cur = i;
      img.style.transform = '';
      setSrc(i);
      texts();
      place(r);
      if (!REDUCE && img.animate) img.animate([{ transform: 'translateX(' + shift + 'px)', opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: 380, delay: 60, easing: EASE, fill: 'backwards' });
    }
    function close() {
      if (!ov || !ov.parentNode) return;
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('resize', onResize);
      var a = links[cur], tr = thumb(cur).getBoundingClientRect(), r = fit(cur);
      function done() {
        ov.remove();
        img.getAnimations().forEach(function (x) { x.cancel(); });
        img.style.transform = '';
        lock(false);
        source(-1);
        a.focus({ preventScroll: true });
      }
      if (REDUCE || !img.animate) { done(); return; }
      bg.animate([{ opacity: getComputedStyle(bg).opacity }, { opacity: 0 }], { duration: 300, fill: 'forwards' });
      ui.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 160, fill: 'forwards' });
      var seen = tr.width > 0 && tr.bottom > 0 && tr.top < innerHeight;
      if (seen && !img.style.transform) { source(cur); fly(tr, r, true).onfinish = done; }
      else img.animate([{ opacity: 1 }, { opacity: 0, transform: (img.style.transform || '') + ' scale(.92)' }], { duration: 240, fill: 'forwards' }).onfinish = done;
    }

    links.forEach(function (a, i) {
      a.addEventListener('click', function (e) {
        if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
        e.preventDefault();
        open(i);
      });
    });
    el.fxLightbox = { open: open, close: close };
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-lightbox'), setup);
  }
  (window.FX = window.FX || {}).lightbox = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-form · טופס פנייה */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var MSG = {
    required: 'צריך למלא את השדה הזה',
    choose: 'צריך לבחור אחת מהאפשרויות',
    check: 'צריך לסמן כדי להמשיך',
    email: 'כתובת המייל לא נראית תקינה',
    phone: 'מספר הטלפון לא נראה תקין',
    short: 'צריך לפחות {n} תווים'
  };
  var TICK = '<svg class="fx-form__tick" viewBox="0 0 24 24" aria-hidden="true"><path pathLength="1" d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
  var uid = 0;

  // טלפון ישראלי: נייד, נייח, 07X ומספרי 1-800. מקבלים גם +972 ורווחים
  function digits(v) { return v.replace(/[^\d+]/g, '').replace(/^\+?972/, '0'); }
  function phoneOk(v) { return /^(?:0[57]\d{8}|0[23489]\d{7}|1(?:[78]00|599)\d{6})$/.test(digits(v)); }
  function phoneNice(v) {
    var d = digits(v);
    if (/^0[57]\d{8}$/.test(d)) return d.slice(0, 3) + '-' + d.slice(3, 6) + '-' + d.slice(6);
    if (/^0[23489]\d{7}$/.test(d)) return d.slice(0, 2) + '-' + d.slice(2, 5) + '-' + d.slice(5);
    return v;
  }

  function setup(form) {
    if (form.__fxForm) return;
    form.__fxForm = true;
    form.noValidate = true;
    var rtl = getComputedStyle(form).direction === 'rtl', fields = [], busy = false;
    form.style.setProperty('--fx-form-origin', rtl ? 'right' : 'left');

    function isPhone(inp) { return inp.type === 'tel' || inp.getAttribute('data-type') === 'phone'; }
    function labelOf(f) {
      var l = f.inp.id && form.querySelector('label[for="' + f.inp.id + '"]');
      return ((l && l.textContent) || f.inp.getAttribute('aria-label') || f.inp.name || '').replace(/\s*\*\s*$/, '').trim();
    }
    function rule(f) {
      var inp = f.inp, v = inp.value.trim(), own = inp.getAttribute('data-error');
      if (inp.type === 'checkbox') return inp.required && !inp.checked ? own || MSG.check : '';
      if (!v) return inp.required ? own || (inp.tagName === 'SELECT' ? MSG.choose : MSG.required) : '';
      if (inp.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) return own || MSG.email;
      if (isPhone(inp) && !phoneOk(v)) return own || MSG.phone;
      var min = +inp.getAttribute('minlength');
      if (min && v.length < min) return own || MSG.short.replace('{n}', min);
      return '';
    }
    function show(f, msg) {
      f.err = msg || '';
      f.wrap.classList.toggle('is-invalid', !!msg);
      f.inp.setAttribute('aria-invalid', msg ? 'true' : 'false');
      if (!f.box) {
        f.box = document.createElement('span');
        f.box.className = 'fx-form__error';
        f.box.id = 'fx-form-error-' + (++uid);
        if (f.wrap.tagName === 'LABEL') f.wrap.parentNode.insertBefore(f.box, f.wrap.nextSibling); else f.wrap.appendChild(f.box);
        var d = f.inp.getAttribute('aria-describedby');
        f.inp.setAttribute('aria-describedby', (d ? d + ' ' : '') + f.box.id);
      }
      f.box.textContent = msg || '';
    }
    function check(f) { var m = rule(f); show(f, m); return !m; }

    Array.prototype.forEach.call(form.querySelectorAll('input, textarea, select'), function (inp) {
      if (/^(hidden|submit|button|reset|image)$/.test(inp.type)) return;
      var wrap = inp.closest('.fx-form__field') || (inp.type === 'checkbox' || inp.type === 'radio' ? inp.closest('label') : null) || inp.parentNode;
      var f = { inp: inp, wrap: wrap, err: '' };
      fields.push(f);
      if (inp.type === 'checkbox' || inp.type === 'radio') { inp.addEventListener('change', function () { if (f.err) check(f); }); return; }
      function up() { wrap.classList.toggle('is-up', document.activeElement === inp || !!inp.value); }
      var count = null, max = +inp.getAttribute('maxlength');
      if (max && inp.tagName === 'TEXTAREA') {                   // מונה תווים להודעה
        count = document.createElement('span');
        count.className = 'fx-form__count';
        count.setAttribute('aria-hidden', 'true');
        wrap.appendChild(count);
      }
      function counted() { if (count) count.textContent = inp.value.length + '/' + max; }
      inp.addEventListener('focus', function () { wrap.classList.add('is-focus'); up(); });
      inp.addEventListener('blur', function () {
        wrap.classList.remove('is-focus');
        if (isPhone(inp) && phoneOk(inp.value)) inp.value = phoneNice(inp.value);
        up();
        if (inp.value || f.err) check(f);                        // לא צועקים על שדה ריק שרק עברו בו
      });
      inp.addEventListener('input', function () { up(); counted(); if (f.err) check(f); });
      inp.addEventListener('change', up);
      up();
      counted();
      setTimeout(up, 400);                                       // מילוי אוטומטי של הדפדפן
    });

    // מלכודת לרובוטים: שדה שאנשים לא רואים. מי שממלא אותו הוא כנראה רובוט
    var trap = document.createElement('div');
    trap.className = 'fx-form__trap';
    trap.setAttribute('aria-hidden', 'true');
    trap.innerHTML = '<label>אל תמלאו את השדה הזה <input name="_gotcha" tabindex="-1" autocomplete="off"></label>';
    form.appendChild(trap);
    var bot = trap.querySelector('input');

    var btn = form.querySelector('[type="submit"]') || form.querySelector('button:not([type])'), live = document.createElement('p'), fail = document.createElement('p');
    if (btn && btn.tagName === 'BUTTON') {
      var text = document.createElement('span');
      text.className = 'fx-form__text';
      while (btn.firstChild) text.appendChild(btn.firstChild);
      btn.appendChild(text);
      btn.insertAdjacentHTML('beforeend', '<span class="fx-form__spin" aria-hidden="true"></span>' + TICK);
      btn.classList.add('fx-form__btn');
    }
    live.className = 'fx-form__live';
    live.setAttribute('role', 'status');
    live.style.cssText = 'position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap';
    form.appendChild(live);
    fail.className = 'fx-form__fail';
    fail.setAttribute('role', 'alert');
    if (btn) btn.parentNode.insertBefore(fail, btn.nextSibling); else form.appendChild(fail);
    function say(t) { live.textContent = ''; setTimeout(function () { live.textContent = t; }, 50); }
    function state(name) {
      if (!btn) return;
      btn.classList.toggle('is-sending', name === 'sending');
      btn.classList.toggle('is-done', name === 'done');
      btn.disabled = name === 'sending' || name === 'done';
      btn.setAttribute('aria-busy', name === 'sending' ? 'true' : 'false');
    }

    function done(message) {
      busy = false;
      state('done');
      var msg = message || form.getAttribute('data-done') || 'תודה! קיבלנו את הפנייה, ונחזור אליכם בהקדם.';
      say(msg);
      setTimeout(function () {
        var h0 = form.offsetHeight, panel = form.querySelector('.fx-form__done');
        if (!panel) {
          panel = document.createElement('div');
          panel.className = 'fx-form__done';
          panel.innerHTML = '<svg viewBox="0 0 48 48" aria-hidden="true"><path pathLength="1" d="M24 4a20 20 0 1 1 0 40a20 20 0 0 1 0-40M15 24.5l6 6 12-12"/></svg><p></p><button type="button" class="fx-form__again">שליחת פנייה נוספת</button>';
          form.appendChild(panel);
          panel.querySelector('.fx-form__again').addEventListener('click', reset);
        }
        if (panel.querySelector('p')) panel.querySelector('p').textContent = msg;
        panel.hidden = false;
        panel.tabIndex = -1;
        form.classList.add('is-done');
        panel.focus({ preventScroll: true });
        var h1 = form.offsetHeight;
        if (!REDUCE && form.animate) form.animate([{ height: h0 + 'px' }, { height: h1 + 'px' }], { duration: 420, easing: 'cubic-bezier(.2, .8, .2, 1)' });
      }, REDUCE ? 0 : 900);
    }
    function failed(message) {
      busy = false;
      state('');
      fail.textContent = message || form.getAttribute('data-fail') || 'השליחה לא הצליחה. נסו שוב בעוד רגע, או התקשרו אלינו.';
    }
    function reset() {
      form.reset();
      form.classList.remove('is-done');
      var panel = form.querySelector('.fx-form__done');
      if (panel) panel.hidden = true;
      state('');
      fail.textContent = '';
      fields.forEach(function (f) { show(f, ''); f.wrap.classList.remove('is-up', 'is-shake'); f.inp.dispatchEvent(new Event('input')); });
      if (fields[0]) fields[0].inp.focus();
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (busy) return;
      fail.textContent = '';
      var bad = fields.filter(function (f) { return !check(f); });
      if (bad.length) {                                            // כל שדה שגוי רועד, והפוקוס עובר לראשון שבהם
        bad.forEach(function (f) {
          if (REDUCE) return;
          var n = f.wrap.tagName === 'LABEL' ? f.wrap : f.inp;
          n.classList.remove('is-shake');
          n.offsetWidth;
          n.classList.add('is-shake');
        });
        bad[0].inp.focus();
        say(bad.length === 1 ? 'יש שדה אחד לתקן' : 'יש ' + bad.length + ' שדות לתקן');
        return;
      }
      busy = true;
      state('sending');
      if (bot.value) { setTimeout(done, 600); return; }
      var data = {}, lines = [];
      fields.forEach(function (f) {
        var inp = f.inp;
        if (!inp.name || inp.name === '_gotcha' || ((inp.type === 'checkbox' || inp.type === 'radio') && !inp.checked)) return;
        var v = inp.tagName === 'SELECT' && inp.selectedIndex >= 0 ? inp.options[inp.selectedIndex].text : inp.value.trim();
        data[inp.name] = inp.value;
        if (v && inp.type !== 'checkbox') lines.push(labelOf(f) + ': ' + v);
      });
      var ev = new CustomEvent('fx:submit', { bubbles: true, cancelable: true, detail: { data: data, form: form } });
      if (!form.dispatchEvent(ev)) return;                         // האתר מטפל בשליחה לבד, וקורא ל-done או ל-fail
      var wa = form.getAttribute('data-whatsapp');
      if (wa) {                                                    // וואטסאפ: נפתחת הודעה מוכנה, ונשאר רק ללחוץ על שליחה
        var head = form.getAttribute('data-whatsapp-title') || 'פנייה חדשה מהאתר';
        window.open('https://wa.me/' + wa.replace(/\D/g, '') + '?text=' + encodeURIComponent(head + '\n' + lines.join('\n')), '_blank', 'noopener');
        done(form.getAttribute('data-done') || 'פתחנו את וואטסאפ עם ההודעה. נשאר רק ללחוץ על שליחה.');
        return;
      }
      var action = form.getAttribute('action');
      if (action && window.fetch) {
        fetch(action, { method: (form.getAttribute('method') || 'POST').toUpperCase(), body: new FormData(form), headers: { Accept: 'application/json' } })
          .then(function (r) { if (r.ok) done(); else failed(); }, function () { failed(); });
        return;
      }
      setTimeout(done, 900);                                       // בלי כתובת שליחה: רק הדגמה
    });

    form.fxForm = { done: done, fail: failed, reset: reset };
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('form.fx-form'), setup);
  }
  (window.FX = window.FX || {}).form = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-booking · זימון תור */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var LETTERS = 'אבגדהוש';
  var WD = ['ראשון', 'שני', 'שלישי', 'רביעי', 'חמישי', 'שישי', 'שבת'];
  var WS = ['א׳', 'ב׳', 'ג׳', 'ד׳', 'ה׳', 'ו׳', 'ש׳'];
  var MONTHS = ['ינואר', 'פברואר', 'מרץ', 'אפריל', 'מאי', 'יוני', 'יולי', 'אוגוסט', 'ספטמבר', 'אוקטובר', 'נובמבר', 'דצמבר'];
  var MS = ['ינו׳', 'פבר׳', 'מרץ', 'אפר׳', 'מאי', 'יוני', 'יולי', 'אוג׳', 'ספט׳', 'אוק׳', 'נוב׳', 'דצמ׳'];
  var uid = 0;

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function hhmm(m) { return pad(Math.floor(m / 60) % 24) + ':' + pad(m % 60); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function icon(d) { return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '"/></svg>'; }

  // שעות פעילות בעברית: "א-ה 09:00-20:00; ו 08:00-14:00; ש סגור"
  function ranges(text) {
    if (/סגור/.test(text)) return [];
    var out = [], re = /(\d{1,2})[:.](\d{2})\s*[-–—]\s*(\d{1,2})[:.](\d{2})/g, m;
    while ((m = re.exec(text))) {
      var a = +m[1] * 60 + +m[2], b = +m[3] * 60 + +m[4];
      if (b <= a) b += 1440;
      out.push([a, Math.min(b, 1440)]);
    }
    return out;
  }
  function parseWeek(s) {
    var week = [[], [], [], [], [], [], []];
    (s || '').split(/[;\n]+/).forEach(function (part) {
      var m = /^\s*(.+?)\s+((?:\d|סגור).*)$/.exec(part);
      if (!m) return;
      var rs = ranges(m[2]);
      m[1].replace(/[׳'"\s]/g, '').split(',').forEach(function (tok) {
        var r = tok.split(/[-–]/), a = LETTERS.indexOf(r[0]), b = LETTERS.indexOf(r[r.length - 1]);
        if (a < 0 || b < 0) return;
        for (var i = a; ; i = (i + 1) % 7) { week[i] = rs; if (i === b) break; }
      });
    });
    return week;
  }
  function parseExcept(s) {
    var map = {};
    (s || '').split(/[;\n]+/).forEach(function (part) {
      var m = /^\s*(\d{4}-\d{2}-\d{2})\s+(.+)$/.exec(part);
      if (m) map[m[1]] = ranges(m[2]);
    });
    return map;
  }
  // התאריך והשעה עכשיו, לפי אזור הזמן של העסק ולא של הגולש
  function now(tz) {
    var p = {};
    try {
      new Intl.DateTimeFormat('en-US', { timeZone: tz, year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', hourCycle: 'h23' })
        .formatToParts(new Date()).forEach(function (x) { p[x.type] = x.value; });
    } catch (err) {
      var d = new Date();
      p = { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate(), hour: d.getHours(), minute: d.getMinutes() };
    }
    return { y: +p.year, m: +p.month, d: +p.day, min: (+p.hour % 24) * 60 + +p.minute };
  }
  function dayAt(base, k) {
    var t = new Date(Date.UTC(base.y, base.m - 1, base.d + k));
    return { key: t.getUTCFullYear() + '-' + pad(t.getUTCMonth() + 1) + '-' + pad(t.getUTCDate()), y: t.getUTCFullYear(), m: t.getUTCMonth() + 1, d: t.getUTCDate(), wd: t.getUTCDay(), k: k };
  }

  function setup(el) {
    if (el.__fxBooking) return;
    el.__fxBooking = true;
    function attr(n, d) { var v = el.getAttribute(n); return v === null ? d : v; }
    var tz = attr('data-tz', 'Asia/Jerusalem'), week = parseWeek(attr('data-hours', 'א-ה 09:00-18:00')), except = parseExcept(attr('data-except', ''));
    var step = +attr('data-step', 30) || 30, count = +attr('data-days', 14) || 14, lead = +attr('data-lead', 30) || 0;
    var rtl = getComputedStyle(el).direction === 'rtl', wa = attr('data-whatsapp', ''), form = el.closest('form'), id = 'fx-booking-' + (++uid);
    var busy = {};
    function setBusy(list) {
      busy = {};
      (list || []).forEach(function (s) {
        var m = /(\d{4}-\d{2}-\d{2})\D+(\d{1,2})[:.](\d{2})/.exec(s);
        if (m) (busy[m[1]] = busy[m[1]] || []).push(+m[2] * 60 + +m[3]);
      });
    }
    setBusy(attr('data-busy', '').split(','));
    var services = [], svcList = el.querySelector('.fx-booking__services');
    if (svcList) {
      Array.prototype.forEach.call(svcList.querySelectorAll('li'), function (li) {
        services.push({ name: li.textContent.trim(), min: +li.getAttribute('data-min') || step, price: li.getAttribute('data-price') || '' });
      });
      svcList.parentNode.removeChild(svcList);
    }
    var st = { svc: services.length ? 0 : -1, day: -1, time: null, sent: false };

    var html = '';
    if (services.length) {
      html += '<div class="fx-booking__row"><p class="fx-booking__label" id="' + id + '-s">מה עושים?</p><div class="fx-booking__services" role="group" aria-labelledby="' + id + '-s">' +
        services.map(function (s, i) { return '<button type="button" class="fx-booking__svc" data-i="' + i + '"><b>' + esc(s.name) + '</b><span>' + s.min + ' דק׳' + (s.price ? ' · ' + esc(s.price) : '') + '</span></button>'; }).join('') + '</div></div>';
    }
    html += '<div class="fx-booking__row"><div class="fx-booking__top"><p class="fx-booking__label" id="' + id + '-d">באיזה יום?</p><p class="fx-booking__month" aria-hidden="true"></p><div class="fx-booking__arrows">' +
      '<button type="button" class="fx-booking__arrow" data-dir="-1" aria-label="ימים קודמים">' + icon(rtl ? 'M9 5l7 7-7 7' : 'M15 5l-7 7 7 7') + '</button>' +
      '<button type="button" class="fx-booking__arrow" data-dir="1" aria-label="ימים הבאים">' + icon(rtl ? 'M15 5l-7 7 7 7' : 'M9 5l7 7-7 7') + '</button></div></div>' +
      '<div class="fx-booking__days" role="group" aria-labelledby="' + id + '-d"></div></div>';
    html += '<div class="fx-booking__row"><p class="fx-booking__label" id="' + id + '-t">באיזו שעה?</p><div class="fx-booking__slots" role="group" aria-labelledby="' + id + '-t"></div></div>';
    html += '<div class="fx-booking__bar"><p class="fx-booking__sum" aria-live="polite"></p>' +
      (form ? '' : '<button type="button" class="fx-booking__go" disabled>' + esc(attr('data-button', wa ? 'שליחת בקשה בוואטסאפ' : 'שליחת בקשה לתור')) + '</button>') + '</div>';
    el.insertAdjacentHTML('beforeend', html);
    el.classList.add('is-ready');
    var daysEl = el.querySelector('.fx-booking__days'), slotsEl = el.querySelector('.fx-booking__slots'), sumEl = el.querySelector('.fx-booking__sum');
    var monthEl = el.querySelector('.fx-booking__month'), goBtn = el.querySelector('.fx-booking__go'), list = [], hidden = {};
    if (form) ['date', 'time', 'service'].forEach(function (k) {         // בתוך טופס: הבחירה נשמרת בשדות נסתרים
      var name = attr('data-name', 'booking') + '_' + k, inp = form.querySelector('input[name="' + name + '"]');
      if (!inp) { inp = document.createElement('input'); inp.type = 'hidden'; inp.name = name; el.appendChild(inp); }
      hidden[k] = inp;
    });

    function hoursOf(d) { return except[d.key] || week[d.wd]; }
    function slotsOf(d) {
      var len = st.svc >= 0 ? services[st.svc].min : step, out = [], b = busy[d.key] || [], early = d.k === 0 ? now(tz).min + lead : -1;
      hoursOf(d).forEach(function (r) {
        for (var t = r[0]; t + len <= r[1]; t += step) {
          var taken = b.some(function (x) { return x < t + len && x + step > t; });
          out.push({ t: t, taken: taken, off: taken || t < early });
        }
      });
      return out;
    }
    function free(d) { return slotsOf(d).some(function (s) { return !s.off; }); }

    function renderDays() {
      var base = now(tz);
      list = [];
      for (var k = 0; k < count; k++) list.push(dayAt(base, k));
      daysEl.innerHTML = list.map(function (d, i) {
        var open = hoursOf(d).length > 0, ok = open && free(d), name = i === 0 ? 'היום' : i === 1 ? 'מחר' : WS[d.wd];
        return '<button type="button" class="fx-booking__day" data-i="' + i + '" aria-pressed="false"' + (ok ? '' : ' disabled') +
          ' aria-label="יום ' + WD[d.wd] + ', ' + d.d + ' ב' + MONTHS[d.m - 1] + (ok ? '' : open ? ', אין תורים פנויים' : ', סגור') + '">' +
          '<span>' + name + '</span><b>' + d.d + '</b><small>' + (ok ? MS[d.m - 1] : open ? 'מלא' : 'סגור') + '</small></button>';
      }).join('');
    }
    function renderSlots(animate) {
      var d = list[st.day], s = slotsOf(d), parts = [['בוקר', 0, 720], ['צהריים', 720, 1020], ['ערב', 1020, 1440]];
      var out = parts.map(function (p) {
        var g = s.filter(function (x) { return x.t >= p[1] && x.t < p[2]; });
        if (!g.length) return '';
        return '<div class="fx-booking__part"><p>' + p[0] + '</p><div class="fx-booking__grid">' + g.map(function (x) {
          return '<button type="button" class="fx-booking__slot" data-t="' + x.t + '" aria-pressed="' + (x.t === st.time) + '"' + (x.off ? ' disabled' : '') +
            ' aria-label="' + hhmm(x.t) + (x.taken ? ', תפוס' : x.off ? ', כבר עבר' : '') + '">' + hhmm(x.t) + '</button>';
        }).join('') + '</div></div>';
      }).join('');
      slotsEl.innerHTML = out || '<p class="fx-booking__none">' + (hoursOf(d).length ? 'אין תורים פנויים ביום הזה' : 'סגור ביום הזה') + '</p>';
      if (animate && !REDUCE && slotsEl.animate) Array.prototype.forEach.call(slotsEl.querySelectorAll('.fx-booking__slot'), function (b, i) {
        b.animate([{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }], { duration: 280, delay: Math.min(i, 24) * 14, easing: 'cubic-bezier(.2, .8, .2, 1)', fill: 'backwards' });
      });
    }
    function summary() {
      var d = list[st.day], svc = st.svc >= 0 ? services[st.svc].name : '', when = 'יום ' + WD[d.wd] + ' ' + d.d + '.' + d.m;
      sumEl.textContent = st.time === null ? when + ' · בחרו שעה' : (svc ? svc + ' · ' : '') + when + ' · ' + hhmm(st.time);
      if (goBtn) goBtn.disabled = st.time === null;
      el.classList.toggle('has-time', st.time !== null);
      if (form) {
        hidden.date.value = st.time === null ? '' : d.key;
        hidden.time.value = st.time === null ? '' : hhmm(st.time);
        hidden.service.value = svc;
      }
    }
    function press(sel, attrName, value) {
      Array.prototype.forEach.call(el.querySelectorAll(sel), function (b) { b.setAttribute('aria-pressed', String(b.getAttribute(attrName) === String(value))); });
    }
    function pickDay(i, user) {
      st.day = i;
      st.time = null;
      press('.fx-booking__day', 'data-i', i);
      var d = list[i];
      monthEl.textContent = MONTHS[d.m - 1] + ' ' + d.y;
      renderSlots(user);
      summary();
      var b = daysEl.querySelector('[data-i="' + i + '"]');
      if (user && b) b.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: REDUCE ? 'auto' : 'smooth' });
    }
    function sent() {
      st.sent = true;
      el.classList.add('is-sent');
      sumEl.innerHTML = '<svg class="fx-booking__tick" viewBox="0 0 24 24" aria-hidden="true"><path pathLength="1" d="M12 2.5a9.5 9.5 0 1 1 0 19a9.5 9.5 0 0 1 0-19M7.5 12.3l3 3 6-6.3"/></svg><span>' +
        esc(attr('data-done', wa ? 'פתחנו את וואטסאפ עם הבקשה. נשאר רק ללחוץ על שליחה.' : 'הבקשה נשלחה! נאשר את התור בהודעה.')) + '</span>';
      goBtn.textContent = 'בחירת מועד אחר';
    }

    el.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('button');
      if (!b || b.disabled || !el.contains(b)) return;
      if (b.classList.contains('fx-booking__svc')) {
        st.svc = +b.getAttribute('data-i');
        press('.fx-booking__svc', 'data-i', st.svc);
        var keep = st.time;
        renderSlots(false);
        var again = slotsEl.querySelector('[data-t="' + keep + '"]:not(:disabled)');
        st.time = again ? keep : null;
        if (again) again.setAttribute('aria-pressed', 'true');
        summary();
      } else if (b.classList.contains('fx-booking__day')) {
        if (st.sent) return;
        pickDay(+b.getAttribute('data-i'), true);
      } else if (b.classList.contains('fx-booking__slot')) {
        if (st.sent) return;
        st.time = +b.getAttribute('data-t');
        press('.fx-booking__slot', 'data-t', st.time);
        if (!REDUCE && b.animate) b.animate([{ transform: 'scale(.9)' }, { transform: 'scale(1.06)' }, { transform: 'none' }], { duration: 320, easing: 'ease-out' });
        summary();
      } else if (b.classList.contains('fx-booking__arrow')) {
        var dir = +b.getAttribute('data-dir');
        daysEl.scrollBy({ left: dir * daysEl.clientWidth * 0.75 * (rtl ? -1 : 1), behavior: REDUCE ? 'auto' : 'smooth' });
      } else if (b === goBtn) {
        if (st.sent) {                                            // אחרי שליחה: מתחילים בחירה חדשה
          st.sent = false;
          el.classList.remove('is-sent');
          goBtn.textContent = attr('data-button', wa ? 'שליחת בקשה בוואטסאפ' : 'שליחת בקשה לתור');
          pickDay(st.day, true);
          return;
        }
        if (st.time === null) return;
        var d = list[st.day], svc = st.svc >= 0 ? services[st.svc].name : '';
        var text = 'שלום, אשמח לקבוע תור' + (svc ? ' ל' + svc : '') + ' ביום ' + WD[d.wd] + ' ' + d.d + '.' + d.m + ' בשעה ' + hhmm(st.time) + '.';
        el.dispatchEvent(new CustomEvent('fx:booking', { bubbles: true, detail: { date: d.key, time: hhmm(st.time), service: svc, text: text } }));
        if (wa) window.open('https://wa.me/' + wa.replace(/\D/g, '') + '?text=' + encodeURIComponent(text), '_blank', 'noopener');
        sent();
      }
    });

    renderDays();
    if (services.length) press('.fx-booking__svc', 'data-i', st.svc);
    var first = 0;
    while (first < list.length - 1 && !free(list[first])) first++;
    pickDay(first, false);
    setInterval(function () {                                       // תורים של היום שכבר עברו נסגרים לבד
      if (st.sent || document.hidden || st.day !== 0) return;
      var keep = st.time;
      renderSlots(false);
      if (keep !== null && !slotsEl.querySelector('[data-t="' + keep + '"]:not(:disabled)')) st.time = null;
      press('.fx-booking__slot', 'data-t', st.time);
      summary();
    }, 60000);
    el.fxBooking = {
      busy: function (arr) { setBusy(arr); renderDays(); pickDay(Math.max(0, st.day), false); },
      value: function () { return st.time === null ? null : { date: list[st.day].key, time: hhmm(st.time), service: st.svc >= 0 ? services[st.svc].name : '' }; }
    };
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-booking'), setup);
  }
  (window.FX = window.FX || {}).booking = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-contact · כפתור קשר צף */
(function () {
  'use strict';
  var ICONS = {
    whatsapp: '<path d="M12 3.2a8.8 8.8 0 0 0-7.6 13.2L3.2 20.8l4.5-1.2A8.8 8.8 0 1 0 12 3.2z"/><path d="M8.5 11.5h.01M12 11.5h.01M15.5 11.5h.01"/>',
    phone: '<path d="M6.5 3.5h2.8l1.6 4.2-2.1 1.4a10.5 10.5 0 0 0 6.1 6.1l1.4-2.1 4.2 1.6v2.8a2 2 0 0 1-2.2 2A16.5 16.5 0 0 1 4.5 5.7a2 2 0 0 1 2-2.2z"/>',
    waze: '<path d="M4 11.5 20 4l-7.5 16-2-6.5z"/>',
    mail: '<rect x="3.5" y="5.5" width="17" height="13" rx="2"/><path d="m4 7 8 6 8-6"/>',
    calendar: '<rect x="3.5" y="5" width="17" height="15" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>'
  };
  function svg(k, cls) { return '<svg' + (cls ? ' class="' + cls + '"' : '') + ' viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[k] || ICONS.link) + '</svg>'; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function kindOf(a) {                                          // לפי הקישור: וואטסאפ, טלפון, ניווט או מייל
    var k = a.getAttribute('data-kind'), h = a.getAttribute('href') || '';
    if (k) return k;
    if (/wa\.me|whatsapp/i.test(h)) return 'whatsapp';
    if (/^tel:/i.test(h)) return 'phone';
    if (/waze\.com|maps\.|goo\.gl\/maps/i.test(h)) return 'waze';
    if (/^mailto:/i.test(h)) return 'mail';
    return 'link';
  }

  function setup(el) {
    if (el.__fxContact) return;
    var links = Array.prototype.slice.call(el.querySelectorAll('a'));
    if (!links.length) return;
    el.__fxContact = true;
    var rtl = getComputedStyle(el).direction === 'rtl', open = false, main, menu = null, nudge = null;
    var remember = el.getAttribute('data-remember') !== 'false', KEY = 'fx-contact-nudge', text = el.getAttribute('data-nudge');
    el.style.setProperty('--fx-contact-origin', rtl ? 'left' : 'right');
    function color(k) { return 'var(--fx-contact-' + k + ', var(--fx-contact-main))'; }

    if (links.length === 1) {                                    // קישור אחד: הכפתור הוא הקישור עצמו
      main = links[0];
      var k1 = kindOf(main);
      main.classList.add('fx-contact__main');
      main.setAttribute('aria-label', main.getAttribute('aria-label') || main.textContent.trim());
      main.style.setProperty('--fx-c', color(k1));
      main.innerHTML = svg(k1);
    } else {                                                     // כמה קישורים: כפתור שנפתח לתפריט קטן
      menu = document.createElement('ul');
      menu.className = 'fx-contact__menu';
      menu.id = 'fx-contact-' + Math.random().toString(36).slice(2, 8);
      links.forEach(function (a, i) {
        var k = kindOf(a), li = document.createElement('li'), label = a.textContent.trim();
        a.className = 'fx-contact__item';
        a.style.setProperty('--fx-i', links.length - 1 - i);
        a.style.setProperty('--fx-n', links.length);
        a.style.setProperty('--fx-c', color(k));
        a.innerHTML = '<span class="fx-contact__label">' + esc(label) + '</span><span class="fx-contact__ico">' + svg(k) + '</span>';
        li.appendChild(a);
        menu.appendChild(li);
      });
      el.textContent = '';
      main = document.createElement('button');
      main.type = 'button';
      main.className = 'fx-contact__main';
      main.setAttribute('aria-expanded', 'false');
      main.setAttribute('aria-controls', menu.id);
      main.setAttribute('aria-label', el.getAttribute('data-label') || 'דברו איתנו');
      main.innerHTML = svg('whatsapp', 'fx-contact__chat') + '<svg class="fx-contact__x" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>';
      el.appendChild(menu);
      el.appendChild(main);
      main.addEventListener('click', function (e) { toggle(!open, e.detail === 0); });
      document.addEventListener('pointerdown', function (e) { if (open && !el.contains(e.target)) toggle(false); });
      el.addEventListener('keydown', function (e) { if (e.key === 'Escape' && open) { toggle(false); main.focus(); } });
      menu.addEventListener('click', function (e) { if (e.target.closest('a')) setTimeout(function () { toggle(false); }, 200); });
    }
    function toggle(v, keyboard) {
      if (!menu) return;
      open = v;
      el.classList.toggle('is-open', v);
      main.setAttribute('aria-expanded', String(v));
      if (v) {
        hideNudge(true);
        if (keyboard) setTimeout(function () { var f = menu.querySelector('a'); if (f) f.focus(); }, 60);
      }
    }

    // הודעה קטנה שקופצת אחרי כמה שניות, פעם אחת בכל ביקור
    function seen() { try { return sessionStorage.getItem(KEY) === '1'; } catch (err) { return false; } }
    function hideNudge(keep) {
      if (nudge) nudge.hidden = true;
      if (keep && remember) try { sessionStorage.setItem(KEY, '1'); } catch (err) {}
    }
    function showNudge(force) {
      if (!text || open || (!force && remember && seen())) return;
      if (!nudge) {
        nudge = document.createElement('p');
        nudge.className = 'fx-contact__nudge';
        nudge.innerHTML = '<span></span><button type="button" class="fx-contact__close" aria-label="סגירת ההודעה">×</button>';
        nudge.firstChild.textContent = text;
        nudge.addEventListener('click', function (e) {
          var x = e.target.closest('.fx-contact__close');
          hideNudge(true);
          if (x) return;
          if (menu) toggle(true); else main.click();
        });
        el.appendChild(nudge);
      }
      nudge.hidden = false;
    }
    if (text) setTimeout(showNudge, (parseFloat(el.getAttribute('data-delay')) || 6) * 1000);

    // יורד מהדרך כשמגיעים לאזור שכבר יש בו פרטי קשר, למשל הכותרת התחתונה
    var avoid = el.getAttribute('data-avoid');
    if (avoid && 'IntersectionObserver' in window) {
      var inView = [];
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          var i = inView.indexOf(en.target);
          if (en.isIntersecting && i < 0) inView.push(en.target);
          else if (!en.isIntersecting && i >= 0) inView.splice(i, 1);
        });
        el.classList.toggle('is-away', inView.length > 0);
        if (inView.length) { toggle(false); hideNudge(false); }
      });
      Array.prototype.forEach.call(document.querySelectorAll(avoid), function (t) { io.observe(t); });
    }
    el.fxContact = { open: function () { toggle(true); }, close: function () { toggle(false); }, nudge: function () { showNudge(true); } };
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-contact'), setup);
  }
  (window.FX = window.FX || {}).contact = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-open · פתוח עכשיו */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var LETTERS = 'אבגדהוש';
  var WD = ['ראשון', 'שני', 'שלישי', 'רביעי', 'חמישי', 'שישי', 'שבת'];

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function hhmm(m) { return m >= 1440 ? '24:00' : pad(Math.floor(m / 60)) + ':' + pad(m % 60); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  // שעות פעילות בעברית: "א-ה 09:00-20:00; ו 08:00-14:00; ש סגור"
  function ranges(text) {
    if (/סגור/.test(text)) return [];
    var out = [], re = /(\d{1,2})[:.](\d{2})\s*[-–—]\s*(\d{1,2})[:.](\d{2})/g, m;
    while ((m = re.exec(text))) {
      var a = +m[1] * 60 + +m[2], b = +m[3] * 60 + +m[4];
      if (b <= a) b += 1440;
      out.push([a, Math.min(b, 1440)]);
    }
    return out.sort(function (x, y) { return x[0] - y[0]; });
  }
  function parseWeek(s) {
    var week = [[], [], [], [], [], [], []];
    (s || '').split(/[;\n]+/).forEach(function (part) {
      var m = /^\s*(.+?)\s+((?:\d|סגור).*)$/.exec(part);
      if (!m) return;
      var rs = ranges(m[2]);
      m[1].replace(/[׳'"\s]/g, '').split(',').forEach(function (tok) {
        var r = tok.split(/[-–]/), a = LETTERS.indexOf(r[0]), b = LETTERS.indexOf(r[r.length - 1]);
        if (a < 0 || b < 0) return;
        for (var i = a; ; i = (i + 1) % 7) { week[i] = rs; if (i === b) break; }
      });
    });
    return week;
  }
  // חגים וימים מיוחדים: "2026-09-21 סגור (ערב חג); 2026-09-22 09:00-13:00"
  function parseExcept(s) {
    var map = {};
    (s || '').split(/[;\n]+/).forEach(function (part) {
      var m = /^\s*(\d{4}-\d{2}-\d{2})\s+(.+)$/.exec(part);
      if (!m) return;
      var note = /\(([^)]+)\)/.exec(m[2]);
      map[m[1]] = { r: ranges(m[2]), note: note ? note[1].trim() : '' };
    });
    return map;
  }
  function clock(tz) {
    var p = {};
    try {
      new Intl.DateTimeFormat('en-US', { timeZone: tz, year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', hourCycle: 'h23' })
        .formatToParts(new Date()).forEach(function (x) { p[x.type] = x.value; });
    } catch (err) {
      var d = new Date();
      p = { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate(), hour: d.getHours(), minute: d.getMinutes() };
    }
    return { y: +p.year, m: +p.month, d: +p.day, min: (+p.hour % 24) * 60 + +p.minute };
  }
  function dayAt(base, k) {
    var t = new Date(Date.UTC(base.y, base.m - 1, base.d + k));
    return { key: t.getUTCFullYear() + '-' + pad(t.getUTCMonth() + 1) + '-' + pad(t.getUTCDate()), wd: t.getUTCDay() };
  }
  // "שעה ו-20 דקות", "שעתיים", "45 דקות"
  function dur(m) {
    m = Math.max(1, Math.round(m));
    if (m < 60) return m === 1 ? 'דקה' : m + ' דקות';
    var h = Math.floor(m / 60), r = Math.round((m % 60) / 5) * 5;
    if (r === 60) { h++; r = 0; }
    var hs = h === 1 ? 'שעה' : h === 2 ? 'שעתיים' : h + ' שעות';
    return r ? hs + ' ו-' + r + ' דקות' : hs;
  }
  function span(rs) { return rs.length ? '<span dir="ltr">' + rs.map(function (r) { return hhmm(r[0]) + '–' + hhmm(r[1]); }).join(', ') + '</span>' : 'סגור'; }

  function setup(el) {
    if (el.__fxOpen) return;
    el.__fxOpen = true;
    function attr(n, d) { var v = el.getAttribute(n); return v === null ? d : v; }
    var tz = attr('data-tz', 'Asia/Jerusalem'), week = parseWeek(attr('data-hours', '')), except = parseExcept(attr('data-except', ''));
    var soon = +attr('data-soon', 60), rtl = getComputedStyle(el).direction === 'rtl', fake = null, last = '';
    el.style.setProperty('--fx-open-from', rtl ? 'right' : 'left');
    function today(base, k) { var d = dayAt(base, k); d.ex = except[d.key]; d.r = d.ex ? d.ex.r : week[d.wd]; return d; }
    function nowish() {                                            // השעה עכשיו אצל העסק, או שעה מדומה להדגמה
      var c = clock(tz);
      if (!fake) return c;
      var k = (fake.wd - dayAt(c, 0).wd + 7) % 7;
      var t = new Date(Date.UTC(c.y, c.m - 1, c.d + k));
      return { y: t.getUTCFullYear(), m: t.getUTCMonth() + 1, d: t.getUTCDate(), min: fake.min };
    }

    var all = [];
    week.forEach(function (rs) { all = all.concat(rs); });
    var lo = all.length ? Math.floor(Math.min.apply(null, all.map(function (r) { return r[0]; })) / 60) * 60 : 480;
    var hi = all.length ? Math.ceil(Math.max.apply(null, all.map(function (r) { return r[1]; })) / 60) * 60 : 1200;
    var html = '<div class="fx-open__now"><span class="fx-open__dot" aria-hidden="true"></span><p class="fx-open__status" role="status"></p></div>';
    if (attr('data-bar', 'true') !== 'false') html += '<div class="fx-open__day" aria-hidden="true"><div class="fx-open__track"><span class="fx-open__marker" hidden><span>עכשיו</span></span></div>' +
      '<div class="fx-open__scale"><span>' + hhmm(lo) + '</span><span>' + hhmm(Math.round((lo + hi) / 120) * 60) + '</span><span>' + hhmm(hi) + '</span></div></div>';
    if (attr('data-table', 'true') !== 'false') html += '<table class="fx-open__week"><caption>' + esc(attr('data-title', 'שעות פעילות')) + '</caption><tbody></tbody></table>';
    el.insertAdjacentHTML('beforeend', html);
    var statusEl = el.querySelector('.fx-open__status'), track = el.querySelector('.fx-open__track'), marker = el.querySelector('.fx-open__marker'), body = el.querySelector('.fx-open__week tbody');

    function state(base) {
      var t = today(base, 0), m = base.min, cur = null;
      t.r.forEach(function (r) { if (m >= r[0] && m < r[1]) cur = r; });
      if (cur) {
        var end = cur[1];
        t.r.forEach(function (r) { if (r[0] === end) end = r[1]; });
        var left = end - m;
        if (left <= soon) return { cls: 'is-soon', title: 'פתוח עכשיו', sub: 'נסגר בעוד ' + dur(left) };
        return { cls: 'is-on', title: 'פתוח עכשיו', sub: end >= 1440 ? 'עד חצות' : 'עד ' + hhmm(end) };
      }
      var note = t.ex && !t.ex.r.length ? t.ex.note : '';
      for (var k = 0; k < 15; k++) {
        var d = k ? today(base, k) : t, next = d.r.filter(function (r) { return k > 0 || r[0] > m; });
        if (!next.length) continue;
        var s = next[0][0];
        if (k === 0) { var wait = s - m; return { cls: wait <= soon ? 'is-soon' : '', title: 'סגור עכשיו', sub: wait <= soon ? 'נפתח בעוד ' + dur(wait) : 'נפתח היום ב-' + hhmm(s) }; }
        return { cls: '', title: note ? 'סגור היום' : 'סגור עכשיו', note: note, sub: (k === 1 ? 'נפתח מחר ב-' : 'נפתח ביום ' + WD[d.wd] + ' ב-') + hhmm(s) };
      }
      return { cls: '', title: 'סגור כרגע', sub: '' };
    }
    function pos(m) { return Math.max(0, Math.min(100, (m - lo) / (hi - lo) * 100)); }
    function render() {
      var base = nowish(), s = state(base), t = today(base, 0);
      el.classList.remove('is-on', 'is-soon');
      if (s.cls) el.classList.add(s.cls);
      var text = '<b>' + s.title + '</b>' + (s.note ? ' (' + esc(s.note) + ')' : '') + (s.sub ? ' · <span>' + s.sub + '</span>' : '');
      if (text !== last) { last = text; statusEl.innerHTML = text; }
      if (track) {
        Array.prototype.forEach.call(track.querySelectorAll('.fx-open__seg'), function (n) { n.remove(); });
        t.r.forEach(function (r) {
          var seg = document.createElement('span');
          seg.className = 'fx-open__seg';
          seg.style.insetInlineStart = pos(r[0]) + '%';
          seg.style.width = (pos(r[1]) - pos(r[0])) + '%';
          track.insertBefore(seg, marker);
        });
        marker.hidden = base.min < lo || base.min > hi;
        marker.style.insetInlineStart = pos(base.min) + '%';
      }
      if (body) {
        var rows = '';
        for (var i = 0; i < 7; i++) {
          var k = (i - t.wd + 7) % 7, d = today(base, k), isToday = k === 0;
          rows += '<tr class="' + (isToday ? 'is-today' : '') + (d.r.length ? '' : ' is-closed') + '"><th scope="row">' + WD[i] + (isToday ? '<span class="fx-open__tag">היום</span>' : '') + '</th><td>' +
            span(d.r) + (d.ex && d.ex.note ? '<span class="fx-open__note">' + esc(d.ex.note) + '</span>' : '') + '</td></tr>';
        }
        body.innerHTML = rows;
      }
    }

    if (!REDUCE && track && 'IntersectionObserver' in window) {     // הפס של היום מתמלא כשמגיעים אליו
      el.classList.add('is-armed');
      var io = new IntersectionObserver(function (entries) {
        if (!entries[entries.length - 1].isIntersecting) return;
        io.disconnect();
        requestAnimationFrame(function () { el.classList.add('is-in'); });
      }, { threshold: 0.4 });
      io.observe(el);
    }
    render();
    setInterval(function () { if (!document.hidden && !fake) render(); }, 30000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) render(); });
    el.fxOpen = {
      update: render,
      at: function (wd, min) { fake = wd === null || wd === undefined ? null : { wd: wd, min: min || 0 }; render(); }   // הדגמה: יום ושעה מדומים
    };
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-open'), setup);
  }
  (window.FX = window.FX || {}).open = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-access · תפריט נגישות */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var ICON = {
    person: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="6.6" r="1.3" fill="currentColor"/><path d="M6.5 9.4c1.8.6 3.6.9 5.5.9s3.7-.3 5.5-.9M12 10.3v4.3M12 14.6l-2.3 4.4M12 14.6l2.3 4.4"/>',
    contrast: '<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5v17a8.5 8.5 0 0 0 0-17z" fill="currentColor"/>',
    gray: '<path d="M12 3.5c3 3.6 5.6 6.6 5.6 9.9a5.6 5.6 0 0 1-11.2 0c0-3.3 2.6-6.3 5.6-9.9z"/><path d="M12 9.5v9.4"/>',
    links: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    font: '<path d="M3.5 19 8.5 5l5 14M5.3 14.4h6.4M15.4 11.4c.6-1.2 1.6-1.9 3-1.9 1.8 0 2.6 1.2 2.6 3V19M21 15.3c-.7-.5-1.6-.6-2.6-.5-1.5.2-2.5 1-2.5 2.1s.9 1.9 2.2 1.9c1.4 0 2.5-.9 2.9-2.3"/>',
    spacing: '<path d="M4 5h16M4 10h16M4 15h10M4 20h16"/>',
    still: '<rect x="6.5" y="5" width="3.6" height="14" rx="1"/><rect x="13.9" y="5" width="3.6" height="14" rx="1"/>',
    cursor: '<path d="M5.5 3.5 18.5 11l-6 1.6-3 5.9z"/>'
  };
  var OPTS = [['contrast', 'ניגודיות גבוהה'], ['gray', 'גווני אפור'], ['links', 'הדגשת קישורים'], ['font', 'גופן קריא'], ['spacing', 'ריווח טקסט'], ['still', 'עצירת אנימציות'], ['cursor', 'סמן גדול']];
  var SIZES = [1, 1.12, 1.25, 1.4, 1.6];
  function svg(k) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + ICON[k] + '</svg>'; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  function setup(el) {
    if (el.__fxAccess) return;
    el.__fxAccess = true;
    var target = document.querySelector(el.getAttribute('data-target') || 'html') || document.documentElement;
    var key = el.getAttribute('data-store') || 'fx-access', rtl = getComputedStyle(el).direction === 'rtl', open = false;
    var inline = target.style.fontSize, base = parseFloat(getComputedStyle(target).fontSize) || 16, id = 'fx-access-' + Math.random().toString(36).slice(2, 8);
    var state = { size: 0 };
    try { state = JSON.parse(localStorage.getItem(key)) || state; } catch (err) {}
    el.style.setProperty('--fx-access-origin', rtl ? 'right' : 'left');
    var statement = el.getAttribute('data-statement');
    el.innerHTML = '<div class="fx-access__panel" id="' + id + '" role="dialog" aria-label="הגדרות נגישות" hidden>' +
      '<div class="fx-access__head"><p class="fx-access__title">נגישות</p><button type="button" class="fx-access__x" aria-label="סגירת תפריט הנגישות">×</button></div>' +
      '<div class="fx-access__size"><span id="' + id + '-size">גודל טקסט</span><div role="group" aria-labelledby="' + id + '-size">' +
      '<button type="button" data-size="-1" aria-label="הקטנת טקסט">−</button><output aria-live="polite">100%</output><button type="button" data-size="1" aria-label="הגדלת טקסט">+</button></div></div>' +
      '<div class="fx-access__grid">' + OPTS.map(function (o) { return '<button type="button" class="fx-access__opt" data-opt="' + o[0] + '" aria-pressed="false">' + svg(o[0]) + '<span>' + o[1] + '</span></button>'; }).join('') + '</div>' +
      '<div class="fx-access__foot"><button type="button" class="fx-access__reset">איפוס הגדרות</button>' + (statement ? '<a href="' + esc(statement) + '">הצהרת נגישות</a>' : '') + '</div></div>' +
      '<button type="button" class="fx-access__toggle" aria-expanded="false" aria-controls="' + id + '" aria-label="' + esc(el.getAttribute('data-label') || 'תפריט נגישות') + '">' + svg('person') + '</button>';
    var panel = el.querySelector('.fx-access__panel'), toggleBtn = el.querySelector('.fx-access__toggle'), out = el.querySelector('output');

    function save() { try { localStorage.setItem(key, JSON.stringify(state)); } catch (err) {} }
    function apply() {
      OPTS.forEach(function (o) {
        target.classList.toggle('fx-a-' + o[0], !!state[o[0]]);
        el.querySelector('[data-opt="' + o[0] + '"]').setAttribute('aria-pressed', String(!!state[o[0]]));
      });
      target.style.fontSize = state.size ? (base * SIZES[state.size]).toFixed(2) + 'px' : inline;   // מגדילים לפי הגודל שהאתר כבר הגדיר
      out.textContent = Math.round(SIZES[state.size] * 100) + '%';
      el.querySelector('[data-size="-1"]').disabled = state.size <= 0;
      el.querySelector('[data-size="1"]').disabled = state.size >= SIZES.length - 1;
      if (state.still) Array.prototype.forEach.call(target.querySelectorAll('video'), function (v) { try { v.pause(); } catch (err) {} });
      save();
    }
    function focusables() { return Array.prototype.filter.call(panel.querySelectorAll('button, a[href]'), function (n) { return !n.disabled; }); }
    function setOpen(v, back) {
      open = v;
      panel.hidden = !v;
      toggleBtn.setAttribute('aria-expanded', String(v));
      if (v) {
        if (!REDUCE && panel.animate) {
          panel.animate([{ opacity: 0, transform: 'translateY(12px) scale(.96)' }, { opacity: 1, transform: 'none' }], { duration: 260, easing: 'cubic-bezier(.2, .8, .2, 1)' });
          Array.prototype.forEach.call(panel.querySelectorAll('.fx-access__opt'), function (b, i) {
            b.animate([{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }], { duration: 300, delay: 60 + i * 25, easing: 'cubic-bezier(.2, .8, .2, 1)', fill: 'backwards' });
          });
        }
        var f = el.querySelector('[data-opt]');
        if (f) f.focus({ preventScroll: true });
      } else if (back) toggleBtn.focus();
    }
    toggleBtn.addEventListener('click', function () { setOpen(!open, true); });
    el.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('button');
      if (!b || !panel.contains(b)) return;
      if (b.classList.contains('fx-access__x')) setOpen(false, true);
      else if (b.hasAttribute('data-size')) { state.size = Math.max(0, Math.min(SIZES.length - 1, state.size + +b.getAttribute('data-size'))); apply(); }
      else if (b.hasAttribute('data-opt')) { var k = b.getAttribute('data-opt'); state[k] = !state[k]; apply(); }
      else if (b.classList.contains('fx-access__reset')) { state = { size: 0 }; apply(); }
    });
    el.addEventListener('keydown', function (e) {
      if (!open) return;
      if (e.key === 'Escape') { setOpen(false, true); return; }
      if (e.key !== 'Tab') return;                                   // מקלדת: הפוקוס מסתובב בתוך התפריט
      var f = focusables(), i = f.indexOf(document.activeElement);
      if (i < 0) return;
      if (e.shiftKey && i === 0) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); }
    });
    document.addEventListener('pointerdown', function (e) { if (open && !el.contains(e.target)) setOpen(false); });
    apply();
    el.fxAccess = { open: function () { setOpen(true); }, close: function () { setOpen(false); }, reset: function () { state = { size: 0 }; apply(); } };
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-access'), setup);
  }
  (window.FX = window.FX || {}).access = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();
