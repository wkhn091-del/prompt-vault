/* fx-flap · לוח טיסות */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var HE = 'אבגדהוזחטיכלמנסעפצקרשת', EN = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', NUM = '0123456789';
  var RTL = /[\u0590-\u08FF]/;

  function graphemes(s) {
    if (window.Intl && Intl.Segmenter) {
      return Array.from(new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(s),
        function (x) { return x.segment; });
    }
    return Array.from(s);
  }

  function half(cls) {
    var el = document.createElement('span'), ch = document.createElement('span');
    el.className = 'fx-flap__half ' + cls;
    ch.className = 'fx-flap__ch';
    el.appendChild(ch);
    return { el: el, ch: ch };
  }

  function makeCell() {
    var el = document.createElement('span');
    el.className = 'fx-flap__cell';
    el.setAttribute('aria-hidden', 'true');
    var p = {
      top: half('fx-flap__half--top'),
      bot: half('fx-flap__half--bot'),
      ftop: half('fx-flap__half--top fx-flap__flip'),
      fbot: half('fx-flap__half--bot fx-flap__flip')
    };
    [p.top, p.bot, p.ftop, p.fbot].forEach(function (h) { el.appendChild(h.el); });
    return { el: el, p: p, cur: ' ', job: 0, a: null, b: null };
  }

  function show(cell, ch) {
    cell.cur = ch;
    cell.p.top.ch.textContent = ch;
    cell.p.bot.ch.textContent = ch;
  }

  function stop(cell) {
    if (cell.a) cell.a.cancel();
    if (cell.b) cell.b.cancel();
    cell.a = cell.b = null;
    cell.p.ftop.el.style.visibility = 'hidden';
    cell.p.fbot.el.style.visibility = 'hidden';
    show(cell, cell.cur);
  }

  // היפוך אחד: החצי העליון נופל, ואחריו החצי התחתון של האות הבאה נוחת
  function flip(cell, next, dur, done) {
    var p = cell.p;
    p.ftop.ch.textContent = cell.cur;
    p.fbot.ch.textContent = next;
    p.top.ch.textContent = next;
    p.ftop.el.style.visibility = 'visible';
    cell.a = p.ftop.el.animate(
      [{ transform: 'rotateX(0deg)', filter: 'brightness(1)' },
       { transform: 'rotateX(-90deg)', filter: 'brightness(.45)' }],
      { duration: dur / 2, easing: 'ease-in', fill: 'forwards' });
    cell.a.onfinish = function () {
      p.ftop.el.style.visibility = 'hidden';
      p.fbot.el.style.visibility = 'visible';
      cell.a.cancel();
      cell.a = null;
      cell.b = p.fbot.el.animate(
        [{ transform: 'rotateX(90deg)', filter: 'brightness(.45)' },
         { transform: 'rotateX(0deg)', filter: 'brightness(1)' }],
        { duration: dur / 2, easing: 'ease-out', fill: 'forwards' });
      cell.b.onfinish = function () {
        cell.cur = next;
        p.bot.ch.textContent = next;
        p.fbot.el.style.visibility = 'hidden';
        cell.b.cancel();
        cell.b = null;
        done();
      };
    };
  }

  // shuffle = להפוך גם תאים שכבר מציגים את האות הנכונה (לכניסה הראשונה)
  function setWord(st, word, delay, shuffle) {
    var chars = graphemes(word);
    var pool = RTL.test(word) ? HE : /[A-Za-z]/.test(word) ? EN : /[0-9]/.test(word) ? NUM : HE;
    st.root.setAttribute('aria-label', word);
    st.cells.forEach(function (cell, i) {
      var target = chars[i] || ' ', job = ++cell.job;
      stop(cell);
      if (REDUCE || !cell.el.animate) { show(cell, target); return; }
      if (cell.cur === target && (!shuffle || target === ' ')) return;
      var total = target === ' ' ? 1 : st.flips + (i % 3), k = 0;
      function next() {
        if (job !== cell.job) return;
        k++;
        var last = k >= total;
        var ch = last ? target : pool.charAt(Math.floor(Math.random() * pool.length));
        flip(cell, ch, last ? st.speed * 1.6 : st.speed, function () { if (!last) next(); });
      }
      setTimeout(next, (delay || 0) + i * st.stagger);
    });
  }

  function setup(root) {
    if (root.__fxFlap) return;
    var text = root.textContent.replace(/\s+/g, ' ').trim();
    var words = (root.getAttribute('data-words') || '').split('|')
      .map(function (w) { return w.trim(); }).filter(Boolean);
    if (text && words.indexOf(text) === -1) words.unshift(text);
    if (!words.length) return;

    function num(name, d) { var v = parseFloat(root.getAttribute(name)); return isNaN(v) ? d : v; }
    var count = num('data-cells', 0) ||
      Math.max.apply(null, words.map(function (w) { return graphemes(w).length; }));
    var st = root.__fxFlap = {
      root: root, cells: [], index: 0,
      speed: num('data-speed', 100), stagger: num('data-stagger', 45), flips: num('data-flips', 3)
    };

    // התאים מסתדרים לפי כיוון הטקסט, גם אם העמוד בכיוון ההפוך
    var rtl = RTL.test(words.join(''));
    if (!root.hasAttribute('dir') && (getComputedStyle(root).direction === 'rtl') !== rtl) {
      root.setAttribute('dir', rtl ? 'rtl' : 'ltr');
    }
    root.setAttribute('role', 'img');
    root.textContent = '';
    for (var i = 0; i < count; i++) {
      var cell = makeCell();
      st.cells.push(cell);
      root.appendChild(cell.el);
    }
    root.fxFlap = { set: function (w) { setWord(st, String(w), 0); } };

    // המילה מוצגת מהרגע הראשון. כשהיא נכנסת למסך התאים מתערבבים ונוחתים עליה שוב
    root.setAttribute('aria-label', words[0]);
    graphemes(words[0]).forEach(function (ch, n) { if (st.cells[n]) show(st.cells[n], ch); });
    if (REDUCE || !('IntersectionObserver' in window)) return;

    var started = false, timer = 0;
    new IntersectionObserver(function (entries) {
      var on = entries[entries.length - 1].isIntersecting;
      clearInterval(timer);
      if (!on) return;
      if (!started) { started = true; setWord(st, words[0], num('data-delay', 0), true); }
      if (words.length > 1) {
        timer = setInterval(function () {
          st.index = (st.index + 1) % words.length;
          setWord(st, words[st.index], 0);
        }, num('data-interval', 2600));
      }
    }, { threshold: 0.1 }).observe(root);
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-flap'), setup);
  }
  (window.FX = window.FX || {}).flap = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-repel · אותיות בורחות */
(function () {
  'use strict';
  if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var RTL = /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFC]/;
  var LTR = /[A-Za-z\u00C0-\u024F\u0370-\u03FF\u0400-\u04FF]/;
  var DIGIT = /[0-9]/, UNIT = /[#$%\u00B0\u20AC\u00A3\u00A5\u20AA]/;
  var items = [], mouse = { x: -9999, y: -9999 }, running = false;

  function graphemes(s) {
    if (window.Intl && Intl.Segmenter) {
      return Array.from(new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(s),
        function (x) { return x.segment; });
    }
    return Array.from(s);
  }

  // קובע לכל תו את כיוון הקריאה שלו, כמו שהדפדפן עושה בטקסט רגיל:
  // עברית מימין, אנגלית משמאל, מספר הולך עם השפה שלפניו, וסימן פיסוק הולך עם שני שכניו או עם כיוון העמוד
  function resolve(text, base) {
    var gs = graphemes(text), out = [], strong = base, i, j, k;
    for (i = 0; i < gs.length; i++) {
      var g = gs[i], o = { g: g, dir: '', num: false, space: g === ' ' };
      if (RTL.test(g)) o.dir = strong = 'r';
      else if (LTR.test(g)) o.dir = strong = 'l';
      else if (DIGIT.test(g) || (UNIT.test(g) && (DIGIT.test(gs[i - 1] || '') || DIGIT.test(gs[i + 1] || '')))) {
        o.dir = strong;
        o.num = true;
      }
      out.push(o);
    }
    for (i = 0; i < out.length; i = k) {
      if (out[i].dir) { k = i + 1; continue; }
      for (k = i; k < out.length && !out[k].dir; k++);
      var prev = i ? out[i - 1].dir : base, next = k < out.length ? out[k].dir : base;
      var inNumber = k - i === 1 && i > 0 && k < out.length && out[i - 1].num && out[k].num && !out[i].space;
      for (j = i; j < k; j++) {
        out[j].dir = prev === next ? prev : base;
        out[j].num = inNumber;
      }
    }
    return out;
  }

  // מפרק את הטקסט לאותיות נפרדות ושומר על סדר נכון בעברית, באנגלית, במספרים ובשילוב שלהם
  function split(el) {
    var text = el.textContent.replace(/\s+/g, ' ').trim();
    var base = getComputedStyle(el).direction === 'rtl' ? 'r' : 'l';
    var chars = [], run = null, runDir = '', word = null, seg = null;
    var sr = document.createElement('span');
    sr.className = 'fx-repel__sr';
    sr.textContent = text;
    el.textContent = '';
    el.appendChild(sr);

    resolve(text, base).forEach(function (o) {
      if (!run || runDir !== o.dir) {
        run = document.createElement('span');
        run.dir = o.dir === 'r' ? 'rtl' : 'ltr';
        run.setAttribute('aria-hidden', 'true');
        el.appendChild(run);
        runDir = o.dir;
        word = seg = null;
      }
      if (o.space) {
        run.appendChild(document.createTextNode(' '));
        word = seg = null;
        return;
      }
      if (!word) {
        word = document.createElement('span');
        word.className = 'fx-repel__w';
        run.appendChild(word);
        seg = null;
      }
      var parent = word;
      if (o.num && o.dir === 'r') {          // מספר בתוך טקסט בעברית עדיין נקרא משמאל לימין
        if (!seg) {
          seg = document.createElement('span');
          seg.dir = 'ltr';
          word.appendChild(seg);
        }
        parent = seg;
      } else {
        seg = null;
      }
      var c = document.createElement('span');
      c.className = 'fx-repel__c';
      c.textContent = o.g;
      parent.appendChild(c);
      chars.push({ el: c, cx: 0, cy: 0, x: 0, y: 0, vx: 0, vy: 0, live: false });
    });
    return chars;
  }

  function measure(it) {
    it.dirty = false;
    it.chars.forEach(function (c) {
      var r = c.el.getBoundingClientRect();
      c.cx = r.left + r.width / 2 - c.x;
      c.cy = r.top + r.height / 2 - c.y;
    });
    var b = it.el.getBoundingClientRect(), m = it.radius * 2.4;
    it.box = { l: b.left - m, t: b.top - m, r: b.right + m, b: b.bottom + m };
  }

  function frame() {
    var active = false;
    for (var k = 0; k < items.length; k++) {
      var it = items[k];
      if (!it.visible) continue;
      if (it.dirty) measure(it);
      var near = mouse.x > it.box.l && mouse.x < it.box.r && mouse.y > it.box.t && mouse.y < it.box.b;
      if (!near && !it.live) continue;
      var R = it.radius, live = false;
      for (var i = 0; i < it.chars.length; i++) {
        var c = it.chars[i], tx = 0, ty = 0;
        var dx = c.cx - mouse.x, dy = c.cy - mouse.y, d = Math.sqrt(dx * dx + dy * dy);
        if (d < R) {
          var f = 1 - d / R;
          f = f * f * it.force;
          tx = d ? dx / d * f : 0;
          ty = d ? dy / d * f : -f;
        }
        c.vx = (c.vx + (tx - c.x) * 0.12) * 0.78;      // קפיץ
        c.vy = (c.vy + (ty - c.y) * 0.12) * 0.78;
        c.x += c.vx;
        c.y += c.vy;
        if (Math.abs(c.x) + Math.abs(c.y) + Math.abs(c.vx) + Math.abs(c.vy) > 0.06) {
          live = c.live = true;
          c.el.style.transform = 'translate(' + c.x.toFixed(2) + 'px,' + c.y.toFixed(2) + 'px) rotate(' +
            (c.x * it.twist).toFixed(2) + 'deg)';
        } else if (c.live) {
          c.live = false;
          c.x = c.y = c.vx = c.vy = 0;
          c.el.style.transform = '';
        }
      }
      it.live = live;
      if (live || near) active = true;
    }
    if (active) requestAnimationFrame(frame); else running = false;
  }

  function wake() {
    if (!running && items.length) { running = true; requestAnimationFrame(frame); }
  }

  // לחיצה או הקשה מפזרת את האותיות שבסביבה
  function burst(x, y) {
    items.forEach(function (it) {
      if (!it.visible) return;
      if (it.dirty) measure(it);
      var R = it.radius * 2.2;
      it.chars.forEach(function (c) {
        var dx = c.cx - x, dy = c.cy - y, d = Math.sqrt(dx * dx + dy * dy) || 1;
        if (d > R) return;
        var p = (1 - d / R) * it.force * 0.45;
        c.vx += dx / d * p;
        c.vy += dy / d * p;
        c.live = it.live = true;
      });
    });
  }

  function away() { mouse.x = mouse.y = -9999; wake(); }
  function dirty() { items.forEach(function (it) { it.dirty = true; }); wake(); }

  function setup(el) {
    if (el.__fxRepel) return;
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var it = el.__fxRepel = {
      el: el, chars: split(el), visible: true, dirty: true, live: false, box: null,
      radius: num('data-radius', 120), force: num('data-force', 46), twist: num('data-twist', 0.35)
    };
    items.push(it);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        it.visible = entries[entries.length - 1].isIntersecting;
        it.dirty = true;
      }, { rootMargin: '120px' }).observe(el);
    }
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-repel'), setup);
  }

  window.addEventListener('pointermove', function (e) { mouse.x = e.clientX; mouse.y = e.clientY; wake(); }, { passive: true });
  window.addEventListener('pointerdown', function (e) {
    mouse.x = e.clientX; mouse.y = e.clientY;
    burst(e.clientX, e.clientY);
    wake();
  }, { passive: true });
  window.addEventListener('pointerup', function (e) { if (e.pointerType !== 'mouse') away(); }, { passive: true });
  window.addEventListener('pointercancel', away, { passive: true });
  document.documentElement.addEventListener('mouseleave', away);
  window.addEventListener('scroll', dirty, { passive: true, capture: true });
  window.addEventListener('resize', dirty);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(dirty);

  (window.FX = window.FX || {}).repel = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-lit · טקסט נדלק */
(function () {
  'use strict';
  if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var items = [], queued = false;

  // עוטף כל מילה ב-span בלי לגעת בתגיות שבתוך הפסקה
  function wrap(el) {
    var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null), nodes = [], n, words = [];
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach(function (node) {
      var frag = document.createDocumentFragment(), prev = null;
      node.nodeValue.split(/(\s+)/).forEach(function (part) {
        if (!part) return;
        if (/^\s+$/.test(part)) {
          if (prev) prev.appendChild(document.createTextNode(' '));
          else frag.appendChild(document.createTextNode(' '));
          return;
        }
        prev = document.createElement('span');
        prev.className = 'fx-lit__w';
        prev.textContent = part;
        frag.appendChild(prev);
        words.push(prev);
      });
      node.parentNode.replaceChild(frag, node);
    });
    return words;
  }

  function update() {
    queued = false;
    var vh = window.innerHeight;
    items.forEach(function (it) {
      if (!it.visible) return;
      var r = it.el.getBoundingClientRect();
      var a = vh * it.start, b = vh * it.end;
      var p = (a - r.top) / (r.height + a - b);
      p = p < 0 ? 0 : p > 1 ? 1 : p;
      var n = it.words.length, head = p * (n + it.spread);
      for (var i = 0; i < n; i++) {
        var v = (head - i) / it.spread;
        v = v < 0 ? 0 : v > 1 ? 1 : Math.round(v * 50) / 50;
        if (v !== it.last[i]) {
          it.last[i] = v;
          it.words[i].style.setProperty('--p', v);
        }
      }
    });
  }

  function queue() {
    if (!queued) { queued = true; requestAnimationFrame(update); }
  }

  function setup(el) {
    if (el.__fxLit) return;
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var words = wrap(el);
    var it = el.__fxLit = {
      el: el, words: words, last: new Array(words.length), visible: true,
      start: num('data-start', 0.82),    // איפה במסך המילה הראשונה נדלקת (0 למעלה, 1 למטה)
      end: num('data-end', 0.42),        // איפה במסך המילה האחרונה נדלקת
      spread: num('data-spread', 6)      // כמה מילים נדלקות יחד
    };
    if (getComputedStyle(el).direction === 'rtl') el.classList.add('fx-lit--rtl');
    items.push(it);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        it.visible = entries[entries.length - 1].isIntersecting;
        queue();
      }, { rootMargin: '25% 0px' }).observe(el);
    }
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-lit'), setup);
    queue();
  }

  window.addEventListener('scroll', queue, { passive: true, capture: true });
  window.addEventListener('resize', queue);
  (window.FX = window.FX || {}).lit = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-odo · מונה מתגלגל */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  function span(cls, text) {
    var s = document.createElement('span');
    s.className = cls;
    if (text != null) s.textContent = text;
    return s;
  }

  // כל ספרה הופכת לגליל של ספרות. שאר התווים (₪, פסיק, %) נשארים במקום
  function build(el) {
    var text = el.textContent.replace(/\s+/g, ' ').trim(), reels = [], index = 0;
    el.setAttribute('role', 'img');
    el.setAttribute('aria-label', text);
    el.textContent = '';
    Array.from(text).forEach(function (ch) {
      if (!/[0-9]/.test(ch)) { el.appendChild(span('fx-odo__s', ch)).setAttribute('aria-hidden', 'true'); return; }
      var cell = span('fx-odo__d'), reel = span('fx-odo__reel'), turns = 1 + (index % 3), count = 0, t, k;
      cell.setAttribute('aria-hidden', 'true');
      for (t = 0; t < turns; t++) for (k = 0; k < 10; k++) { reel.appendChild(span('', k)); count++; }
      for (k = 0; k <= +ch; k++) { reel.appendChild(span('', k)); count++; }
      cell.appendChild(reel);
      el.appendChild(cell);
      reels.push({ el: reel, end: 'translateY(' + (-(count - 1) / count * 100).toFixed(4) + '%)', i: index++ });
    });
    return reels;
  }

  function play(st) {
    st.reels.forEach(function (r) {
      r.el.style.transform = r.end;
      if (REDUCE || !r.el.animate) return;
      r.el.animate([{ transform: 'translateY(0)' }, { transform: r.end }], {
        duration: st.duration + r.i * st.stagger,
        easing: 'cubic-bezier(.12,.86,.16,1)',
        fill: 'backwards'
      });
    });
  }

  function setup(el) {
    if (el.__fxOdo) return;
    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var st = el.__fxOdo = {
      reels: build(el),
      duration: num('data-duration', 1400),   // משך הגלגול של הספרה הראשונה, במילישניות
      stagger: num('data-stagger', 140)       // תוספת זמן לכל ספרה נוספת
    };
    el.fxOdo = { play: function () { play(st); } };
    if (REDUCE || !('IntersectionObserver' in window)) { play(st); return; }
    var once = el.getAttribute('data-once') !== 'false';
    var io = new IntersectionObserver(function (entries) {
      if (!entries[entries.length - 1].isIntersecting) return;
      play(st);
      if (once) io.disconnect();
    }, { threshold: 0.6 });
    io.observe(el);
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-odo'), setup);
  }
  (window.FX = window.FX || {}).odo = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-magnet · כפתור מגנטי */
(function () {
  'use strict';
  var mm = window.matchMedia;
  var REDUCE = mm && mm('(prefers-reduced-motion: reduce)').matches;
  var FINE = mm && mm('(hover: hover) and (pointer: fine)').matches;
  var list = [], px = -9999, py = -9999, running = false;

  function setup(el) {
    if (el.__fxMagnet) return;
    var label = el.querySelector('.fx-magnet__label');
    if (!label) {
      label = document.createElement('span');
      label.className = 'fx-magnet__label';
      while (el.firstChild) label.appendChild(el.firstChild);
      el.appendChild(label);
    }
    var over = document.createElement('span'), copy = label.cloneNode(true);
    over.className = 'fx-magnet__over';
    over.setAttribute('aria-hidden', 'true');
    over.appendChild(copy);
    el.appendChild(over);

    function num(name, d) { var v = parseFloat(el.getAttribute(name)); return isNaN(v) ? d : v; }
    var st = el.__fxMagnet = {
      el: el, labels: [label, copy], over: over, rect: null, dirty: true, live: false,
      x: 0, y: 0, vx: 0, vy: 0,
      strength: num('data-strength', 0.35),   // עוצמת המשיכה (0 עד 1)
      reach: num('data-reach', 36)            // מאיזה מרחק בפיקסלים הכפתור מתחיל להימשך
    };
    list.push(st);

    // המילוי מתחיל בנקודת הכניסה ומתנקז אל נקודת היציאה
    var since = 0, timer = 0;
    function fill(e, on) {
      var r = el.getBoundingClientRect();
      var x = ((e.clientX - r.left) / r.width * 100).toFixed(1) + '%';
      var y = ((e.clientY - r.top) / r.height * 100).toFixed(1) + '%';
      clearTimeout(timer);
      if (on) {
        since = performance.now();
        over.style.transition = 'none';
        over.style.setProperty('--fx-x', x);
        over.style.setProperty('--fx-y', y);
        void over.offsetWidth;
        over.style.transition = '';
        el.classList.add('is-on');
        return;
      }
      // בהקשה באצבע המילוי נשאר מספיק זמן כדי שיראו אותו
      var wait = e.pointerType === 'mouse' ? 0 : Math.max(0, 450 - (performance.now() - since));
      timer = setTimeout(function () {
        over.style.setProperty('--fx-x', x);
        over.style.setProperty('--fx-y', y);
        el.classList.remove('is-on');
      }, wait);
    }
    el.addEventListener('pointerenter', function (e) { fill(e, true); });
    el.addEventListener('pointerleave', function (e) { fill(e, false); });
    el.addEventListener('pointercancel', function (e) { fill(e, false); });
  }

  function frame() {
    var active = false;
    list.forEach(function (st) {
      if (st.dirty) {
        var r = st.el.getBoundingClientRect();
        st.rect = { cx: r.left + r.width / 2 - st.x, cy: r.top + r.height / 2 - st.y, w: r.width, h: r.height };
        st.dirty = false;
      }
      var dx = px - st.rect.cx, dy = py - st.rect.cy;
      var inside = Math.abs(dx) < st.rect.w / 2 + st.reach && Math.abs(dy) < st.rect.h / 2 + st.reach;
      if (!inside && !st.live) return;
      var tx = inside ? dx * st.strength : 0, ty = inside ? dy * st.strength : 0;
      var k = inside ? 0.16 : 0.1, damp = inside ? 0.62 : 0.8;   // נצמד חזק, משתחרר בקפיצה
      st.vx = (st.vx + (tx - st.x) * k) * damp;
      st.vy = (st.vy + (ty - st.y) * k) * damp;
      st.x += st.vx;
      st.y += st.vy;
      if (inside || Math.abs(st.x) + Math.abs(st.y) + Math.abs(st.vx) + Math.abs(st.vy) > 0.05) {
        st.live = active = true;
        st.el.style.transform = 'translate(' + st.x.toFixed(2) + 'px,' + st.y.toFixed(2) + 'px)';
        var inner = 'translate(' + (st.x * 0.3).toFixed(2) + 'px,' + (st.y * 0.3).toFixed(2) + 'px)';
        st.labels[0].style.transform = inner;
        st.labels[1].style.transform = inner;
      } else {
        st.live = false;
        st.x = st.y = st.vx = st.vy = 0;
        st.el.style.transform = st.labels[0].style.transform = st.labels[1].style.transform = '';
      }
    });
    if (active) requestAnimationFrame(frame); else running = false;
  }

  function wake() {
    if (!running && list.length) { running = true; requestAnimationFrame(frame); }
  }
  function dirty() { list.forEach(function (st) { st.dirty = true; }); }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-magnet'), setup);
  }

  if (FINE && !REDUCE) {
    window.addEventListener('pointermove', function (e) {
      if (e.pointerType === 'touch') return;
      px = e.clientX; py = e.clientY;
      wake();
    }, { passive: true });
    document.documentElement.addEventListener('mouseleave', function () { px = py = -9999; wake(); });
    window.addEventListener('scroll', dirty, { passive: true, capture: true });
    window.addEventListener('resize', dirty);
  }

  (window.FX = window.FX || {}).magnet = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-cursor · סמן חכם */
(function () {
  'use strict';
  var mm = window.matchMedia;
  if (!mm || !mm('(hover: hover) and (pointer: fine)').matches) return;   // רק עם עכבר
  var REDUCE = mm('(prefers-reduced-motion: reduce)').matches;
  var CLICKABLE = 'a, button, [role="button"], summary, label, select';
  var el, label, raf = 0, base = 14, zones = false;
  var p = { x: 0, y: 0 }, c = { x: 0, y: 0, w: 14, h: 14, r: 7, a: 0, sx: 1, sy: 1 };
  var mode = 'dot', stick = null, visible = false, pressed = false, first = true, recheck = false;

  function pick(t) {
    if (!t || !t.closest) return;
    if (zones && !t.closest('[data-cursor-zone]')) { hide(); return; }
    var s = t.closest('[data-cursor-stick]'), l = t.closest('[data-cursor]');
    var next = s ? 'stick' : (l && l.getAttribute('data-cursor')) ? 'label' : t.closest(CLICKABLE) ? 'link' : 'dot';
    stick = s;
    if (next === 'label' && label.textContent !== l.getAttribute('data-cursor')) {
      label.textContent = l.getAttribute('data-cursor');
    }
    if (next !== mode) {
      mode = next;
      el.classList.toggle('is-label', mode === 'label');
    }
    show();
  }

  function show() {
    if (visible) return;
    visible = first = true;
    el.classList.add('is-visible');
    if (!raf) raf = requestAnimationFrame(frame);
  }
  function hide() {
    visible = false;
    el.classList.remove('is-visible');
  }

  function frame() {
    raf = 0;
    if (recheck) { recheck = false; pick(document.elementFromPoint(p.x, p.y)); }
    var tx = p.x, ty = p.y, tw = base, th = base, tr = base / 2;
    if (mode === 'stick' && stick && stick.isConnected) {
      // נצמד לאלמנט ולוקח את הצורה שלו
      var r = stick.getBoundingClientRect(), pad = 6, mx = r.left + r.width / 2, my = r.top + r.height / 2;
      tw = r.width + pad * 2;
      th = r.height + pad * 2;
      tx = mx + (p.x - mx) * 0.12;
      ty = my + (p.y - my) * 0.12;
      tr = Math.min(parseFloat(getComputedStyle(stick).borderTopLeftRadius) || 0, Math.min(r.width, r.height) / 2) + pad;
    } else if (mode === 'label') {
      tw = th = 88; tr = 44;
    } else if (mode === 'link') {
      tw = th = base * 3.4; tr = tw / 2;
    }
    if (pressed) { tw *= 0.86; th *= 0.86; }
    if (first) { c.x = tx; c.y = ty; first = false; }

    var k = REDUCE ? 1 : 0.22, vx = tx - c.x, vy = ty - c.y;
    c.x += vx * k;
    c.y += vy * k;
    c.w += (tw - c.w) * 0.2;
    c.h += (th - c.h) * 0.2;
    c.r += (tr - c.r) * 0.2;

    // נמתח לכיוון התנועה
    var free = (mode === 'dot' || mode === 'link') && !REDUCE, speed = Math.sqrt(vx * vx + vy * vy);
    c.sx += ((free ? 1 + Math.min(speed / 70, 0.7) : 1) - c.sx) * 0.25;
    c.sy += ((free ? 1 - Math.min(speed / 220, 0.3) : 1) - c.sy) * 0.25;
    if (free && speed > 1.5) c.a = Math.atan2(vy, vx);

    el.style.width = c.w.toFixed(1) + 'px';
    el.style.height = c.h.toFixed(1) + 'px';
    el.style.borderRadius = c.r.toFixed(1) + 'px';
    el.style.transform = 'translate3d(' + (c.x - c.w / 2).toFixed(1) + 'px,' + (c.y - c.h / 2).toFixed(1) + 'px,0) rotate(' +
      (free ? c.a : 0).toFixed(3) + 'rad) scale(' + c.sx.toFixed(3) + ',' + c.sy.toFixed(3) + ')';
    if (visible) raf = requestAnimationFrame(frame);
  }

  function init() {
    if (el) return;
    el = document.querySelector('.fx-cursor');
    if (!el) return;                                              // בלי האלמנט הזה הסמן הרגיל נשאר
    if (el.parentNode !== document.body) document.body.appendChild(el);
    el.setAttribute('aria-hidden', 'true');
    label = document.createElement('span');
    label.className = 'fx-cursor__text';
    el.appendChild(label);
    base = parseFloat(getComputedStyle(el).getPropertyValue('--fx-cursor-size')) || 14;
    c.w = c.h = base;
    c.r = base / 2;

    // עם data-cursor-zone הסמן פועל רק בתוך האזורים המסומנים. בלי זה, בכל העמוד
    zones = !!document.querySelector('[data-cursor-zone]');
    document.documentElement.classList.add(zones ? 'fx-cursor-zones' : 'fx-cursor-all');

    window.addEventListener('pointermove', function (e) {
      if (e.pointerType === 'touch') return;
      p.x = e.clientX; p.y = e.clientY;
      pick(e.target);
    }, { passive: true });
    window.addEventListener('pointerdown', function () { pressed = true; }, { passive: true });
    window.addEventListener('pointerup', function () { pressed = false; }, { passive: true });
    window.addEventListener('scroll', function () { recheck = visible; }, { passive: true, capture: true });
    window.addEventListener('blur', hide);
    document.documentElement.addEventListener('mouseleave', hide);
  }

  (window.FX = window.FX || {}).cursor = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();

/* fx-menu · תפריט וילון */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var NS = 'http://www.w3.org/2000/svg';

  function clamp(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
  function ease(t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }

  // צורת הווילון: מלבן שהקצה התחתון שלו מתקמר בזמן התנועה
  function shape(q) {
    q = clamp(q);
    var y = ease(q) * 100, bulge = Math.sin(q * Math.PI) * 34;
    return 'M0 0H100V' + y.toFixed(2) + 'Q50 ' + (y + bulge * 2).toFixed(2) + ' 0 ' + y.toFixed(2) + 'Z';
  }

  function setup(menu) {
    if (menu.__fxMenu) return;
    menu.__fxMenu = true;

    var svg = document.createElementNS(NS, 'svg');
    var back = document.createElementNS(NS, 'path'), front = document.createElementNS(NS, 'path');
    svg.setAttribute('class', 'fx-menu__curtain');
    svg.setAttribute('viewBox', '0 0 100 100');
    svg.setAttribute('preserveAspectRatio', 'none');
    svg.setAttribute('aria-hidden', 'true');
    svg.appendChild(back);
    svg.appendChild(front);
    menu.insertBefore(svg, menu.firstChild);

    Array.prototype.forEach.call(menu.querySelectorAll('.fx-menu__list a'), function (a, i) {
      a.style.setProperty('--i', i);
    });

    var close = menu.querySelector('.fx-menu__close');
    if (!close) {
      close = document.createElement('button');
      close.type = 'button';
      close.className = 'fx-menu__close';
      close.setAttribute('aria-label', menu.getAttribute('data-close-label') || 'סגירת התפריט');
      menu.appendChild(close);
    }

    var toggles = menu.id ? document.querySelectorAll('[aria-controls="' + menu.id + '"]') : [];
    var lock = menu.getAttribute('data-lock') !== 'false';   // נועל את גלילת העמוד כשהתפריט פתוח
    var contain = menu.getAttribute('data-contain') === 'true';   // נשאר בגבולות האלמנט שעוטף אותו
    var t = 0, target = 0, raf = 0, last = 0, opener = null;

    // אבא עם transform או backdrop-filter כולא אלמנט fixed. כאן התפריט נמתח חזרה לכל המסך
    function fit() {
      if (contain) return;
      menu.style.inset = menu.style.left = menu.style.top = menu.style.width = menu.style.height = '';
      var r = menu.getBoundingClientRect(), w = document.documentElement.clientWidth;
      if (Math.abs(r.left) < 1 && Math.abs(r.top) < 1 && Math.abs(r.width - w) < 2 && r.height > window.innerHeight - 100) return;
      menu.style.inset = 'auto';
      menu.style.left = -r.left + 'px';
      menu.style.top = -r.top + 'px';
      menu.style.width = w + 'px';
      menu.style.height = window.innerHeight + 'px';
      menu.style.height = '100lvh';
    }

    function draw() {
      back.setAttribute('d', shape(t * 1.3));
      front.setAttribute('d', shape(t * 1.3 - 0.3));
    }
    function settle() {
      raf = 0;
      if (!target) menu.classList.remove('is-closing');
    }
    function step(now) {
      var dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      t = target ? Math.min(t + dt / 0.95, 1) : Math.max(t - dt / 0.7, 0);
      draw();
      if (t !== target) raf = requestAnimationFrame(step); else settle();
    }
    function set(open) {
      if ((target === 1) === open) return;
      target = open ? 1 : 0;
      if (open) fit();
      menu.classList.toggle('is-open', open);
      menu.classList.toggle('is-closing', !open);
      menu.setAttribute('aria-hidden', open ? 'false' : 'true');
      if ('inert' in menu) menu.inert = !open;
      Array.prototype.forEach.call(toggles, function (b) { b.setAttribute('aria-expanded', open ? 'true' : 'false'); });
      if (lock) document.documentElement.style.overflow = open ? 'hidden' : '';
      if (open) {
        opener = document.activeElement;
        close.focus({ preventScroll: true });
      } else if (opener && opener.focus) {
        opener.focus({ preventScroll: true });
        opener = null;
      }
      if (REDUCE) { t = target; draw(); settle(); return; }
      if (!raf) { last = performance.now(); raf = requestAnimationFrame(step); }
    }

    menu.setAttribute('aria-hidden', 'true');
    if ('inert' in menu) menu.inert = true;
    draw();

    Array.prototype.forEach.call(toggles, function (b) {
      b.addEventListener('click', function () { set(target !== 1); });
    });
    close.addEventListener('click', function () { set(false); });
    menu.addEventListener('click', function (e) { if (e.target.closest('a')) set(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') set(false); });
    window.addEventListener('resize', function () { if (target) fit(); });
    menu.fxMenu = { open: function () { set(true); }, close: function () { set(false); } };
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-menu'), setup);
  }
  (window.FX = window.FX || {}).menu = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-holo · הולוגרמה */
(function () {
  'use strict';
  var mm = window.matchMedia;
  if (mm && mm('(prefers-reduced-motion: reduce)').matches) return;
  var TOUCH = !!mm && !mm('(hover: hover) and (pointer: fine)').matches;

  function setup(el) {
    if (el.__fxHolo) return;
    Array.prototype.forEach.call(el.querySelectorAll('[data-depth]'), function (n) {
      n.style.setProperty('--d', parseFloat(n.getAttribute('data-depth')) || 0);
    });
    // במגע אין ריחוף, אז הכרטיס מתנדנד לבד. data-idle="true" מפעיל את זה גם עם עכבר
    var idle = el.hasAttribute('data-idle') ? el.getAttribute('data-idle') !== 'false' : TOUCH;
    var st = el.__fxHolo = { px: 0, py: 0, on: 0, tx: 0, ty: 0, ton: 0, hover: false, visible: true, raf: 0 };

    function frame(now) {
      st.raf = 0;
      if (idle && !st.hover && st.visible) {
        st.tx = Math.sin(now / 1300) * 0.6;
        st.ty = Math.cos(now / 1700) * 0.45;
        st.ton = 1;
      }
      st.px += (st.tx - st.px) * 0.12;
      st.py += (st.ty - st.py) * 0.12;
      st.on += (st.ton - st.on) * 0.1;
      el.style.setProperty('--px', st.px.toFixed(4));
      el.style.setProperty('--py', st.py.toFixed(4));
      el.style.setProperty('--on', st.on.toFixed(3));
      var moving = Math.abs(st.tx - st.px) + Math.abs(st.ty - st.py) + Math.abs(st.ton - st.on) > 0.002;
      if (moving || (idle && !st.hover && st.visible)) st.raf = requestAnimationFrame(frame);
    }
    function wake() { if (!st.raf) st.raf = requestAnimationFrame(frame); }

    el.addEventListener('pointermove', function (e) {
      if (e.pointerType === 'touch') return;
      var r = el.getBoundingClientRect(), w = el.offsetWidth, h = el.offsetHeight;
      var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      st.tx = Math.max(-1, Math.min(1, (e.clientX - cx) / (w / 2)));
      st.ty = Math.max(-1, Math.min(1, (e.clientY - cy) / (h / 2)));
      st.ton = 1;
      st.hover = true;
      wake();
    });
    el.addEventListener('pointerleave', function () {
      st.hover = false;
      st.tx = st.ty = st.ton = 0;
      wake();
    });
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible && idle) wake();
      }).observe(el);
    }
    if (idle) wake();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-holo'), setup);
  }
  (window.FX = window.FX || {}).holo = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-drag · קרוסלת תנופה */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  function setup(root) {
    if (root.__fxDrag) return;
    var track = root.querySelector('.fx-drag__track');
    if (!track || !track.children.length) return;
    function num(name, d) { var v = parseFloat(root.getAttribute(name)); return isNaN(v) ? d : v; }

    var dirn = getComputedStyle(root).direction;
    var originals = Array.prototype.slice.call(track.children);
    root.style.direction = 'ltr';                                      // השורה נפרסת משמאל, והחישוב זהה בעברית ובאנגלית
    originals.forEach(function (el) { el.style.direction = dirn; });   // התוכן שומר על כיוון הקריאה שלו

    var loop = root.getAttribute('data-loop') !== 'false';              // קרוסלה אינסופית
    var curve = REDUCE ? 0 : num('data-curve', 1);                      // עוצמת הקשת (0 מבטל)
    var st = root.__fxDrag = {
      x: 0, v: 0, skew: 0, setW: 1, vw: 0, min: 0, items: [], raf: 0,
      dragging: false, hover: false, visible: true, moved: 0, lastX: 0, lastT: 0, pid: -1,
      speed: REDUCE || !loop ? 0 : num('data-speed', 0.5) * (dirn === 'rtl' ? 1 : -1)   // תנועה עצמית, פיקסלים לפריים
    };
    if (!root.hasAttribute('tabindex')) root.tabIndex = 0;

    function measure() {
      Array.prototype.forEach.call(track.querySelectorAll('[data-fx-clone]'), function (c) { track.removeChild(c); });
      var gap = parseFloat(getComputedStyle(track).columnGap) || 0;
      st.vw = root.clientWidth;
      st.setW = track.offsetWidth + gap;
      if (loop) {
        var copies = Math.ceil(st.vw / st.setW) + 1;
        for (var c = 0; c < copies; c++) {
          originals.forEach(function (el) {
            var k = el.cloneNode(true);
            k.setAttribute('data-fx-clone', '');
            k.setAttribute('aria-hidden', 'true');
            Array.prototype.forEach.call(k.querySelectorAll('a, button, input, [tabindex]'), function (f) { f.tabIndex = -1; });
            track.appendChild(k);
          });
        }
      }
      st.items = Array.prototype.map.call(track.children, function (el) {
        return { el: el, c: el.offsetLeft + el.offsetWidth / 2 };
      });
      st.min = Math.min(0, st.vw - track.offsetWidth);
    }

    function frame() {
      st.raf = 0;
      var out = !loop && (st.x > 0 || st.x < st.min);
      if (!st.dragging) {
        if (Math.abs(st.v) > 0.05) { st.x += st.v; st.v *= 0.95; }       // תנופה שדועכת
        else { st.v = 0; if (st.speed && !st.hover) st.x += st.speed; }
        if (out) { st.x += ((st.x > 0 ? 0 : st.min) - st.x) * 0.16; st.v *= 0.6; }
      }
      var lean = REDUCE ? 0 : Math.max(-9, Math.min(9, st.v * 0.35));
      st.skew += (lean - st.skew) * 0.2;

      var off = loop ? -((((-st.x) % st.setW) + st.setW) % st.setW) : st.x;
      track.style.transform = 'translate3d(' + off.toFixed(2) + 'px,0,0) skewX(' + st.skew.toFixed(2) + 'deg)';

      if (curve) {
        var mid = st.vw / 2;
        for (var i = 0; i < st.items.length; i++) {
          var it = st.items[i], n = (it.c + off - mid) / mid;
          if (n < -1.9 || n > 1.9) continue;
          it.el.style.transform = 'translateY(' + (n * n * 26 * curve).toFixed(1) + 'px) rotate(' + (n * 4.5 * curve).toFixed(2) + 'deg)';
        }
      }
      var settling = Math.abs(st.skew) > 0.02 || (out && Math.abs((st.x > 0 ? 0 : st.min) - st.x) > 0.3);
      if (st.visible && (st.dragging || st.v || settling || (st.speed && !st.hover))) st.raf = requestAnimationFrame(frame);
    }
    function wake() { if (!st.raf) st.raf = requestAnimationFrame(frame); }

    root.addEventListener('pointerdown', function (e) {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      st.dragging = true;
      st.pid = e.pointerId;
      st.moved = 0;
      st.v = 0;
      st.lastX = e.clientX;
      st.lastT = performance.now();
      wake();
    });
    root.addEventListener('pointermove', function (e) {
      if (!st.dragging || e.pointerId !== st.pid) return;
      var dx = e.clientX - st.lastX, now = performance.now(), dt = Math.max(now - st.lastT, 1);
      st.lastX = e.clientX;
      st.lastT = now;
      st.moved += Math.abs(dx);
      if (st.moved > 6 && !root.classList.contains('is-dragging')) {
        root.classList.add('is-dragging');
        try { root.setPointerCapture(e.pointerId); } catch (err) {}
      }
      st.x += !loop && (st.x > 0 || st.x < st.min) ? dx * 0.35 : dx;
      st.v = st.v * 0.6 + dx / dt * 16.7 * 0.4;
    });
    function end(e) {
      if (!st.dragging || (e && e.pointerId !== st.pid)) return;
      st.dragging = false;
      root.classList.remove('is-dragging');
      if (performance.now() - st.lastT > 90) st.v = 0;      // עצרו לפני ששחררו: בלי זריקה
      st.v = Math.max(-90, Math.min(90, st.v));
      if (st.speed && Math.abs(st.v) > 1) st.speed = Math.abs(st.speed) * (st.v > 0 ? 1 : -1);
      wake();
    }
    root.addEventListener('pointerup', end);
    root.addEventListener('pointercancel', end);
    root.addEventListener('click', function (e) {
      if (st.moved > 6) { e.preventDefault(); e.stopPropagation(); }
    }, true);
    root.addEventListener('dragstart', function (e) { e.preventDefault(); });
    root.addEventListener('pointerenter', function (e) { if (e.pointerType === 'mouse') st.hover = true; });
    root.addEventListener('pointerleave', function () { st.hover = false; wake(); });
    root.addEventListener('wheel', function (e) {
      if (Math.abs(e.deltaX) <= Math.abs(e.deltaY)) return;
      e.preventDefault();
      st.x -= e.deltaX;
      wake();
    }, { passive: false });
    root.addEventListener('keydown', function (e) {
      if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
      e.preventDefault();
      st.v = e.key === 'ArrowLeft' ? -26 : 26;
      wake();
    });

    var lastW = -1;
    function relayout() {
      if (root.clientWidth === lastW) return;
      lastW = root.clientWidth;
      measure();
      wake();
    }
    function remeasure() { lastW = -1; relayout(); }
    if ('ResizeObserver' in window) new ResizeObserver(relayout).observe(root);
    else window.addEventListener('resize', relayout);
    window.addEventListener('load', remeasure);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(remeasure);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible) wake();
      }).observe(root);
    }
    relayout();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-drag'), setup);
  }
  (window.FX = window.FX || {}).drag = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-zoom · זום דרך מילה */
(function () {
  'use strict';
  if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var items = [], queued = false;

  function hyp(a, b) { return Math.sqrt(a * a + b * b); }

  function setup(sec) {
    if (sec.__fxZoom) return;
    var stage = sec.querySelector('.fx-zoom__stage'), wordEl = sec.querySelector('.fx-zoom__word');
    if (!stage || !wordEl) return;
    var canvas = document.createElement('canvas'), ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.className = 'fx-zoom__canvas';
    canvas.setAttribute('aria-hidden', 'true');
    stage.appendChild(canvas);
    sec.classList.add('is-ready');

    // אלמנט עוטף עם overflow מבטל את position: sticky. במקרה כזה האפקט מצמיד את המסך בעצמו
    var manual = false;
    for (var n = sec.parentElement; n && n !== document.documentElement; n = n.parentElement) {
      var o = getComputedStyle(n), root = getComputedStyle(document.documentElement);
      if (n === document.body && root.overflowX === 'visible' && root.overflowY === 'visible') continue;
      if (/auto|scroll|hidden/.test(o.overflowX + ' ' + o.overflowY)) { manual = true; break; }
    }
    if (manual) sec.classList.add('is-manual');

    function num(name, d) { var v = parseFloat(sec.getAttribute(name)); return isNaN(v) ? d : v; }
    var st = sec.__fxZoom = {
      text: wordEl.textContent.replace(/\s+/g, ' ').trim(),
      fit: num('data-fit', 0.8),      // כמה מרוחב המסך המילה תופסת (0 עד 1)
      hold: num('data-hold', 0.18),   // איזה חלק מהגלילה נשאר לתוכן אחרי שהמילה נפתחה
      W: 0, H: 0, dpr: 1, font: '', dir: 'ltr', cover: '#ffffff',
      fx: 0, fy: 0, base: 0, maxS: 4, p: -1, visible: true
    };

    function word(c) {
      c.font = st.font;
      c.textAlign = 'center';
      c.textBaseline = 'alphabetic';
      c.direction = st.dir;
      c.fillStyle = '#000';
      c.fillText(st.text, st.W / 2, st.base);
    }

    // מוצא את הנקודה העבה ביותר באותיות. לשם נכנסים בזום, והיא קובעת כמה צריך להגדיל
    function focus() {
      var k = Math.min(1, 480 / st.W), w = Math.max(2, Math.round(st.W * k)), h = Math.max(2, Math.round(st.H * k));
      var off = document.createElement('canvas');
      off.width = w;
      off.height = h;
      var c = off.getContext('2d', { willReadFrequently: true });
      c.scale(k, k);
      word(c);
      var px = c.getImageData(0, 0, w, h).data, d = new Float32Array(w * h), x, y, i, v;
      for (i = 0; i < w * h; i++) d[i] = px[i * 4 + 3] > 127 ? 1e6 : 0;
      for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
        i = y * w + x;
        if (!d[i]) continue;
        if (!x || !y || x === w - 1 || y === h - 1) { d[i] = 1; continue; }
        d[i] = Math.min(d[i], d[i - 1] + 1, d[i - w] + 1, d[i - w - 1] + 1.414, d[i - w + 1] + 1.414);
      }
      for (y = h - 2; y > 0; y--) for (x = w - 2; x > 0; x--) {
        i = y * w + x;
        if (!d[i]) continue;
        d[i] = Math.min(d[i], d[i + 1] + 1, d[i + w] + 1, d[i + w + 1] + 1.414, d[i + w - 1] + 1.414);
      }
      var best = -1, bx = w / 2, by = h / 2, bd = 1;
      for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
        v = d[y * w + x];
        if (v < 1) continue;
        var score = v * (1 - Math.abs(x - w / 2) / w * 0.9);
        if (score > best) { best = score; bx = x; by = y; bd = v; }
      }
      st.fx = bx / k;
      st.fy = by / k;
      var far = Math.max(hyp(st.fx, st.fy), hyp(st.W - st.fx, st.fy), hyp(st.fx, st.H - st.fy), hyp(st.W - st.fx, st.H - st.fy));
      st.maxS = Math.max(far / Math.max(bd / k, 1) * 1.25, 4);
    }

    function layout() {
      var r = stage.getBoundingClientRect();
      if (!r.width || !r.height) return;
      st.W = r.width;
      st.H = r.height;
      st.dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(st.W * st.dpr);
      canvas.height = Math.round(st.H * st.dpr);
      var cs = getComputedStyle(wordEl), face = cs.fontStyle + ' ' + cs.fontWeight + ' ';
      st.dir = cs.direction;
      st.cover = getComputedStyle(sec).getPropertyValue('--fx-zoom-cover').trim() || '#ffffff';
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.font = face + '200px ' + cs.fontFamily;
      var size = Math.min(st.W * st.fit / (ctx.measureText(st.text).width || 1) * 200, st.H * 0.62);
      st.font = face + size.toFixed(1) + 'px ' + cs.fontFamily;
      ctx.font = st.font;
      var m = ctx.measureText(st.text);
      st.base = st.H / 2 + ((m.actualBoundingBoxAscent || size * 0.7) - (m.actualBoundingBoxDescent || 0)) / 2;
      focus();
      st.p = -1;
      queue();
    }

    function draw(p) {
      ctx.setTransform(st.dpr, 0, 0, st.dpr, 0, 0);
      ctx.globalCompositeOperation = 'source-over';
      ctx.clearRect(0, 0, st.W, st.H);
      if (p >= 1) return;                                   // המילה נפתחה לגמרי
      ctx.fillStyle = st.cover;
      ctx.fillRect(0, 0, st.W, st.H);
      var s = Math.pow(st.maxS, Math.pow(p, 1.35));
      ctx.globalCompositeOperation = 'destination-out';     // המילה חותכת חור במסך
      ctx.translate(st.fx, st.fy);
      ctx.scale(s, s);
      ctx.translate(-st.fx, -st.fy);
      word(ctx);
    }

    st.update = function () {
      if (!st.visible || !st.W) return;
      var r = sec.getBoundingClientRect(), total = r.height - st.H;
      var raw = total > 0 ? -r.top / total : 0;
      raw = raw < 0 ? 0 : raw > 1 ? 1 : raw;
      if (manual) stage.style.transform = 'translate3d(0,' + (raw * Math.max(total, 0)).toFixed(1) + 'px,0)';
      var p = Math.min(raw / (1 - st.hold), 1);
      if (Math.abs(p - st.p) < 0.0004) return;
      st.p = p;
      sec.style.setProperty('--fx-zoom-p', p.toFixed(4));
      draw(p);
    };
    items.push(st);

    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        queue();
      }, { rootMargin: '20% 0px' }).observe(sec);
    }
    if ('ResizeObserver' in window) new ResizeObserver(layout).observe(stage);
    else window.addEventListener('resize', layout);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(layout);
    layout();
  }

  function update() {
    queued = false;
    items.forEach(function (st) { st.update(); });
  }
  function queue() {
    if (!queued) { queued = true; requestAnimationFrame(update); }
  }
  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-zoom'), setup);
  }

  window.addEventListener('scroll', queue, { passive: true, capture: true });
  (window.FX = window.FX || {}).zoom = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-mosaic · מעבר מוזאיקה */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var KEY = 'fx-mosaic';

  function state(el) {
    return el.__fxMosaic || (el.__fxMosaic = { el: el, tiles: [], cols: 0, rows: 0, busy: false });
  }

  function build(st) {
    var el = st.el, r = el.getBoundingClientRect();
    var cols = Math.max(2, parseInt(el.getAttribute('data-cols'), 10) || 10);   // מספר האריחים לרוחב
    if (r.width < 560) cols = Math.max(4, Math.round(cols * 0.6));
    var rows = Math.max(2, Math.ceil(r.height / (r.width / cols)));
    if (cols === st.cols && rows === st.rows) return;
    st.cols = cols;
    st.rows = rows;
    st.tiles = [];
    el.style.gridTemplateColumns = 'repeat(' + cols + ',1fr)';
    el.style.gridTemplateRows = 'repeat(' + rows + ',1fr)';
    el.textContent = '';
    for (var y = 0; y < rows; y++) {
      for (var x = 0; x < cols; x++) {
        var t = document.createElement('i');
        t.className = 'fx-mosaic__t';
        el.appendChild(t);
        st.tiles.push({ el: t, x: x, y: y, v: 0 });
      }
    }
  }

  // קובע לכל אריח מתי הוא נכנס. הצורות: diagonal, center, rows, random
  function order(st, pattern) {
    var cx = (st.cols - 1) / 2, cy = (st.rows - 1) / 2, max = 0;
    var spread = parseFloat(st.el.getAttribute('data-spread')) || 480;          // משך הגל במילישניות
    st.tiles.forEach(function (t) {
      t.v = pattern === 'center' ? Math.sqrt((t.x - cx) * (t.x - cx) + (t.y - cy) * (t.y - cy))
        : pattern === 'random' ? Math.random()
        : pattern === 'rows' ? t.y + (t.x % 2) * 0.6
        : t.x + t.y;
      if (t.v > max) max = t.v;
    });
    st.tiles.forEach(function (t) {
      t.el.style.transitionDelay = (max ? t.v / max * spread : 0).toFixed(0) + 'ms';
    });
    return spread + 460;
  }

  function pick(st, pattern) { return pattern || st.el.getAttribute('data-pattern') || 'diagonal'; }

  function cover(el, pattern, done) {
    var st = state(el);
    build(st);
    el.classList.add('is-active');
    var total = REDUCE ? 0 : order(st, pick(st, pattern));
    void el.offsetWidth;
    el.classList.add('is-covered');
    setTimeout(done, total + 30);
  }

  function uncover(el, pattern, done) {
    var st = state(el);
    var total = REDUCE ? 0 : order(st, pick(st, pattern));
    el.classList.remove('is-covered');
    setTimeout(function () {
      el.classList.remove('is-active');
      if (done) done();
    }, total + 30);
  }

  function overlay() {
    var el = document.querySelector('.fx-mosaic');
    if (!el) {
      el = document.createElement('div');
      el.className = 'fx-mosaic';
      document.body.appendChild(el);
    }
    el.setAttribute('aria-hidden', 'true');
    return el;
  }

  // להחלפת תוכן בלי לעבור עמוד: FX.mosaic.play(function () { ...מחליפים תוכן... })
  function play(swap, opts) {
    opts = opts || {};
    var el = opts.el || overlay(), st = state(el);
    if (st.busy) return;
    st.busy = true;
    cover(el, opts.pattern, function () {
      if (swap) swap();
      requestAnimationFrame(function () {
        uncover(el, opts.pattern, function () { st.busy = false; });
      });
    });
  }

  // אם הגענו לעמוד דרך מעבר, מתחילים מכוסים ומתגלים
  function arrive() {
    var came = false;
    try {
      came = sessionStorage.getItem(KEY) === '1';
      sessionStorage.removeItem(KEY);
    } catch (err) {}
    if (!came) return;
    var el = overlay(), st = state(el);
    build(st);
    st.tiles.forEach(function (t) { t.el.style.transition = 'none'; });
    el.classList.add('is-active', 'is-covered');
    void el.offsetWidth;
    st.tiles.forEach(function (t) { t.el.style.transition = ''; });
    requestAnimationFrame(function () { uncover(el, null); });
  }

  document.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('a[data-fx-transition]') : null;
    if (!a || e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if (a.target === '_blank' || a.hasAttribute('download') || a.origin !== location.origin) return;
    if (a.pathname === location.pathname && a.search === location.search && a.hash) return;   // קישור בתוך אותו עמוד
    var url = a.href;
    e.preventDefault();
    try { sessionStorage.setItem(KEY, '1'); } catch (err) {}
    cover(overlay(), null, function () { location.href = url; });
  });
  window.addEventListener('pageshow', function (e) {
    var el = e.persisted && document.querySelector('.fx-mosaic');
    if (el) el.classList.remove('is-active', 'is-covered');
  });

  var arrived = false;
  function init() {
    if (arrived) return;
    arrived = true;
    arrive();
  }
  init.play = play;
  (window.FX = window.FX || {}).mosaic = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();

/* fx-dots · רשת נקודות */
(function () {
  'use strict';
  var REDUCE = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var list = [], running = false, mx = -9999, my = -9999;

  // כל צבע CSS חוקי -> [r, g, b]
  function rgb(color) {
    var c = document.createElement('canvas');
    c.width = c.height = 1;
    var x = c.getContext('2d');
    x.fillStyle = '#888';
    x.fillStyle = color;
    x.fillRect(0, 0, 1, 1);
    var d = x.getImageData(0, 0, 1, 1).data;
    return [d[0], d[1], d[2]];
  }

  function draw(st, now) {
    var ctx = st.ctx, dots = st.dots, R = st.radius, push = st.push, size = st.size;
    var rect = st.rect = st.host.getBoundingClientRect();
    var lx = mx - rect.left, ly = my - rect.top, t = now * 0.0011;
    var hot = [[], [], [], [], [], [], []], live = false, i, j, d, w;

    for (i = st.waves.length - 1; i >= 0; i--) {
      w = st.waves[i];
      w.r += 9;
      w.power *= 0.975;
      if (w.r > w.max) st.waves.splice(i, 1);
    }

    ctx.setTransform(st.dpr, 0, 0, st.dpr, 0, 0);
    ctx.clearRect(0, 0, st.W, st.H);
    ctx.fillStyle = st.shades[0];
    ctx.beginPath();
    for (i = 0; i < dots.length; i++) {
      d = dots[i];
      var tx = 0, ty = 0, dx = d.ox - lx, dy = d.oy - ly, q = dx * dx + dy * dy;
      if (q < R * R) {                                   // העכבר דוחף
        var dist = Math.sqrt(q) || 1, f = 1 - dist / R;
        f = f * f * push;
        tx = dx / dist * f;
        ty = dy / dist * f;
      }
      for (j = 0; j < st.waves.length; j++) {            // גל מלחיצה
        w = st.waves[j];
        var wx = d.ox - w.x, wy = d.oy - w.y, wd = Math.sqrt(wx * wx + wy * wy) || 1, band = Math.abs(wd - w.r);
        if (band < 46) {
          var a = (1 - band / 46) * w.power;
          d.vx += wx / wd * a;
          d.vy += wy / wd * a;
        }
      }
      d.vx = (d.vx + (tx - d.x) * 0.1) * 0.8;            // קפיץ חזרה למקום
      d.vy = (d.vy + (ty - d.y) * 0.1) * 0.8;
      d.x += d.vx;
      d.y += d.vy;
      d.m = Math.abs(d.x) + Math.abs(d.y);
      if (d.m > 0.35) {
        live = true;
        hot[Math.min(6, 1 + Math.floor(d.m / push * 6))].push(d);
      } else {
        var rad = st.ambient ? size * (1 + 0.45 * Math.sin(d.ox * 0.018 + d.oy * 0.024 - t)) : size;
        ctx.moveTo(d.ox + rad, d.oy);
        ctx.arc(d.ox, d.oy, rad, 0, 6.2832);
      }
    }
    ctx.fill();

    for (j = 1; j <= 6; j++) {
      if (!hot[j].length) continue;
      ctx.fillStyle = st.shades[j];
      ctx.beginPath();
      for (i = 0; i < hot[j].length; i++) {
        d = hot[j][i];
        var r2 = size * (1 + Math.min(d.m / push, 1) * 1.7), x = d.ox + d.x, y = d.oy + d.y;
        ctx.moveTo(x + r2, y);
        ctx.arc(x, y, r2, 0, 6.2832);
      }
      ctx.fill();
    }
    st.live = live || st.waves.length > 0;
  }

  function frame(now) {
    var again = false;
    list.forEach(function (st) {
      if (!st.visible || !st.W) return;
      draw(st, now);
      if (st.ambient || st.live) again = true;
    });
    if (again) requestAnimationFrame(frame); else running = false;
  }
  function wake() {
    if (!running && list.length) { running = true; requestAnimationFrame(frame); }
  }

  function setup(host) {
    if (host.__fxDots) return;
    var canvas = document.createElement('canvas'), ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.className = 'fx-dots__canvas';
    canvas.setAttribute('aria-hidden', 'true');
    host.appendChild(canvas);

    function num(name, d) { var v = parseFloat(host.getAttribute(name)); return isNaN(v) ? d : v; }
    var cs = getComputedStyle(host), shades = [];
    var base = rgb(cs.getPropertyValue('--fx-dots-color').trim() || '#8d8c84');
    var accent = rgb(cs.getPropertyValue('--fx-dots-accent').trim() || '#ffd21f');
    for (var s = 0; s <= 6; s++) {
      shades.push('rgb(' + [0, 1, 2].map(function (c) { return Math.round(base[c] + (accent[c] - base[c]) * s / 6); }).join(',') + ')');
    }

    var st = host.__fxDots = {
      host: host, canvas: canvas, ctx: ctx, shades: shades, dots: [], waves: [], rect: null,
      W: 0, H: 0, dpr: 1, visible: true, live: false,
      gap: num('data-gap', 26),          // מרחק בין נקודות
      radius: num('data-radius', 130),   // טווח ההשפעה של העכבר
      push: num('data-push', 30),        // כמה רחוק נקודה נדחפת
      size: num('data-size', 1.5),       // רדיוס נקודה
      ambient: !REDUCE && host.getAttribute('data-ambient') !== 'false'   // גל עדין גם בלי עכבר
    };
    list.push(st);

    function resize() {
      var r = host.getBoundingClientRect();
      if (!r.width || !r.height) return;
      st.W = r.width;
      st.H = r.height;
      st.dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(st.W * st.dpr);
      canvas.height = Math.round(st.H * st.dpr);
      var gap = st.gap;
      while ((st.W / gap) * (st.H / gap) > 4500) gap *= 1.15;
      var cols = Math.floor(st.W / gap) + 1, rows = Math.floor(st.H / gap) + 1;
      var ox = (st.W - (cols - 1) * gap) / 2, oy = (st.H - (rows - 1) * gap) / 2;
      st.dots = [];
      for (var y = 0; y < rows; y++) {
        for (var x = 0; x < cols; x++) {
          st.dots.push({ ox: ox + x * gap, oy: oy + y * gap, x: 0, y: 0, vx: 0, vy: 0, m: 0 });
        }
      }
      draw(st, performance.now());
      wake();
    }
    if ('ResizeObserver' in window) new ResizeObserver(resize).observe(host);
    else window.addEventListener('resize', resize);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible) wake();
      }).observe(host);
    }
    resize();
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('.fx-dots'), setup);
  }

  if (!REDUCE) {
    window.addEventListener('pointermove', function (e) { mx = e.clientX; my = e.clientY; wake(); }, { passive: true });
    window.addEventListener('pointerdown', function (e) {
      mx = e.clientX; my = e.clientY;
      list.forEach(function (st) {
        if (!st.visible || !st.W) return;
        var r = st.host.getBoundingClientRect();
        if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) return;
        st.waves.push({ x: e.clientX - r.left, y: e.clientY - r.top, r: 0, power: 2.6, max: Math.sqrt(r.width * r.width + r.height * r.height) });
      });
      wake();
    }, { passive: true });
    window.addEventListener('pointerup', function (e) { if (e.pointerType !== 'mouse') { mx = my = -9999; wake(); } }, { passive: true });
    document.documentElement.addEventListener('mouseleave', function () { mx = my = -9999; wake(); });
  }

  (window.FX = window.FX || {}).dots = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();

/* fx-pixel · חשיפת פיקסלים */
(function () {
  'use strict';
  if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  // מצייר את התמונה בריבועים בגודל block, לפי אותו חיתוך שהדפדפן מציג
  function draw(st, block) {
    var img = st.img, c = st.canvas, ctx = c.getContext('2d');
    var cw = Math.max(1, Math.round(st.w / block)), ch = Math.max(1, Math.round(st.h / block));
    var tmp = st.tmp || (st.tmp = document.createElement('canvas'));
    tmp.width = cw;
    tmp.height = ch;
    var nw = img.naturalWidth, nh = img.naturalHeight, sx = 0, sy = 0, sw = nw, sh = nh;
    if (getComputedStyle(img).objectFit === 'cover') {
      var s = Math.max(st.w / nw, st.h / nh);
      sw = st.w / s;
      sh = st.h / s;
      sx = (nw - sw) / 2;
      sy = (nh - sh) / 2;
    }
    var t = tmp.getContext('2d');
    t.imageSmoothingEnabled = true;
    t.drawImage(img, sx, sy, sw, sh, 0, 0, cw, ch);
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.drawImage(tmp, 0, 0, cw, ch, 0, 0, c.width, c.height);
  }

  function clear(st) {
    clearTimeout(st.timer);
    if (st.canvas && st.canvas.parentNode) st.canvas.parentNode.removeChild(st.canvas);
    st.canvas = null;
  }

  function play(st, count) {
    var img = st.img, parent = img.parentNode;
    if (!parent || !img.naturalWidth || !img.offsetWidth) return;
    clear(st);
    var c = st.canvas = document.createElement('canvas');
    c.className = 'fx-pixel__canvas';
    c.setAttribute('aria-hidden', 'true');
    if (getComputedStyle(parent).position === 'static') parent.style.position = 'relative';
    parent.insertBefore(c, img.nextSibling);

    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    st.w = img.offsetWidth;
    st.h = img.offsetHeight;
    c.style.left = img.offsetLeft + 'px';
    c.style.top = img.offsetTop + 'px';
    c.style.width = st.w + 'px';
    c.style.height = st.h + 'px';
    c.style.borderRadius = getComputedStyle(img).borderRadius;
    c.width = Math.max(1, Math.round(st.w * dpr));
    c.height = Math.max(1, Math.round(st.h * dpr));

    var n = Math.max(2, count || st.steps), coarse = Math.max(st.w, st.h) / 7, i = 0;
    (function next() {
      if (i >= n) { clear(st); return; }
      try {
        draw(st, Math.max(2, coarse * Math.pow(4 / coarse, i / (n - 1))));   // מריבועים גסים עד 4 פיקסלים
      } catch (err) { clear(st); return; }
      i++;
      st.timer = setTimeout(next, st.speed);
    })();
  }

  function setup(img) {
    if (img.__fxPixel) return;
    function num(name, d) { var v = parseFloat(img.getAttribute(name)); return isNaN(v) ? d : v; }
    var st = img.__fxPixel = {
      img: img, canvas: null, tmp: null, timer: 0, w: 0, h: 0,
      steps: num('data-steps', 6),     // כמה צעדים עד שהתמונה חדה
      speed: num('data-speed', 95)     // זמן לכל צעד, במילישניות
    };
    img.fxPixel = { play: function () { play(st); } };

    function ready() {
      if (!('IntersectionObserver' in window)) { play(st); return; }
      var io = new IntersectionObserver(function (entries) {
        if (!entries[entries.length - 1].isIntersecting) return;
        io.disconnect();
        play(st);
      }, { threshold: 0.25 });
      io.observe(img);
    }
    if (img.complete && img.naturalWidth) ready();
    else img.addEventListener('load', ready, { once: true });

    if (img.getAttribute('data-hover') === 'true') {       // חוזר על האפקט בריחוף
      img.addEventListener('pointerenter', function (e) { if (e.pointerType === 'mouse') play(st, 4); });
    }
  }

  function init(scope) {
    Array.prototype.forEach.call((scope || document).querySelectorAll('img.fx-pixel'), setup);
  }
  (window.FX = window.FX || {}).pixel = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); });
  else init();
})();
